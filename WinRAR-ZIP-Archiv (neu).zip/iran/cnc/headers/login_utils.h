#ifndef LOGIN_UTILS_H
#define LOGIN_UTILS_H

#include <time.h>

#define MAX_USERS 64

typedef struct {
    char user[50];
    char pass[50];
    int  maxtime;
    int  maxbots;
    int  is_logged_in;
    int  is_admin;
    int  is_root;
    int  prefix_enabled;
    /* Unix timestamp at which this plan expires.
       0 means the plan never expires (root users are always 0). */
    time_t expire_time;
} User;

extern User users[MAX_USERS];
extern int  user_count;

/* Load / persist users from/to database/logins.txt */
void load_users(void);
void save_users(void);

/* Returns user index on success.
   -1 = wrong credentials
   -2 = already logged in
   -3 = plan expired  */
int check_login(const char *user, const char *pass);

#endif /* LOGIN_UTILS_H */
