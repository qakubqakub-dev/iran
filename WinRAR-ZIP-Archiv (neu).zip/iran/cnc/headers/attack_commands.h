#ifndef ATTACK_COMMANDS_H
#define ATTACK_COMMANDS_H

#include "user_handler.h"
#include <stdint.h>

typedef struct {
    int len;
    int len_min;
    int len_max;
    int psize;          /* alias for len — used by udp/icmp/gre bots */
    int srcport;
    int cons;           /* slot count (cons=N → use N/maxslots fraction of bots) */
    int gport;
    uint8_t http_method;
    char proto[8];
    char sarch[64];
    char sgroup[64];
    char msg_bytes[64];
    char http_target[256];
    int msg_len;
    int usleep_min;
    int usleep_max;

    int has_len;
    int has_srcport;
    int has_cons;       /* 1 if cons= was explicitly set */
    int has_gport;
    int has_proto;
    int has_sarch;
    int has_sgroup;
    int has_msg;
    int has_usleep;
    int has_httpmode;
} AttackOptions;

void init_attack_options(AttackOptions *options);
void handle_udp_command(const User *user, const char *command, char *response);
void handle_udpplain_command(const User *user, const char *command, char *response);
void handle_tcp_command(const User *user, const char *command, char *response);
void handle_http_command(const User *user, const char *command, char *response);
void handle_syn_command(const User *user, const char *command, char *response);
void handle_icmp_command(const User *user, const char *command, char *response);
void handle_gre_command(const User *user, const char *command, char *response);
void handle_pps_command(const User *user, const char *command, char *response);

int is_attack_command(const char *command);

#endif // ATTACK_COMMANDS_H
