// language: C, file: logger.c, target: Linux, gcc
// Logger: settings cached once, log files held open, single mutex, no per-call fopen storm.
#include "headers/logger.h"
#include <stdio.h>
#include <string.h>
#include <netdb.h>
#include <time.h>
#include <pthread.h>
#include <errno.h>

#define CYAN "\033[1;36m"
#define DARK_RED "\033[31;2m"
#define GREEN "\033[32m"
#define YELLOW "\033[33m"
#define RESET "\033[0m"
#define RED "\033[31m"

static pthread_mutex_t g_log_mutex = PTHREAD_MUTEX_INITIALIZER;
static FILE* g_botlog = NULL;   // database/logs.txt
static FILE* g_userlog = NULL;  // database/userlogs.txt

static int g_filelogs = 1;
static int g_logips = 1;
static int g_loggroups = 0;
static int g_settings_loaded = 0;

static void get_timestamp(char* buf, size_t len) {
    time_t now = time(NULL);
    struct tm tm_buf;
    struct tm* tm_info = localtime_r(&now, &tm_buf);
    if (tm_info) strftime(buf, len, "%Y-%m-%d %H:%M:%S", tm_info);
    else buf[0] = 0;
}

/* Load options/settings.txt exactly once. Re-call log_settings_reload() if the
   file changes at runtime. Silent on failure � defaults are safe. */
static void load_settings_locked(void) {
    if (g_settings_loaded) return;
    g_settings_loaded = 1;

    FILE* sf = fopen("options/settings.txt", "r");
    if (!sf) return;

    char line[128];
    while (fgets(line, sizeof(line), sf)) {
        if (strncmp(line, "filelogs:", 9) == 0) {
            g_filelogs = strstr(line, "yes") ? 1 : 0;
        } else if (strncmp(line, "logips:", 7) == 0) {
            g_logips = strstr(line, "yes") ? 1 : 0;
        } else if (strncmp(line, "loggroups:", 10) == 0) {
            g_loggroups = strstr(line, "yes") ? 1 : 0;
        }
    }
    fclose(sf);
}

void log_settings_reload(void) {
    pthread_mutex_lock(&g_log_mutex);
    g_settings_loaded = 0;
    load_settings_locked();
    pthread_mutex_unlock(&g_log_mutex);
}

static FILE* open_append(const char* path) {
    FILE* f = fopen(path, "a");
    if (!f) {
        /* Try to create parent dir once � silences repeated ENOENT spam. */
        fprintf(stderr, "[logger] cannot open %s: %s\n", path, strerror(errno));
    }
    return f;
}

void log_command(const char* user, const char* ip, const char* command) {
    char logline[1024];
    char logline_plain[1024];
    char timestamp[32] = {0};

    get_timestamp(timestamp, sizeof(timestamp));

    pthread_mutex_lock(&g_log_mutex);
    load_settings_locked();

    if (g_logips && ip) {
        snprintf(logline, sizeof(logline),
                 "[" RED "%s" RESET "] " CYAN "%s" RESET " ran command: " YELLOW "%s" RESET "\n",
                 ip, user, command);
        snprintf(logline_plain, sizeof(logline_plain),
                 "[%s] %s ran command: %s\n", ip, user, command);
    } else {
        snprintf(logline, sizeof(logline),
                 CYAN "%s" RESET " ran command: " YELLOW "%s" RESET "\n",
                 user, command);
        snprintf(logline_plain, sizeof(logline_plain),
                 "%s ran command: %s\n", user, command);
    }

    if (g_filelogs) {
        if (!g_userlog) g_userlog = open_append("database/userlogs.txt");
        if (g_userlog) {
            fprintf(g_userlog, "[%s] %s", timestamp, logline_plain);
            fflush(g_userlog);
        }
    }
    pthread_mutex_unlock(&g_log_mutex);

    /* Console output outside the lock � printf can block on tty. */
    fputs(logline, stdout);
}

void log_bot_join(const char* arch, const char* ip, const char* group) {
    char logline[1024];
    char logline_plain[1024];

    pthread_mutex_lock(&g_log_mutex);
    load_settings_locked();

    if (g_loggroups && group && group[0]) {
        snprintf(logline, sizeof(logline),
                 CYAN "[BOT_JOINED]: " RESET DARK_RED "%s" RESET
                 " | " GREEN "Architecture:" RESET " " CYAN "%s" RESET
                 " | " GREEN "TYPE: " DARK_RED "%s\n",
                 ip, arch, group);
        snprintf(logline_plain, sizeof(logline_plain),
                 "[BOT_JOINED]: %s | Architecture: %s | TYPE: %s\n",
                 ip, arch, group);
    } else {
        snprintf(logline, sizeof(logline),
                 CYAN "[BOT_JOINED]: " RESET DARK_RED "%s" RESET
                 " | " GREEN "Architecture:" RESET " " CYAN "%s" RESET "\n",
                 ip, arch);
        snprintf(logline_plain, sizeof(logline_plain),
                 "[BOT_JOINED]: %s | Architecture: %s\n", ip, arch);
    }

    if (g_filelogs) {
        if (!g_botlog) g_botlog = open_append("database/logs.txt");
        if (g_botlog) {
            fputs(logline_plain, g_botlog);
            fflush(g_botlog);
        }
    }
    pthread_mutex_unlock(&g_log_mutex);

    fputs(logline, stdout);
}

void log_bot_disconnected(const char* ip, const char* arch, const char* cause) {
    char logline[1024];
    char logline_plain[1024];

    pthread_mutex_lock(&g_log_mutex);
    load_settings_locked();

    snprintf(logline, sizeof(logline),
             CYAN "[BOT_DISCONNECTED]: " RESET DARK_RED "%s" RESET
             " Arch: " CYAN "%s" RESET
             " Cause: " YELLOW "%s" RESET "\n",
             ip ? ip : "?", arch ? arch : "?", cause ? cause : "?");
    snprintf(logline_plain, sizeof(logline_plain),
             "[BOT_DISCONNECTED]: %s Arch: %s Cause: %s\n",
             ip ? ip : "?", arch ? arch : "?", cause ? cause : "?");

    if (g_filelogs) {
        if (!g_botlog) g_botlog = open_append("database/logs.txt");
        if (g_botlog) {
            fputs(logline_plain, g_botlog);
            fflush(g_botlog);
        }
    }
    pthread_mutex_unlock(&g_log_mutex);

    fputs(logline, stdout);
}