#include "headers/login_utils.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>

User users[MAX_USERS];
int user_count = 0;

static int token_equals_ci(const char *a, const char *b) {
    if (!a || !b) return 0;
    while (*a && *b) {
        if (tolower((unsigned char)*a) != tolower((unsigned char)*b)) return 0;
        a++; b++;
    }
    return *a == '\0' && *b == '\0';
}

static int is_admin_flag(const char *admin_flag) {
    if (!admin_flag || admin_flag[0] == '\0') return 0;
    return token_equals_ci(admin_flag, "admin")
        || token_equals_ci(admin_flag, "1")
        || token_equals_ci(admin_flag, "yes")
        || token_equals_ci(admin_flag, "true");
}

void load_users(void) {
    FILE *file = fopen("database/logins.txt", "r");
    if (!file) return;
    user_count = 0;

    char rootusers[512] = {0};
    FILE *sf = fopen("options/settings.txt", "r");
    if (sf) {
        char line[128];
        while (fgets(line, sizeof(line), sf)) {
            if (strncmp(line, "rootuser:", 9) == 0) {
                sscanf(line + 9, " %511s", rootusers);
                break;
            }
        }
        fclose(sf);
    }

    char line[256];
    while (user_count < MAX_USERS && fgets(line, sizeof(line), file)) {
        /* Skip comment/header lines */
        if (line[0] == '#' || line[0] == '\n' || line[0] == '\r') continue;

        users[user_count].is_admin      = 0;
        users[user_count].is_root       = 0;
        users[user_count].prefix_enabled = 0;
        users[user_count].expire_time   = 0;  /* default: never expires */

        char user[50], pass[50], admin_flag[16] = "";
        int  maxtime = 0, maxbots = 0;
        long long expire_raw = 0;

        /* Format: user pass maxtime maxbots [admin_flag [expire_timestamp]]
           Backward-compatible: fields 5 and 6 are optional. */
        int n = sscanf(line, "%49s %49s %d %d %15s %lld",
                       user, pass, &maxtime, &maxbots, admin_flag, &expire_raw);
        if (n < 4) continue;

        strncpy(users[user_count].user, user, sizeof(users[user_count].user) - 1);
        users[user_count].user[sizeof(users[user_count].user) - 1] = '\0';
        strncpy(users[user_count].pass, pass, sizeof(users[user_count].pass) - 1);
        users[user_count].pass[sizeof(users[user_count].pass) - 1] = '\0';

        users[user_count].maxtime     = maxtime;
        users[user_count].maxbots     = maxbots;
        users[user_count].expire_time = (time_t)expire_raw;

        if (n >= 5 && is_admin_flag(admin_flag))
            users[user_count].is_admin = 1;

        /* Root-user resolution from settings.txt */
        if (rootusers[0] != '\0') {
            char *root_copy = malloc(strlen(rootusers) + 1);
            strcpy(root_copy, rootusers);
            char *saveptr;
            char *token = strtok_r(root_copy, ",", &saveptr);
            while (token) {
                while (*token == ' ') token++;
                char *end = token + strlen(token) - 1;
                while (end > token && *end == ' ') { *end = '\0'; end--; }
                if (strcmp(user, token) == 0) {
                    users[user_count].is_root = 1;
                    break;
                }
                token = strtok_r(NULL, ",", &saveptr);
            }
            free(root_copy);
        }

        if (users[user_count].is_root) {
            users[user_count].is_admin = 1;
            users[user_count].expire_time = 0; /* root always has an active plan */
        }

        users[user_count].is_logged_in = 0;
        user_count++;
    }
    fclose(file);
}

/* Persist the in-memory user table back to disk.
   Format: user pass maxtime maxbots admin_flag expire_timestamp */
void save_users(void) {
    /* Write to tmp first, then atomic rename — never corrupt the live file. */
    FILE *f = fopen("database/logins.tmp", "w");
    if (!f) return;

    fprintf(f, "#USER PASS MAXTIME MAXBOTS ADMIN expire_timestamp\n");
    for (int i = 0; i < user_count; i++) {
        fprintf(f, "%s %s %d %d %s %lld\n",
                users[i].user,
                users[i].pass,
                users[i].maxtime,
                users[i].maxbots,
                users[i].is_admin ? "admin" : "0",
                (long long)users[i].expire_time);
    }
    fclose(f);
    rename("database/logins.tmp", "database/logins.txt");
}

int check_login(const char *user, const char *pass) {
    time_t now = time(NULL);
    for (int i = 0; i < user_count; i++) {
        if (strcmp(user, users[i].user) == 0 && strcmp(pass, users[i].pass) == 0) {
            if (users[i].is_logged_in) return -2;
            /* expire_time == 0 → never expires (root / lifetime plan) */
            if (users[i].expire_time > 0 && now >= users[i].expire_time) return -3;
            return i;
        }
    }
    return -1;
}
