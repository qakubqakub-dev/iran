#pragma once

#ifndef ATTACK_PARAMS_H
#define ATTACK_PARAMS_H

#include <arpa/inet.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <linux/ip.h>
#include <linux/udp.h>
#include <linux/tcp.h>
#include <linux/icmp.h>
#include <errno.h>
#include <time.h>
#include <stdio.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <poll.h>
#include <ctype.h>
#include <stddef.h>
#include <sys/time.h>
#include "checksum.h"

typedef struct {
    struct sockaddr_in target_addr;
    uint32_t duration;
    uint8_t  active;
    uint16_t len;       /* packet size (or min if range) */
    uint16_t len_min;
    uint16_t len_max;
    uint16_t srcport;
    uint8_t  http_method;  /* 1=GET 2=POST 4=HEAD */
    uint32_t base_ip;
    uint8_t  cidr;
    unsigned char msg[128];
    int msg_len;
    int usleep_min;
    int usleep_max;
} attack_params;

typedef struct {
    struct sockaddr_in target_addr;
    uint32_t duration;
    uint8_t  active;
    uint32_t len;       /* was psize */
    uint16_t srcport;
    uint16_t gre_proto; /* 0=IP 1=TCP 2=UDP */
    uint16_t gport;
    uint32_t base_ip;
    uint8_t  cidr;
    unsigned char msg[128];
    int msg_len;
    int usleep_min;
    int usleep_max;
} gre_attack_params;

#endif // ATTACK_PARAMS_H
